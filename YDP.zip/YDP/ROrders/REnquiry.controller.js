/**
****************************************************************************************
*  Changed on:  Changed by:   Change ID:  TR Number:        Description:
*  2017.11.16   Subha          C001      GKAK908020        model change-table
*               z019767
*  2017.11.17  SUBHA-z019767   C002      GKAK908031        table count clear.
* 2017.11.22   subha           C003      GKAK908047        filter date correction.
*****************************************************************************************
*/
sap.ui.define([
        "encollab/dp/BaseController",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/Sorter",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/format/DateFormat"
    ],
    /**
     * <p>Order Enquiry controller, the methods in this class look after searching orders</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Orders</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.ROrders.Enquiry.view.xml</li>
     * </ul>
     * @class Enquiry
      * @memberOf encollab.dp.ROrders
     * @extends {encollab.dp.BaseController}
     * @param  {encollab.dp.BaseController} Controller
     * @param  {sap.ui.movel.Filter} Filter
     * @param  {sap.ui.model.FilterOperator} FilterOperator
     * @param  {sap.ui.model.Sorter} Sorter
     * @param  {sap.ui.model.json.JSONModel} JSONModel
     * @param  {sap.ui.core.format.DateForms} DateFormat
     * @return {encollab.dp.ROrders.REnquiry}
     */
    function(Controller, Filter, FilterOperator, Sorter, JSONModel, DateFormat) {

         "use strict";

        return Controller.extend("encollab.dp.ROrders.REnquiry", {
            /**
             * List of user parameters required to search for orders
             * @name   encollab.dp.ROrders.Detail#_userParameters
             * @type {array<string>}
             * @member
             */
            _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
            /**
             * Holds all the activate calls
             * @name   encollab.dp.ROrders.Detail#_activeCalls
             * @type {array<function>}
             * @member
             */
            _activeCalls: [],
            /**
             * placeholder for the right formatting function
             * @name   encollab.dp.ROrders.Detail#_prepare
             * @type {function}
             * @member
             */
            _prepare: null,

            /**
             * On initialization, this method sets up a local model to hold the results of the search. Orders are fetched based
             * on a date range, further filtering and sorting is done on this local JSON model instead of on the oData service.
             *
             * @method
             * @name   encollab.dp.ROrders.REnquiry#onInit
             */
            onInit: function() {

                Controller.prototype.onInit.apply(this, arguments);

                this.myRouter.getRoute("ROrders").attachPatternMatched(this._onObjectMatched, this);

                this.model = new JSONModel({
                    count: 0,
                    ROrder_tab: [],
                    price_p: 0,
                    priceuom: 'IDR',
                    table: 'ROrdersTable'
                });

                this.setModel(this.model, 'data');

                this._ordersTable = this.byId('ROrdersTable');
            },

            /**
             * Sets up the dates and initializes a search when the route "orders" is matched
             * @name   encollab.dp.ROrders.Detail#_onObjectMatched
             * @method
             * @param  {sap.ui.base.Event} oEvent
             */
            _onObjectMatched: function(oEvent) {
                var dates = this.byId('ROrdersSearchBar').getDateRange();
                this._search(dates.first, dates.last);
            },
            /**
             * Adds a filter to the json data set up on the table
             * @name   encollab.dp..ROrders.Detail#onSearchFilter
             * @method
             * @param  {sap.ui.base.Event} oEvent
             */
            onSearchFilter: function(oEvent) {
                var searchString = oEvent.getParameter('filter');

                var binding = this._ordersTable.getBinding('rows');
                var filters = new Filter([
                    new Filter("Searcher", FilterOperator.Contains, searchString.toUpperCase())
                ], false);

                binding.filter(filters, sap.ui.model.FilterType.Control)
            },
            /**
             * Executes a new search on the oData channel when the date range changes
             * @name   encollab.dp..ROrders.Detail#onSearchSearch
             * @param  {sap.ui.base.Event} oEvent
             * @method
             */
            onSearchSearch: function(oEvent) {
                var firstDate = oEvent.getParameter('first');
                var lastDate = oEvent.getParameter('last');

                this._search(firstDate, lastDate);
            },

            /**
             * Performs the actual search on the oData channel. It does several things:
             * <ul>
             * <li>Cancels all current active calls to the odata model</li>
             * <li>Adds filters for the first and last date in the range</li>
             * <li>On success, sends results to the proper formatter.</li>
             * </ul>
             * @name   encollab.dp.ROrders.Detail#_search
             * @param  {date} firstDate
             * @param  {date} lastDate
             * @method
             */
            _search: function(firstDate, lastDate) {
                this._ordersTable.setBusy(true);
                //cancel all active calls

                $.each(this._activeCalls, function(i, a) {
                    a.call();
                });
                //BOC-C003
                var filters = [
                  new Filter('OrdDate', FilterOperator.BT, this.accountForUTCDate(firstDate), this.accountForUTCDate(lastDate))
                ]
               //EOC-C003
                this.getModel('ROrders').setUseBatch(false);


                //push the current active call's ABORT function into the active calls.
                this._activeCalls.push(this.getModel('ROrders').read('/ReturnOrderSet', { //ReturnOrderSet
                    filters: filters,
                    sorters: [
                        //new Sorter('OrdDate', false, false)
                    ],
                    urlParameters: {
                        '$top': 999999,
                        //'$expand': 'ItemsSimple',
                        '$format': 'json'
                    },
                    success: function(data) {
                        //set active calls to nothing.
                        this._activeCalls = [];
                        //BOC-C001
                        this.model.setProperty('/ROrders', this._prepareHeaderResults(data.results));
                        //EOC-C001
                        this._ordersTable.setBusy(false);
                        this.getModel('ROrders').setUseBatch(true);
                    }.bind(this)
                }).abort);
            },
            /**
             * Formats data as headers only. In order to do the local search, and in order to get the sorters right,
             * some values are converted to strings that are actually numbers, and it converts dates from JS Date objects
             * to formatter strings. It also creates a field that is not displayed called 'searcher' to make filtering later easier.
             * @name   encollab.dp..ROrders.Detail#data.res
             * @param  {object} data
             * @return {object}
             * @method
             */
            _prepareHeaderResults: function(data) {
            //BOC-C002
               if (data.length === 0) {
          this.model.setProperty('/price_p', 0);
          this.model.setProperty('/count', 0);
          return [];
        }
        //EOC-C002

                this.unformatted = data;

                var value = 0,
                    d = {},
                    newData = [];

                data = data.sort(function(a, b) {
                    return (b.Invoice - a.Invoice);
                });

                for (var i = 0; i < data.length; i++) {
                        d = data[i];
                        d.Qty = parseInt(d.Qty);
                        d.Invoice = parseInt(d.Invoice);
                        d.Price = parseInt(d.Price);
                d.NetValue = parseInt(d.NetValue);
                d.Amount = parseInt(d.Amount);

                        d.Searcher = [
                            d.Invoice.toString(),
                            d.OrdDate,
                            d.OrderNr,
                            d.OrderNr_O,
                            d.Material,
                            d.Status
                        ].join().toUpperCase();

                        value += d.Price;
                        newData.push(d);
                    }

                newData = newData.sort(function(a, b) {
                    return (b.Invoice - a.Invoice);
                });

                this.model.setProperty('/price_p', value);
                this.model.setProperty('/ROrders', newData);
                this.model.setProperty('/count', newData.length + ' Orders found');
                this.model.setProperty('/table', 'ROrdersTable');

                return newData;
            },

            /**
             * When pressing an order number, navigates to the order detail screen
             * @name   encollab.dp..ROrders.Detail#onPress
             * @param  {sap.ui.base.Event} oEvent The event object
             * @method
             */
            onPress: function(oEvent) {

                var oItem = oEvent.getSource();

                this.myRouter.navTo("ordersdetail", {
                    orderPath: oItem.getBindingContext('data').getProperty('OrderNr_O')
                });
            },
            /**
            /**
             * Formatter. Shows the order type or a generic title
             * @name   encollab.dp.ROrders.Detail#onCreatePress
             * @param {string} title
             * @param {string} orderType
             * @method
             */
            titlePicker: function(title, orderType) {
                return (orderType) ? orderType : title;
            }
        });
    });