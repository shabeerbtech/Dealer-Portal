sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function(JSONModel) {
	return JSONModel.extend("encollab.dp.orders.detail.DocFlowModel", {

		constructor: function(orders) {
			this.orders = orders;
			JSONModel.prototype.constructor.call(this);
		},
		setFlow: function(order, docflow) {
			var flow = [],
				doc, pos, so, delvry, matnr, structure = null;

			for (var i = 0; i < docflow.length; i++) {

				var d = docflow[i];

				if (d.Docnum.toString() === order.toString()) {
					so = d;
				} else if (d.Vbtyp_n === 'J') {
					delvry = d;
					matnr = this.orders.getProperty("/SalesOrderItemSet(OrderNr='" + so.Docnum + "',ItemNr='" + so.Itemnum + "')").Material
				}

				if (delvry) {
					if (flow[flow.length - 1] && flow[flow.length - 1].Item === d.Itemnum && flow[flow.length - 1].Delivery === '') {
						flow.pop();
					}
					if (d.Docnum === delvry.Docnum) {
						if (structure !== null) {
							flow.push(structure);
						}
						structure = {
							Material: matnr,
							Item: so.Itemnum,
							Delivery: delvry.Docnum,
							Invoice: '',
							openDate: so.Erdat,
							openTime: so.Erzet,
							pickingDate: '',
							pickingTime: '',
							packingDate: '',
							packingTime: '',
							deliveryDate: '',
							deliveryTime: '',
							confirmedDate: '',
							confirmedTime: '',
							Quantity: delvry.Qty,
							QuantityUom: delvry.QtyUom
						};
					}

					switch (d.Vbtyp_n) {
						case 'J': //delivery
							structure.pickingDate = d.Erdat;
							structure.pickingTime = d.Erzet;
							break;
						case 'Q': //WMS transfer order
							structure.packingDate = d.Erdat;
							structure.packingTime = d.Erzet;
							break;
						case 'R': //goods movement
							structure.deliveryDate = d.Erdat;
							structure.deliveryTime = d.Erzet;
							break;
						case 'M':
							structure.Invoice = d.Docnum
							break;
					}

				} else {
					flow.push({
						Material: matnr,
						Item: so.Itemnum,
						Delivery: '',
						Invoice: '',
						openDate: so.Erdat,
						openTime: so.Erzet,
						pickingDate: '',
						pickingTime: '',
						packingDate: '',
						packingTime: '',
						deliveryDate: '',
						deliveryTime: '',
						confirmedDate: '',
						confirmedTime: '',
						Quantity: d.Qty,
						QuantityUom: d.QtyUom
					});
				}
			}

			//the last one will miss out if it had no delivery
			if (structure !== null) {
				flow.push(structure);
			}

			this.setProperty('/docflow', flow);
		},
		_getStructure: function(d) {
			for (var i = 0; i < this._flow.length; i++) {
				if (this._flow[i].Docnuv === d.Docnuv && this._flow[i].Itemnuv === d.Itemnuv) {
					return i;
				}
			}
			var structure = {
				Docnuv: d.Docnuv,
				Itemnuv: d.Itemnuv,
				Docnum: d.Docnum,
				Itemnum: d.Itemnum,
				openDate: '',
				openTime: '',
				picking: '',
				packing: '',
				delivered: ''
			}
			this._flow.push(structure);
			return this._flow.length - 1;
		}
	});
});