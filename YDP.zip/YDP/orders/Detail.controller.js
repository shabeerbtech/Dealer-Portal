/**
 ****************************************************************************************
 *  Changed on:  Changed by:   Change ID:  TR Number:        Description:
 *  2017.11.23   Subha          C001       GKAK908073       IE changes code replacement
 *  2017.11.24   Subha          C002(C001  GKAK908094
 *                              /C002 /C003 (GKAK907475/GKAK907481
 *                             /C004/C005) /GKAK907507/GKAK907751/GKAK907892)  ZRE validation-code replace
 * 2018.01.10   SUBHA          C006          GKAK908267         Special char with PO ENCODE/DECODE
 * 2018.01.24   SUBHA         C007         GKAK908333           concatenate PO&OrderType&sold to
 * 2018.01.25  subha          C008        GKAK908340                 item Qty concatenate value
 * 2018.02.01 subha           C009        GKAK908349               FILE Drop key change
 *****************************************************************************************
 */
sap.ui.define([
        "encollab/dp/BaseController",
        'sap/ui/model/Filter',
        'sap/ui/model/FilterOperator',
        'sap/m/MessageToast',
        'encollab/dp/controls/ValueDialog',
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Item"
    ],
  /**
   * <p>This is the controller for the page that handles Order Creation. It only presents a few fields as defined in HeaderModel that
   * corrensponds to the actual order model. It presents two extra fields and a look up for Invoices when choosing a Return Order. </p>
   * <h4>OData services used</h4>
   * <ul>
   * <li>Orders</li>
   * <li>Parts</li>
   * <li>Core</li>
   * </ul>
   * <h4>Templates used</h4>
   * <ul>
   * <li>encollab.dp.order.Detail.view.xml</li>
   * <li>encollab.dp.order.detail.changeFakturPajak.fragment.xml</li>
   * <li>encollab.dp.order.detail.confirmNavigationDialog.fragment.xml</li>
   * <li>encollab.dp.order.detail.documentFlow.fragment.xml</li>
   * <li>encollab.dp.order.detail.documentFlowItemTemplate.fragment.xml</li>
   * <li>encollab.dp.order.detail.fakturPajak.fragment.xml</li>
   * <li>encollab.dp.order.detail.fakturPajakTemplate.fragment.xml</li>
   * <li>encollab.dp.order.detail.orderChanges.fragment.xml</li>
   * <li>encollab.dp.order.detail.orderChangesTemplate.fragment.xml</li>
   * <li>encollab.dp.order.detail.salesOrderHeader.fragment.xml</li>
   * <li>encollab.dp.order.detail.salesOrderItems.fragment.xml</li>
   * <li>encollab.dp.order.detail.salesOrderItemTemplate.fragment.xml</li>
   * <li>encollab.dp.order.detail.scheduleLines.fragment.xml</li>
   * <li>encollab.dp.order.detail.scheduleLinesTemplate.fragment.xml</li>
   * <li>encollab.dp.order.detail.UpdateHeaderDialog.fragment.xml</li>
   * </ul>
   * @class Detail
   * @memberOf encollab.dp.orders
   * @extends {encollab.dp.BaseController}
   * @param  {encollab.dp.BaseController} Controller
   * @param  {sap.ui.model.Filter} Filter
   * @param  {sap.ui.model.FilterOperator} Operator
   * @param  {sap.m.MessageToast} MessageToast
   * @param  {encollab.dp.controls.ValueDialog} ValueDialog
   * @param  {sap.ui.model.json.JSONModel} JSONModel
   * @param  {sap.ui.core.Item} Item
   * @return {encollab.dp.orders.Detail}
   */
  function(Controller, Filter, Operator, MessageToast, ValueDialog, JSONModel, Item) {
    "use strict";
    return Controller.extend("encollab.dp.orders.Detail", {
      /**
       * This array holds the user parameters required to run this controller. In this case, the user has to be set up
       * with SPA, VKO, VTW (the entire sales area), and WRK (plant)
       *
       * @private
       * @member
       * @name   encollab.dp.orders.Detail#_userParameters
       */
      _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
      _count: 0,
      /**
       * On initialization, this method sets up the model for the header and binds the Inco Terms search help to it.
       * It also checks if the current order is a return order or not. This flag is set on the data model and used throughout the
       * screen to show and hide certain elements
       *
       * @method
       * @name   encollab.dp.orders.Detail#onInit
       */
      onInit: function() {
        Controller.prototype.onInit.apply(this, arguments);

        this.setModel(new JSONModel({
          active: true,
          isReturn: false,
          isNotReturn: true
        }), 'data');

        if (!this.header) {
          this.header = sap.ui.xmlfragment("encollab.dp.orders.detail.UpdateHeaderDialog", this);
          this.getModel('orders').read('/IncoTermsSet', {
            success: function(ord) {
              this.header.setModel(new JSONModel({
                IncoTerms: ord.results
              }), 'data');
            }.bind(this)
          });
          this.header.setModel(this.getModel('orders'), 'orders');
          this.header.setModel(this.getModel('i18n'), 'i18n');
        }

        var item = this.getView().byId('idMaterialDialog');

        this.byId('ordersHowToDialogLink').setHref(this.getRelativeUrl('order.csv'))
        this.byId('idSOItemsTable').setNoDataText('No existing items');
        this.byId('idSOItemsTable').addStyleClass('sapUiLargeMarginBottom');

        this.myRouter.getRoute("ordersdetail").attachPatternMatched(this._onObjectMatched, this);
       // BOC-C007
        this.myRouter.getRoute("ordercall").attachPatternMatched(this._onKeyChange, this);
        //BOC-C007
      },

      /**
       * If the current route is "ordersdetail", the orders oData service is bound to the view containing the
       * current order number as taken from the URL, expanded on Items, Deliveries, ScheduleLines and Changes.
       * It also sets a parameter to see if the order is a return or not, as that drives some of the visuals.
       *
       * @method
       * @name   encollab.dp.orders.Detail#_onObjectMatched
       */
      _onObjectMatched: function(oEvent) {
   //   BOC-C006
        this.order = encodeURIComponent(this.order);
        this.order = oEvent.getParameter("arguments").orderPath;
        var model = this.getModel('orders');
        var path = "SalesOrderSet('" + this.order + "')";
        this.path1 = path;
        var expand = 'Items,Deliveries,ScheduleLines,Changes';
        if (this.order) {
          //docflow now separate because it's completely rehashed and does not
          //resemble the actual docflow. it used to be just in the binditems below

          //bind items
          this.myView.bindElement({
            model: 'orders',
            path: "/" + path,
            parameters: {
              expand: expand
            },
            events: {
              change: this._onBindingChange.bind(this),
              dataRequested: function() {
                this.getView().setBusy(true);
              }.bind(this),
              dataReceived: function(oEvent) {
                this.getView().setBusy(false);
                var doctype = this.getModel('orders').getProperty("/SalesOrderSet('" + this.order + "')/DocType");
                this.getModel('data').setProperty('/isReturn', (doctype === 'ZRE'));
                this.getModel('data').setProperty('/isNotReturn', (doctype !== 'ZRE'));
//BOC - C005
                this.getModel('data').setProperty('/isReturn', (doctype === 'ZCR'));
                this.getModel('data').setProperty('/isNotReturn', (doctype !== 'ZCR'));
//EOC - C005
              this.order = decodeURIComponent(this.order);
                this._buttonStatus();
                //BOC-C002
                this.doctype = doctype;
                //EOC-C002
              }.bind(this)
            }
          });

          //bind to header separately.
          this.header.bindElement({
            model: 'orders',
            path: "/" + "SalesOrderSet('" + this.order + "')"
          });
        }
            this.order = decodeURIComponent(this.order);
         	// EOC-C006
      },

      //BOC-C007
      _onKeyChange: function(oEvent) {
        var sVehiclePath = oEvent.getParameter("arguments").orderPath;
        this.DocType = oEvent.getParameter("arguments").DocType;
        this.SoldTo = oEvent.getParameter("arguments").SoldTo;
        this.order = sVehiclePath;
        var concat = decodeURIComponent(this.order + '*' + this.DocType + '*' + this.SoldTo);

        var model = this.getModel('orders');

          var conSO = this.order + '*' + this.DocType + '*' + this.SoldTo;
        var path = "SalesOrderSet('" + conSO + "')";
        var expand = 'Items,Deliveries,ScheduleLines,Changes';

        if (this.order) {
          //docflow now separate because it's completely rehashed and does not
          //resemble the actual docflow. it used to be just in the binditems below

          //bind items
          this.myView.bindElement({
            model: 'orders',
            path: "/" + path,
            parameters: {
              expand: expand
            },
            events: {
              change: this._onBindingChange.bind(this),
              dataRequested: function() {
                this.getView().setBusy(true);
              }.bind(this),
              dataReceived: function(oEvent) {
                this.getView().setBusy(false);
                // + this.order + "
                var doctype = this.getModel('orders').getProperty("/SalesOrderSet('" + this.order + "')/DocType");
                this.getModel('data').setProperty('/isReturn', (doctype === 'ZRE'));
                this.getModel('data').setProperty('/isNotReturn', (doctype !== 'ZRE'));
                //BOC - C005
                this.getModel('data').setProperty('/isReturn', (doctype === 'ZCR'));
                this.getModel('data').setProperty('/isNotReturn', (doctype !== 'ZCR'));
                //EOC - C005
                this.order = decodeURIComponent(this.order);
                this._buttonStatus();
                //BOC-C002
                this.doctype = doctype;
                //EOC-C002
              }.bind(this)
            }
          });

          //bind to header separately.
          this.header.bindElement({
            model: 'orders',
            path: "/" + "SalesOrderSet('" + this.order + "')"
          });
        }

        this.order = decodeURIComponent(this.order);
      },
      //EOC-C007
      /**
       * If the binding changes, so if the order changes in other words, some things need to be reset.
       *
       * @method
       * @name   encollab.dp.orders.Detail#_onBindingChange
       */
      _onBindingChange: function() {
        var oView = this.getView(),
          oElementBinding = oView.getElementBinding('orders');
        try {
          var path = this.getView().getBindingContext('orders').getPath();
          var data = this._expandElementBindingToData(this.path1, this.getModel('orders'));
          var out = this._formatOrderForDownload(data);
          this.byId('idDetailButtonDownload').setData(out);
        } catch (e) {

        }
        // No data for the binding
        if (!oElementBinding.getBoundContext()) {
          oView.setBusy(false);
          this.getRouter().getTargets().display("objectNotFound");
          return;
        } else {
         // BOC-C006
            this.order = decodeURIComponent(this.order);
          this._buttonStatus();
        //  EOC-C006

        }

        this._resetItemCheckboxes();
      },
      /**
       * IncoTerms suggestions.
       *
       * @method
       * @name   encollab.dp.orders.Detail#onIncoTermsSuggest
       */
      onIncoTermsSuggest: function(oEvent) {
        var oSearch = oEvent.getSource();

        var value = oEvent.getParameter("suggestValue");

        var filters = [];
        if (value) {
          filters = [new sap.ui.model.Filter([
                        new sap.ui.model.Filter("Bezei", function(sText) {
              return (sText || "").toUpperCase().indexOf(value.toUpperCase()) > -1;
            }),
                        new sap.ui.model.Filter("Inco1", function(sDes) {
              return (sDes || "").toUpperCase().indexOf(value.toUpperCase()) > -1;
            })
                    ], false)];

        }

        oSearch.getBinding("suggestionItems").filter(filters);
        oSearch.suggest();
      },
      /**
       * The status of Release and Add Item button is checked in various places. This makes sure the buttons
       * are enabled / disabled based on the delivery block.
       *
       * @method
       * @name   encollab.dp.orders.Detail#_buttonStatus
       */
      _buttonStatus: function() {
      // BOC-C006
        this.order = encodeURIComponent(this.order);
        var order = this.getModel('orders').getProperty("/SalesOrderSet('" + this.order + "')");
        this.order = decodeURIComponent(this.order);
        //EOC-C006
      if (order.DeliveryBlock !== "YP") {
          this.getModel('data').setProperty('/active', false);
          //this.byId('idDetailButtonSave').setType("Default").setEnabled(false);
          this.byId('idDetailButtonRelease').setType("Default").setEnabled(false);
          this.byId('idDetailButtonCreate').setType("Emphasized");
          this.byId('idAddItem').setVisible(false);
        } else {
          this.byId('idDetailButtonRelease').setType("Emphasized").setEnabled(true);
          this.byId('idDetailButtonCreate').setType("Default");
          this.byId('idAddItem').setVisible(true);
          this.getModel('data').setProperty('/active', true);
        }

      },
      /**
       * This method searches the Parts oData service for materials based on the user input, and
       * populates the list underneath it.
       *
       * @method
       * @param  {sap.ui.base.Event} oEvent The event object
       * @name   encollab.dp.orders.Detail#onSearch
       */
      onSearch: function(oEvent) {
        var filters = [];
        var searchString = oEvent.getParameter("newValue");

        if (searchString && searchString.length > 3) {

          var oTemplate = new Item({
            key: "{part>PartID}",
            text: "{part>PartID} - {part>PartDesc}"
          });

          var status = this.getView().byId('idLoading');

          //filters.push(new Filter('Salesorg', Operator.EQ, this.myComponent.getMySettingValue('VKO')));
          //filters.push(new Filter('Distchannel', Operator.EQ, this.myComponent.getMySettingValue('VTW')));
          filters.push(new Filter({
            filters: [
                            new Filter("PartID", Operator.Contains, searchString.toUpperCase()),
                            new Filter("PartDesc", Operator.Contains, searchString.toUpperCase())
                        ],
            and: false
          }));

          this.getView().byId("idMatList").bindItems({
            path: "part>/PartSearchSet",
            parameters: {
              select: "PartID,PartDesc"
            },
            template: oTemplate,
            filters: filters,
            events: {
              dataRequested: function() {
                status.setText('Searching....');
              },
              dataReceived: function(mResponse) {
                status.setText(mResponse.getParameter('data').results.length + ' matches found');
              }
            }
          });
        } else {
          this.getView().byId("idMatList").unbindItems();
        }
      },
      /**
       * When a material from the search list is pressed, it's key is stored
       *
       * @method
       * @param  {sap.ui.base.Event} oEvent The event object
       * @name   encollab.dp.orders.Detail#onMatItemPress
       */
      onMatItemPress: function(oEvent) {
        var material = oEvent.getParameter('item').getKey();
        this.byId('newItemSearch').setValue(material);
        oEvent.getSource().unbindItems();
      },
      /**
       * When the material is added, it's key and quantity are retrieved and the Orders oData channel is used to
       * add an order line. Input is reset afterwards.
       *
       * @method
       * @param  {sap.ui.base.Event} oEvent The event object
       * @name   encollab.dp.orders.Detail#onAddMaterial
       */
//BOC-C007
      onAddMaterial: function(oEvent) {
          var oSource = oEvent.getSource();
         var path = oSource.getBindingContext('orders').getPath();
         var line = this.getModel('orders').getProperty(path);
        this.resetMessagePopover();
        var material = this.byId('newItemSearch').getValue().trim().toUpperCase();
        var qty = this.byId('idAddMaterialQtyInput').getValue() || "1";

        if (typeof material !== 'undefined' && material !== '' && typeof qty !== 'undefined' && parseInt(qty) > 0) {
          var structure = this._getOrderStructure();
          this.byId('idSOItemsTable').setBusy(true);

          var data = this._getItemStructure({
            Material: material,
            SalesQuantity: qty.toString().trim()
          });
        //  BOC-C006
          data.OrderNr = decodeURIComponent(data.OrderNr);
        //  EOC-C006
          structure.Items.push(data);
          structure.DocType = line.DocType;
          structure.SoldTo = line.SoldTo;

          this.getModel('orders').create('/SalesOrderSet', structure, {
            success: this._onCreateItemSuccess.bind(this),
            error: this._onCreateItemError.bind(this)
          });

          this.getView().byId("idMatList").unbindItems();
          this.getView().byId('idLoading').setText('');

          this.byId('idAddMaterialQtyInput').setValue("1");
          this.byId('newItemSearch').setValue(null).focus();
        }
        },
        //EOC-C007
      /**
       * Updates an order line with the Proof of Delivery line when the user enters a date in the input dialog.
       *
       * @method
       * @param  {sap.ui.base.Event} oEvent The event object
       * @name   encollab.dp.orders.Detail#onPODDate
       */
      onPODDate: function(oEvent) {
        var date = this.accountForUTCDate(oEvent.getSource().getDateValue());
        if (date > new Date()) {
          MessageToast.show(this.getModel('i18n').getProperty('ordersDetailPODMessage'));
          this.warningMessage(this.getModel('i18n').getProperty('ordersDetailPODMessage'))
          oEvent.getSource().setDateValue(null)
        } else {
          var index = parseInt(oEvent.getSource().getId().match(/[0-9]*$/)[0]);
          var data = this.byId('idSODocFlowTable').getItems();
          var path = data[index].getBindingContext('orders').getPath();
          var line = this.getModel('orders').getProperty(path)
          line.PODDate = date;

          this.getModel('orders').update(path, line, {
            success: function(data) {
              },
            error: function(data) {
                  }
          })
        }
      },
      /**
       * Opens the How-To dialog
       *
       * @method
       * @name   encollab.dp.orders.Detail#onHowToButton
       * @param  {sap.ui.base.Event} oEvent The event object
       */
      onHowToButton: function(oEvent) {
        this.byId('ordersHowToDialog').open();
      },
      /**
       * Checks wether the Proof of Delivery input box should be displayed or not
       *
       * @method
       * @name   encollab.dp.orders.Detail#onPODEnabled
       * @param {date} date A date object
       * @param {string} delivery the delivery number
       * @return {boolean} POD box enabled or disabled
       */
      onPODEnabled: function(date, delivery) {
        if (date !== null) return false;

        return (delivery !== '');
      },
      /**
       * Closes the How-To dialog
       *
       * @method
       * @name   encollab.dp.orders.Detail#onHowToCancel
       */
      onHowToCancel: function(oEvent) {
        this.byId('ordersHowToDialog').close();
      },
      /**************************************************************
                Public event handlers (buttons, links)
             **************************************************************/

      /**
       * The callback that fires when a file is dropped onto order screen. It parses the lines inside
       * and creates order items from them.
       *
       * @method
       * @name   encollab.dp.orders.Detail#onFileDrop
       * @param  {sap.ui.base.Event} oEvent The event object
       */
      onFileDrop: function(oEvent) {
        this.resetMessagePopover();
        //navigate to change items screen if not there.
        this.byId('idDetailIconTabBar').setSelectedKey('__filter0');
        this.byId('idSOItemsTable').setBusy(true);
        var data = oEvent.getParameter('data');

        var structure = this._getOrderStructure();

        for (var i = 0; i < data.length; i++) {
        //BOC-C009
         structure.DocType = this.DocType;
           structure.SoldTo = this.SoldTo;
          structure.Reference = this.order;
          //EOC-C009
          if (data[i].length === 2) {
            structure.Items.push(this._getItemStructure({
              Material: data[i][0],
              SalesQuantity: data[i][1].trim()
            }));
          }
        }

        if (structure.Items.length > 0) {
          this.getModel('orders').create('/SalesOrderSet', structure, {
            success: this._onCreateItemSuccess.bind(this),
            error: this._onCreateItemError.bind(this)
          });
        } else {
          MessageToast('Issue uploading ')
          this.byId('idSOItemsTable').setBusy(false);
        }

      },
      /**
       * Displays a message when file upload fails
       *
       * @method
       * @name   encollab.dp.orders.Detail#onFileError
       * @param  {sap.ui.base.Event} oEvent The event object
       */
      onFileError: function(oEvent) {
        var text = oEvent.getParameter('message');
        MessageToast.show(text);
        this.errorMessage(text);
      },

      onCreatedByPress: function(oEvent) {
        this.myRouter.navTo('ordersenquiry', {
          searchTerm: oEvent.getSource().getText()
        });
      },
      /**
       * Opens the dropdown on the title selector
       *
       * @method
       * @name   encollab.dp.orders.Detail#onTitleSelectorPress
       * @param  {sap.ui.base.Event} oEvent The event object
       */
      onTitleSelectorPress: function(oEvent) {
        this.header.openBy(oEvent.getSource());
      },
      /**
       * All material names are links that open the app on the Parts screen, where the material
       * details are displayed. See class encollab.dp.parts.Detail.
       *
       * @method
       * @name   encollab.dp.orders.Detail#onMaterialPress
       * @param  {sap.ui.base.Event} oEvent The event object
       */
      onMaterialPress: function(oEvent) {
        var oContext = oEvent.getSource().getBindingContext('orders').getPath();
        var oData = this.getView().getBindingContext('orders').getProperty(oContext);

        var partId = oData.Material;
        if (partId) {
          this.myRouter.navTo("partsdetail", {
            partPath: partId
          });
        }
      },
      /**
       * When the order quantity is pressed, a dialog box opens up where the order line item quantity can be adjusted.
       *
       * @method
       * @name   encollab.dp.orders.Detail#onItemQtyPress
       * @param  {sap.ui.base.Event} oEvent The event object
       */

      onItemQtyPress: function(oEvent) {

        this.qty = {
          path: oEvent.getSource().getBindingContext('orders').getPath(),
          item: oEvent.getSource()
        }
        var item = this.formatter.removeLeadingZeroes(this.getModel('orders').getProperty(this.qty.path + '/ItemNr'));

        var dialog = new ValueDialog({
          title: 'Change Quantity of item ' + item,
          question: 'Enter a new Quantity',
          value: this.getModel('orders').getProperty(this.qty.path + '/SalesQuantity'),
          onConfirm: this._onItemQtyConfirm.bind(this)
        });

        this.getView().addDependent(dialog);
        dialog.open();
      },

      onUpdateHeaderConfirmButton: function(oEvent) {
        this.getView().setBusy(true);
        this.header.close();

        var data = this.getView().getBindingContext('orders').getProperty();
        var path = this.getView().getBindingContext('orders').getPath();

        delete data.__metadata;
        delete data.Items;
        delete data.DocFlow;
        delete data.DocFlowSet;
        delete data.Changes;
        delete data.Deliveries;
        delete data.ScheduleLines;

        //kinda bizarre
        $.each(this.header.findElements(true), function(i, e) {
          switch (e.getId()) {
            case 'idUpdateHeaderReference':
            case 'idUpdateHeaderIncoTerms2':
              data[e.getId().replace('idUpdateHeader', '')] = e.getValue();
              break;
            case 'idUpdateHeaderIncoTerms1':
              data.IncoTerms1 = e.getSelectedItem().getKey()
              data.IncoTerms1Descr = e.getSelectedItem().getText()
              break;
          }
        });

        this.getModel('orders').update(path, data, {
          success: this._onUpdateHeaderSuccess.bind(this),
          error: this._onUpdateHeaderError.bind(this)
        });
      },

      /**
       * Formats all details of the order in the preferred CSV layout for download
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_formatOrderForDownload
       * @param  {array<object>} json JSON data
       * @return {string} CSV details of the order
       */
      _formatOrderForDownload: function(json) {
        var structure = {
          items: 'MaterialGroup,SalesUoM,Plant,MatGroupDesc,FPNumbers,HighItmNr',
          deliveries: 'Posnr,OrderNr,Material,MaterialDescr',
          schedule: 'Category,Material,MaterialDescr,OrderNr,ItemNr,OrderQty'
        }

        var out = []

        var self = this;

        //header stuff, each on own line
        $.each(json, function(key, val) {
          if (!(val instanceof Array)) {
            out.push('"' + key + '","' + self._format(val) + '"');
          }
        });

        //loop schedule lines into items
        var itemkeys = [];
        var itemlines = [];
        var schedulekeys = [];
        var schedulelines = [];
        try {
          $.each(json.Items, function(itemkey, item) {
            if (parseInt(item.HighItmNr) === 0) {
              $.each(json.Deliveries, function(deliverykey, delivery) {
                if (deliverykey === 0 && itemkey === 0) {

                  $.each(json.Items[itemkey], function(key, item) {
                    if (structure.items.split(',').indexOf(key) === -1) itemkeys.push(key);
                  });

                  $.each(json.Deliveries[deliverykey], function(key, item) {
                    if (structure.deliveries.split(',').indexOf(key) === -1) itemkeys.push(key);
                  });
                }

                //item line
                if (item.ItemNr === delivery.Posnr) {
                  var line = [];

                  $.each(item, function(a, b) {
                    if (structure.items.split(',').indexOf(a) === -1) line.push(self._format(b));
                  });

                  $.each(delivery, function(c, d) {
                    if (structure.deliveries.split(',').indexOf(c) === -1) line.push(self._format(d));
                  });

                  itemlines.push('"' + line.join('","') + '"');
                }
              });
            }
          });

          $.each(json.Items, function(itemkey, item) {
            if (parseInt(item.HighItmNr) === 0) {
              $.each(json.ScheduleLines, function(schedulekey, schedule) {
                if (schedulekey === 0 && itemkey === 0) {

                  $.each(json.Items[itemkey], function(key, item) {
                    if (structure.items.split(',').indexOf(key) === -1) schedulekeys.push(key);
                  });

                  $.each(json.ScheduleLines[schedulekey], function(key, item) {
                    if (structure.schedule.split(',').indexOf(key) === -1) schedulekeys.push(key);
                  });
                }

                //item line
                if (item.ItemNr === schedule.ItemNr) {
                  var line = [];

                  $.each(item, function(a, b) {
                    if (structure.items.split(',').indexOf(a) === -1) line.push(self._format(b));
                  });

                  $.each(schedule, function(c, d) {
                    if (structure.schedule.split(',').indexOf(c) === -1) line.push(self._format(d));
                  });

                  schedulelines.push('"' + line.join('","') + '"');
                }
              });
            }
          });
        } catch (e) {

        }

        out.push('\nDeliveries')
        out.push('"' + itemkeys.join('","') + '"');
        out.push(itemlines.join('\n'));
        out.push('\nSchedule Lines')
        out.push('"' + schedulekeys.join('","') + '"');
        out.push(schedulelines.join('\n'));
        return out.join('\n');
      },
      /**
       * This saves the new Item quantity from the item quantity dialog.
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_onItemQtyConfirm
       * @param  {sap.ui.base.Event} oEvent The event object
       */
      //BOC-C001/C008
      _onItemQtyConfirm: function(oEvent) {
        var oSource = oEvent.getSource();
        var path = oSource.getBindingContext('orders').getPath();
        var line = this.getModel('orders').getProperty(path);
        var order = line.OrderNr;
        var DocType = line.DocType;
        var SoldTo = line.SoldTo;
        var conSO = order + '*' + DocType + '*' + SoldTo;
        this.resetMessagePopover();

        var item = this.getModel('orders').getProperty(this.qty.path);
//BOC - C005
        if (this.doctype === "ZRE" || this.doctype === "ZCR") {
//EOC - C005
          var updQty = oEvent.getParameter('value');
          var numupd = Number(updQty);
          if (numupd !== 0) {
            var preQty = item.InvoiceQuantity;
            var numpqty = Number(preQty);
            if (numupd <= numpqty) {
              if (item.SalesQuantity !== oEvent.getParameter('value')) {
                this.byId('idSOItemsTable').setBusy(true);
                var data = this._getItemStructure({
                  SalesQuantity: oEvent.getParameter('value')
                }, item);
                oEvent.getSource().close();
                this.getView().removeDependent(oEvent.getSource());
                data.OrderNr = conSO;
                var itempath = "/SalesOrderItemSet(OrderNr='" + data.OrderNr + "',ItemNr='" + data.ItemNr + "')";
                this.getModel('orders').update(itempath, data, {
                  success: this._onUpdateItemSuccess.bind(this),
                  error: this._onUpdateItemError.bind(this)
                });

              } else {
                MessageToast.show('Quantity is not different');
              }
            } else {
              MessageToast.show('Quantity should not be greater than Invoice Quantity');
            }

          } else {
            MessageToast.show('Quantity should be more than 0');
          }
        } else {
          this.resetMessagePopover();
          var item = this.getModel('orders').getProperty(this.qty.path);

          if (item.SalesQuantity !== oEvent.getParameter('value')) {

            this.byId('idSOItemsTable').setBusy(true);
            var data = this._getItemStructure({
              SalesQuantity: oEvent.getParameter('value')
            }, item);
            oEvent.getSource().close();
            this.getView().removeDependent(oEvent.getSource());
              data.OrderNr = conSO;
            var itempath1 = "/SalesOrderItemSet(OrderNr='" + data.OrderNr + "',ItemNr='" + data.ItemNr + "')";
            this.getModel('orders').update(itempath1, data, {
              success: this._onUpdateItemSuccess.bind(this),
              error: this._onUpdateItemError.bind(this)
            });
          } else {
            MessageToast.show('Quantity is not different');
          }
        }
        oEvent.getSource().close();
        this.getView().removeDependent(oEvent.getSource());
        this._buttonStatus();
      },

      //EOC-C001/C008
      onUpdateHeaderCancelButton: function() {
        this.header.close();
      },
//EOC-C007
      /**
       * Method used to delete items from the order.
       *
       * @method
       * @name   encollab.dp.orders.Detail#onDeleteItemPress
       * @param  {sap.ui.base.Event} oEvent The event object
       */
      // BOC-C007
    onDeleteItemPress: function(oEvent) {
         var oSource = oEvent.getSource();
         var path = oSource.getBindingContext('orders').getPath();
         var line = this.getModel('orders').getProperty(path);
         var order = line.OrderNr;
         var DocType = line.DocType;
         var SoldTo = line.SoldTo;
          var conSO = order + '*' + DocType + '*' + SoldTo;
        this.byId('idSOItemsTable').setBusy(true);
        this.getModel('orders').setUseBatch(false);
        var items = this.byId('idSOItemsTable').getAggregation('items');
        var column = (this.byId('idSOItemsTable').getColumns().length - 1);
        var itemString = [];

        for (var i = 0; i < items.length; i++) {
          if (items[i].getAggregation('cells')[column].getSelected()) {
            itemString.push(items[i].getBindingContext('orders').getObject().ItemNr.toString().trim());
          }
        }
        if (itemString.length > 0) {
          this.getModel('orders').callFunction("/RemoveMultipleOrderLines", {
            method: 'POST',
            urlParameters: {
              Order: conSO,
              Items: itemString.join(',')
            },
            success: this._onDeleteItemSuccess.bind(this),
            error: this._onDeleteItemError.bind(this)
          });
        }

        this._resetItemCheckboxes();
      },
      //EOC-C007
      _resetItemCheckboxes: function() {
        var items = this.byId('idSOItemsTable').getAggregation('items');
        var column = (this.byId('idSOItemsTable').getColumns().length - 1)
        for (var i = 0; i < items.length; i++) {
          items[i].getAggregation('cells')[column].setSelected(false);
        }
      },
      _onUpdateHeaderSuccess: function(data) {
        this.getView().setBusy(false);
        MessageToast.show('SalesOrder ' + data.OrderNr + ' Created succesfully ');

        this.myRouter.navTo("ordersdetail", {
          orderPath: data.OrderNr
        });

        this._buttonStatus();
      },

      _onUpdateHeaderError: function(data) {
        var text = JSON.parse(data.responseText).error.message.value;
        MessageToast.show('Error updating order, see info messages.');
        //this.errorMessage('Error updating order', text);
        this.gatewayError(data);
        this.getView().setBusy(false);
        this._buttonStatus();
      },
      /**
       * Callback used when an item is sucsesfully updated
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_onUpdateItemSuccess
       * @param  {object} data Data return from the odata service
       */
      _onUpdateItemSuccess: function(data) {
        this.getModel('orders').setUseBatch(true);
        this.byId('idSOItemsTable').setBusy(false);
        this.qty = this.plant = {};
        this.getModel('orders').refresh(true);
        MessageToast.show('Order succesfully updated');
        this._buttonStatus();

      },
      /**
       * Callback used when an item update encountered an error
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_onUpdateItemError
       * @param  {object} data Data return from the odata service
       */
      _onUpdateItemError: function(data) {
        this.getModel('orders').setUseBatch(true);
        this.byId('idSOItemsTable').setBusy(false);
        this.qty = this.plant = {};
        MessageToast.show('Error updating order, see info messages.');
        this.gatewayError(data);

        this._buttonStatus();
      },
      /**
       * Callback used when an item delete was succesful
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_onDeleteItemSuccess
       * @param  {object} data Data return from the odata service
       */
      _onDeleteItemSuccess: function() {
        this.getView().setBusy(false);
        this.byId('idSOItemsTable').setBusy(false);
        this.getModel('orders').refresh(true);
        MessageToast.show('Items succesfully deleted');
        this._buttonStatus();
      },
      /**
       * Callback used when an item update encountered an error
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_onDeleteItemError
       * @param  {object} data Data return from the odata service
       */
      _onDeleteItemError: function(data) {
        MessageToast.show('Could not delete item, see info messages');
        this.gatewayError(data);
        this.getModel('orders').refresh(true);
        this.getView().setBusy(false);
        this.byId('idSOItemsTable').setBusy(false);
        this._buttonStatus();
      },
      /**
       * Callback used when an item creation encountered an error
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_onCreateItemError
       * @param  {object} data Data return from the odata service
       */
      _onCreateItemError: function(data) {
        this.byId('idSOItemsTable').setBusy(false)
        var text = JSON.parse(data.responseText).error.message.value;
        MessageToast.show('Could not create item, see info messages');
        this.errorMessage('Could not create item', text);

        this._buttonStatus();
      },
      /**
       * Callback used when an item create was succesful
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_onCreateItemSuccess
       * @param  {object} data Data return from the odata service
       */
     	//BOC-C007
      _onCreateItemSuccess: function(data) {
        this.byId('idSOItemsTable').setBusy(false);

        //multiple
        if (data.Items) {
          MessageToast.show('Items succesfully added to order ' + data.OrderNr);
        } else {
          MessageToast.show('Item ' + parseInt(data.ItemNr) + ', material ' + data.Material + ' succesfully added');
        }
        this.getModel('orders').refresh(true);
        var data1 = data.OrderNr;
        data1 = encodeURIComponent(data1);
        //  console.log(encodeURIComponent(data1));
        this.myRouter.navTo("ordercall", {
          orderPath: data1,
           DocType: encodeURIComponent(data.DocType),
           SoldTo:encodeURIComponent(data.SoldTo)
        });

      this._buttonStatus();
      },
      //EOC-C007
      /**
       * Callback used when an item create was succesful
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_getItemStructure
       * @param  {object} data Optional, prepopulate the item structure with fields from this object
       * @param  {object} item Optional, custom extension of the item structure
       * @return {object} Item
       */
      _getItemStructure: function(data, item) {
        if (typeof item === 'undefined') {
          item = {
            OrderNr: this.order,
            ItemNr: '000000',
            Material: '',
            MaterialGroup: "",
            SalesQuantity: "0.00",
            SalesUoM: "",
            NetPrice: "0.00",
            Currency: "",
            Plant: ""
          }
        }
        return $.extend({}, item, data);
      },
      /**
       * Gets the default order structure.
       *
       * @method
       * @private
       * @name   encollab.dp.orders.Detail#_getOrderStructure
       * @return {object} Order
       */
      _getOrderStructure: function() {
        return {
          OrderNr: this.order,
          DocType: "",
          DocDate: new Date(),
          CreatedDate: new Date(),
          CreatedBy: "",
          SoldTo: "",
          ShipTo: "",
          PaymentTerms: "",
          IncoTerms1: "",
          IncoTerms2: "",
          Reference: "",
          OrderStatus: "",
          OrderStatusDescr: "",
          Items: []
        }
      },
      /**
       * Navigates back to the Orders Enquiry
       *
       * @method
       * @name   encollab.dp.orders.Detail#onNavBack
       */
      onNavBack: function() {
        Controller.prototype.onNavBack.apply(this, ["orders"]);
      },
      /**
       * Navigates to the Order Creation
       *
       * @method
       * @name   encollab.dp.orders.Detail#onCreatePress
       */
      onCreatePress: function() {
        this.myRouter.navTo("orderscreate");
      },
      /**
       * Releases the order by updating it to remove the delivery block
       *
       * @method
       * @name   encollab.dp.orders.Detail#onReleasePress
       */
      onReleasePress: function(oEvent) {
        this.resetMessagePopover();

        var data = this.getView().getModel('data').getProperty('/order');
        var path = this.getView().getBindingContext('orders').getPath();
        var data = this.getView().getBindingContext('orders').getProperty();
        var path = this.getView().getBindingContext('orders').getPath();
        if (data.DeliveryBlock === 'YP') {
          delete data.__metadata;
          delete data.Items;
          delete data.DocFlow;
          delete data.DocFlowSet;
          delete data.Changes;
          delete data.Deliveries;
          delete data.ScheduleLines;

          data.DeliveryBlock = '';
        //  BOC-C004
          this.getModel('orders').create('/SalesOrderSet', data, {
            success: this._onUpdateHeaderSuccess.bind(this),
            error: this._onUpdateHeaderError.bind(this)
          });
        //  EOC-C004
        }
      },

      /**
       * Opens a dialog to change the FP number.
       *
       * @method
       * @name   encollab.dp.orders.Detail#onFPChange
       */
      onFPChange: function(oEvent) {
        // create dialog
        this._oDialog = sap.ui.xmlfragment("encollab.dp.orders.detail.changeFakturPajak", this);
        this._oDialog.bindElement({
          model: 'orders',
          path: oEvent.getSource().getBindingContext('orders').getPath()
        });
        this.getView().addDependent(this._oDialog);
        this._oDialog.open();
      },
      /**
       * Updates a line item with an FP number from the dialog
       *
       * @method
       * @name   encollab.dp.orders.Detail#onFPDialogConfirm
       */
      onFPDialogConfirm: function(oEvent) {
        var oInput = this._findElementIn('newFP', this._oDialog.findElements(true));
        var sPath = oEvent.getSource().getBindingContext('orders').getPath();

        this.onDialogCancel(oEvent);
        this._performUpdate(sPath, {
            'FPNumbers': oInput.getValue()
          },
          function(odata, response) {
            this.busyDialog.close();
          }.bind(this)
        );
      },
      /**
       * Closes the current dialog window
       *
       * @method
       * @name   encollab.dp.orders.Detail#onDialogCancel
       */
      onDialogCancel: function(oEvent) {
        try {
          this._oDialog.close().destroy();
        } catch (err) {}
      },

      /**
       * Performs an update on the sales order. Use it by sending the current path for the Orders
       * service, the payloads and optionally, success and error callbacks.
       * @private
       * @name   encollab.dp.orders.Detail#_performUpdate
       * @param  {string} sPath    The path name of the thing to update
       * @param  {object} sPayload the payload to be send to the oData channel
       * @param  {function} fSuccess Optional, Success callback
       * @param  {function} fError   Optional, Error callback
       * @param  {boolean} noBusy   Optional, when set to false, do the update silently.
       */
      _performUpdate: function(sPath, sPayload, fSuccess, fError, noBusy) {
        this.resetMessagePopover();
        if (!noBusy) this.busyDialog.open();
        if (!fSuccess) {
          fSuccess = jQuery.proxy(function(odata, response) {
            this.getModel('orders').refresh();
            this.busyDialog.close();
          }, this);
        }
        if (!fError) {
          fError = jQuery.proxy(function(oError) {
            this.busyDialog.close();
            this.gatewayError(oError);
          }, this);
        }

        this.getModel('orders').update(sPath, sPayload, {
          merge: true,
          success: fSuccess,
          error: fError
        });
      },
      /**
       * This saves the new Item quantity from the item quantity dialog.
       *
       * @method
       * @name   encollab.dp.orders.Detail#_onItemQtyConfirm
       * @param  {sap.ui.base.Event} oEvent The event object
       */
      onNavigationConfirm: function(oEvent) {
        oEvent.getSource().getParent().close();
        this.getView().removeDependent(oEvent.getSource());
        this.myRouter.navTo("orderscreate");
      },

      onNavigationCancel: function(oEvent) {
        oEvent.getSource().getParent().close();
        this.getView().removeDependent(oEvent.getSource());
      },

      /**************************************************************
       *  Formatters
       **************************************************************/

      /**
       * Formatter, returns a more readable schedule line item number
       *
       * @method
       * @name   encollab.dp.orders.Detail#scheduleLineItem
       * @param  {string} val The value to be formatted
       * @return {string} Formatted value
       */
      scheduleLineItem: function(val) {
        if (val) {
          return this.formatter.removeLeadingZeroes(val.toString().substr(19, 4));
        }
      },
      /**
       * Formatter, better schedule line item number
       *
       * @method
       * @name   encollab.dp.orders.Detail#orderItem
       * @param  {string} val The value to be formatted
       * @return {string} Formatted value
       */
      orderItem: function(val) {
        if (val) {
          return this.formatter.removeLeadingZeroes(val.toString().substr(13, 6));
        }
      },
      /**
       * Formatter, schedule line item status
       *
       * @method
       * @name   encollab.dp.orders.Detail#ChangeState
       * @param  {string} val The value to be formatted
       * @return {string} Formatted value
       */
      ChangeState: function(val) {
        switch (val) {
          case 'D':
            return 'Error';
          case 'I':
            return 'Success';
        }
      },
      /**
       * Formatter, change visibility
       *
       * @method
       * @name   encollab.dp.orders.Detail#ChangeVisible
       * @param  {string} val The value to be formatted
       * @return {boolean}
       */
      ChangeVisible: function(val) {
        return (val === 'U') ? true : false;
      },
      /**
       * Formatter, changes the icon on changes
       *
       * @method
       * @name   encollab.dp.orders.Detail#ChangeIcon
       * @param  {string} val The value to be formatted
       * @return {icon}
       */
      ChangeIcon: function(val) {
        switch (val) {
          case 'D':
            return 'sap-icon://delete';
          case 'I':
            return 'sap-icon://add';
          case 'U':
            return 'sap-icon://accept';
        }
      },
      /**
       * Formatter, item quantity status. 0 is red, otherwise green
       *
       * @method
       * @name   encollab.dp.orders.Detail#quantityStatus
       * @param  {string} val The value to be formatted
       * @return {string} Success or Error
       */
      quantityStatus: function(val) {
        return (parseFloat(val) > 0) ? 'Success' : 'Error';
      },
      /**
       * Formatter, disable input boxes
       *
       * @method
       * @name   encollab.dp.orders.Detail#itemListEnabled
       * @param  {string} val The value to be formatted
       * @return {boolean}
       */
      itemListEnabled: function(val) {

        if (this.getModel('data').getProperty('/active') === false) return false;

        return (val === '000000') ? true : false;

      },
      /**
       * Formatter, status of item
       *
       * @method
       * @name   encollab.dp.orders.Detail#itemListStatus
       * @param  {string} val The value to be formatted
       * @return {string}
       */
      itemListStatus: function(nr) {
        if (parseInt(nr) && parseInt(nr) > 0) return 'TAPA';
      },
      /**
       * Formatter, shows two decimals if value is a number
       *
       * @method
       * @name   encollab.dp.orders.Detail#TwoDecimalsOrNothing
       * @param  {string} val The value to be formatted
       * @return {string} Formatter number
       */
      TwoDecimalsOrNothing: function(val) {
        return (parseFloat(val) === 0) ? '' : parseFloat(val).toFixed(2).toString();
      },

      superceededItem: function(val) {
        //debugger;
      },
      /**
       * Formatter, show item delete button or not
       *
       * @method
       * @name   encollab.dp.orders.Detail#itemDeleteButton
       * @param  {string} val The value to be formatted
       * @return {boolean}
       */
      itemDeleteButton: function(v1, v2) {
        return v1 === '000000' && v2 === true;
      },
      /**
       * Formatter, shows order type instead of generic title if available
       *
       * @method
       * @name   encollab.dp.orders.Detail#titlePicker
       * @param  {string} val The value to be formatted
       * @return {string}
       */
      titlePicker: function(title, orderType) {
        return (orderType) ? orderType : title;
      },

      /**
       * Formatter, sets the status of the delivery block field
       *
       * @method
       * @name   encollab.dp.orders.Detail#deliveryBlockStatus
       * @param  {string} val The value to be formatted
       * @return {string}
       */
      deliveryBlockStatus: function(status) {
        return (status && status.length > 0) ? 'Error' : 'Success';
      },
      /**
       * Formatter, shows price per all eaches
       *
       * @method
       * @name   encollab.dp.orders.Detail#pricePerEach
       * @param  {string} val The value to be formatted
       * @return {number} Total price
       */
      pricePerEach: function(price, qty) {
        return this.formatter.NumberWithThousandsSeparator(price * qty);
      },
      /**
       * Formatter, adds material entered vs material ordered
       *
       * @method
       * @name   encollab.dp.orders.Detail#Material
       * @param  {string} val The value to be formatted
       * @return {string}
       */
      Material: function(mat, entered) {
        return (mat !== entered) ? mat + ' (' + entered + ')' : mat;
      },
      /**
       * Formatter, checks if value is zero
       *
       * @method
       * @name   encollab.dp.orders.Detail#notZero
       * @param  {string} val The value to be formatted
       * @return {boolean}
       */
      notZero: function(val) {
        return parseInt(val) !== 0;
      },
      DeliveryNoteIcon: function(note) {
        return (note) ? 'sap-icon://accept' : 'sap-icon://decline';
      },
      DeliveryNoteStatus: function(note) {
        return (note) ? '#007833' : '#cc1919'
        return (note) ? sap.ui.core.ValueState.Success : sap.ui.core.ValueState.Error;
      }
    });
  });