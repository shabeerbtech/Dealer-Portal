sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function(JSONModel) {
	return JSONModel.extend("encollab.dp.orders.create.HeaderModel", {
		constructor: function(opt) {
			this.opt =  opt || {};
			JSONModel.prototype.constructor.call(this, this._getDefaultStructure());
		},

		//jeepers... i hate ui5 form validation. why not use the default html5 input 
		//thingo's. 
		_getDefaultStructure: function() {
			return {
				order: $.extend({
					OrderNr: "",
					DocType: "ZRO1",
					DocDate: new Date(),
					CreatedDate: new Date(),
					CreatedBy: "",
					SoldTo: "",
					ShipTo: "",
					PaymentTerms: "",
					IncoTerms1: "",
					IncoTerms2: "",
					Reference: "",
					OrderStatus: "",
					OrderStatusDescr: "",
					DeliveryBlock: '',
					DeliveryBlockDescr: '',
					PaymentTermsDescr: ''

				}, this.opt),
				valid: true
			}
		}
	});
});