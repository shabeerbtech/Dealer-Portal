/**
 ****************************************************************************************
 *  Changed on:  Changed by:   Change ID:  TR Number:        Description:
 *  2017.10.30   Subha          C001/C002  GKAK907884/86     onSave space validation
 *  2017.11.02   Shabeer        C003       GKAK907892/7968   PCR - 19 Added ZCR Order Type
 *  2018.01.03   Subha          C004       GKAK908255         PCR4- reference date change
 *  2018.01.04   Subha          C005       GKAK908259         Reference length validation
 *  2018.01.10   Subha          C006       GKAK908267         PCR4-Special char with PO NUMBER
 *  2018.01.24   subha          C007       GKAK908333         PO&ORDERTYPE&SOLDTO
 *****************************************************************************************
 */

sap.ui.define([
    "encollab/dp/BaseController",
    "encollab/dp/orders/create/HeaderModel",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel"
  ],
  /**
   * <p>This is the controller for the page that handles Order Creation. It only presents a few fields as defined in HeaderModel that
   * corrensponds to the actual order model. It presents two extra fields and a look up for Invoices when choosing a Return Order. </p>
   * <h4>OData services used</h4>
   * <ul>
   * <li>Orders</li>
   * <li>Core</li>
   * </ul>
   * <h4>Templates used</h4>
   * <ul>
   * <li>encollab.dp.order.Create.view.xml</li>
   * <li>encollab.dp.order.create.invoiceDialog.fragment.xml</li>
   * </ul>
   * @class Create
   * @memberOf encollab.dp.orders
   * @extends {encollab.dp.BaseController}
   * @param  {encollab/dp/BaseController} Controller   Encollab base controller
   * @param  {encollab/dp/orders/create/HeaderModel} HeaderModel  Order create header model
   * @param  {sap/ui/model/Filter} Filter       
   * @param  {sap/ui/model/FilterOperator} Operator     
   * @param  {sap/m/MessageToast} MessageToast 
   * @param  {sap/ui/model/json/JSONModel} JSONModel    
   * @return {encollab.dp.orders.Create}              Order Create controller
   */
  function(Controller, HeaderModel, Filter, Operator, MessageToast, JSONModel) {
    "use strict";
    return Controller.extend("encollab.dp.orders.Create", {
      /**
       * This array holds the user parameters required to run this controller. In this case, the user has to be set up
       * with SPA, VKO, VTW (the entire sales area), and WRK (plant)
       *
       * @private
       * @member
       * @name   encollab.dp.orders.Create#_userParameters
       */
      _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],

      _loaded: 0,

      /**
       * Initialisation method. executes a method if the route "orderscreate" is matched. See method _onObjectMatch.
       *
       * @method
       * @name   encollab.dp.orders.Create#onInit
       */
      onInit: function() {
        Controller.prototype.onInit.apply(this, arguments);

        //this.myRouter.getTargetHandler().setCloseDialogs(false);
        this.myRouter.getRoute("orderscreate").attachPatternMatched(this._onObjectMatched, this);
      },

      /**
       * <p>This is executed if the route name is "objectcreate", which corresponds to view Create.view.xml</p>
       * <p>
       * It is also fetching, from the orders and core services, to populate the available search helps:
       * <ul>
       * <li>Document types</li>
       * <li>Payment terms</li>
       * <li>Inco terms</li>
       * <li>Order reasons</li>
       * <li>Allocated dealers for sold-to and ship-to party</li>
       * <li></li>
       * </ul>
       * </p>
       * @method
       * @name   encollab.dp.orders.Create#_onObjectMatched
       */
      _onObjectMatched: function() {

        this.getView().setModel(this._getModel(), 'data');

        this.getView().setBusy(true);

        this.getModel('orders').setUseBatch(false)

        //struggled to properly filter the silly odata models. now moving relevant data to a JSON
        //model. This is probably better anyway, to reduce data load. 
        this.getModel('orders').read('/DocTypeSet', {
          success: function(ord) {
            this.getView().getModel('data').setProperty('/DocTypes', ord.results);
            this._checkDone();
          }.bind(this)
        });

        this.getModel('orders').read('/IncoTermsSet', {
          success: function(ord) {
            this.getView().getModel('data').setProperty('/IncoTerms', ord.results);
            this._checkDone();
          }.bind(this)
        });

        this.getModel('orders').read('/PaymentTermsSet', {
          success: function(ord) {
            this.getView().getModel('data').setProperty('/PaymentTerms', ord.results);
            this._checkDone();
          }.bind(this)
        });

        this.getModel('orders').read('/OrderReasons', {
          filters: [
            new Filter('OrderReasonCode', Operator.StartsWith, 'Z')
          ],
          success: function(ord) {
            this.getView().getModel('data').setProperty('/OrderReasons', ord.results);
            this._checkDone();
          }.bind(this)
        });

        this.getModel('core').read('/Users(\'SY-UNAME\')/Dealers', {
          success: function(ord) {
            this.getView().getModel('data').setProperty('/Dealers', ord.results);
            this.getView().getModel('data').setProperty('/order/SoldTo', ord.results[0]);
            this._checkDone();
          }.bind(this)
        });
      },
      /**
       * This sets the header model holding the data stored on the creation model, which is going to be sent to SAP
       * @name  encollab.dp.orders.Create#_getModel
       * @private
       * @method
       */
      _getModel: function() {
        return new HeaderModel({
          SalesOrg: this.myComponent.getMySettingValue('VKO'),
          DistributionChannel: this.myComponent.getMySettingValue('VTW'),
          Division: this.myComponent.getMySettingValue('SPA'),
          //BOC-C004
          Reference: this._getDateString(new Date()),
          //EOC-C004
        });
      },
      /**
       * This checks wether or not all search helps have been populated.
       * @name  encollab.dp.orders.Create#_checkDone
       * @private
       * @method
       */
      _checkDone: function() {
        if (
          this.getView().getModel('data').getProperty('/Dealers') &&
          this.getView().getModel('data').getProperty('/IncoTerms') &&
          this.getView().getModel('data').getProperty('/PaymentTerms') &&
          this.getView().getModel('data').getProperty('/OrderReasons') &&
          this.getView().getModel('data').getProperty('/DocTypes')) {

          this.getView().setBusy(false);
        }
      },
      /**
       * Method that is fired on using the invoice search help. It opens a dialog box that will allow the user 
       * to search for billing documents. 
       * @method
       * @name   encollab.dp.orders.Create#_checkDone
       * @param  {object} oController 
       */
      handleValueHelp: function(oController) {
        this.inputId = oController.oSource.sId;
        // create value help dialog
        if (!this._valueHelpDialog) {
          this._valueHelpDialog = sap.ui.xmlfragment("encollab.dp.orders.create.invoiceDialog", this);
          this.getView().addDependent(this._valueHelpDialog);
        }
        // open value help dialog
        this._valueHelpDialog.open();
      },
      /**
       * Method that filters the invoice data binding, found on the orders odata model, by the search value the user entered in the box. 
       * It searches by Document# or Reference. 
       * to search for billing documents. 
       * @method
       * @name   encollab.dp.orders.Create#_handleValueHelpSearch
       * @param  {sap.ui.base.Event} oEvent The event object 
       */
      _handleValueHelpSearch: function(evt) {
        var sValue = evt.getParameter("value");
        var oFilter = [
          new Filter("Document", Operator.Contains, sValue),
          new Filter("Reference", Operator.Contains, sValue),
        ];
        evt.getSource().getBinding("items").filter(new Filter(oFilter, false));
      },
      /**
       * Closes the invoice search help. If an item was clicked, it's copied into the appropriate field. 
       * to search for billing documents. 
       * @method
       * @name   encollab.dp.orders.Create#_handleValueHelpClose
       * @param  {sap.ui.base.Event} oEvent The event object 
       */
      _handleValueHelpClose: function(evt) {
        var oSelectedItem = evt.getParameter("selectedItem");
        if (oSelectedItem) {
          var productInput = this.getView().byId(this.inputId);
          productInput.setValue(oSelectedItem.getCells()[0].getText());
        }
        evt.getSource().getBinding("items").filter([]);
      },
      /**
       * Used to set the status of an input field to error if it's empty. 
       * @method
       * @name   encollab.dp.orders.Create#valueState
       * @param  {string} state
       */
      valueState: function(state) {
        var empty = (state === null || typeof state === 'undefined' || state === '');

        return empty ? 'Error' : 'None';
      },
      /**
       * This saves the order based on the data saved into the header model by the user. Errors will be reported, when succesful
       * it will navigate to the newly created order. 
       * @name   encollab.dp.orders.Create#onSave
       * @method
       */
      onSave: function() {
        this.resetMessagePopover();
        var data = this.getView().getModel('data').getProperty('/order');
        //BOC-C001/C002

        var space = data.Reference;
        // BOC-C005
            if(space.length <= 20){
        var a = space.trim();
        var b = space.split(" ");

        if (b.length > 1) {
          MessageToast.show('Space are not allowed in Reference');
          return false;
        } else {
//BOC - C003
          if (data.DocType === 'ZRE' || data.DocType === 'ZCR') {
//EOC - C003
            data.OrderNr = this.byId('idCreateOrderInvoice').getValue();
          }
          this.getView().setBusy(true);
          this.getModel('orders').create('/SalesOrderSet', data, {
            success: this._onCreateSuccess.bind(this),
            error: this._onCreateError.bind(this)
          });
        }
         } else{
              MessageToast.show("Reference number contains more than 20 characters");
          return false;
        }
      },
      //EOC-C001/C002/C005.
      /**
       * Method to set the document type when selected. It's relevance is based on wether the order is a return or not. 
       * @name   encollab.dp.orders.Create#onDocTypeSelect
       * @method
       */
      onDocTypeSelect: function(oEvent) {
//BOC - C003
        if (this.getModel('data').getProperty('/order/DocType') !== 'ZRE' || this.getModel('data').getProperty('/order/DocType') !== 'ZCR') {
//EOC - C003
          this.getModel('data').setProperty('/order/OrderStatus', '');
        }
      },
      /**
       * When cancelling creating an order, move to the screen that came before. 
       * @name   encollab.dp.orders.Create#onSave
       * @method
       */
      onCancel: function() {
        this.onNavBack();
      },

      onTitleSelectorPress: function() {
        this.header.open();
      },
      /**
       * When the sold-to changes, also change the ship-to if it's empty. 
       * @name   encollab.dp.orders.Create#onSoldToChange
       * @method
       */
      onSoldToChange: function() {
        if (this.byId('idShipToDefault').getSelected() === true) {
          var soldTo = this.getView().getModel('data').getProperty('/order/SoldTo');
          this.getView().getModel('data').setProperty('/order/ShipTo', soldTo);
          this.byId('idCreateShipTo').setSelectedKey(soldTo);
        }
      },
      /**
       * When inco terms are selected, inco terms 2 is displayed and it's validity is checked. 
       * @name   encollab.dp.orders.Create#onIncoTermsChange
       * @method
       */
      onIncoTermsChange: function(oEvent) {
        var inco1 = this.getView().getModel('data').getProperty('/order/IncoTerms1');
        var inco2 = this.byId('idCreateIncoTerms2').getValue();
        if (inco1 !== '' && inco2 === '') {
          this.byId('idCreateIncoTerms2').setValueState("Error");
          this.getView().getModel('data').setProperty('/valid', false);
        } else {
          this.byId('idCreateIncoTerms2').setValueState("None");
          this.getView().getModel('data').setProperty('/valid', true);
        }
      },
      /**
       * If ship-to is not the same as sold-to, we're separating the checks, and ship-to will need to be set 
       * by the user. 
       * @name   encollab.dp.orders.Create#onShipToDefault
       * @method
       */
      onShipToDefault: function(oEvent) {
        this.byId("idCreateShipTo").setVisible(!oEvent.getSource().getSelected());
        if (oEvent.getSource().getSelected() === true) {
          var soldTo = this.getView().getModel('data').getProperty('/order/SoldTo');
          this.getView().getModel('data').setProperty('/order/ShipTo', soldTo);
          this.byId('idCreateShipTo').setSelectedKey(soldTo);
        } else {
          this.getView().getModel('data').setProperty('/order/ShipTo', '');
        }
      },
      onCreateButton: function() {
        this.getView().setBusy(true);
        this.getModel('orders').create('/SalesOrderSet', this.header.getModel('data').getData(), {
          success: this._onCreateSuccess.bind(this),
          error: this._onCreateError.bind(this)
        });
        this.header.close();
      },
      /**
       * Closes the header. 
       * @name   encollab.dp.orders.Create#onCancelButton
       * @method
       */
      onCancelButton: function() {
        this.header.close();
      },

      /**
       * If incoterms1 is not empty, show incoterms2
       * by the user. 
       * @name   encollab.dp.orders.Create#isIncoTerms2Visible
       * @method
       */
      isIncoTerms2Visible: function(value) {
        return value !== null;
      },
      /**
       * Handles the error on oData failure
       * @private
       * @name   encollab.dp.orders.Create#_onCreateError
       * @method
       */
      _onCreateError: function(data) {
        var text = JSON.parse(data.responseText).error.message.value;
        MessageToast.show('Order creation failed, see info messages');
        this.errorMessage('Order creation failed', text);
        this.getView().setBusy(false);

      },
      /**
       * Converts a date object into Y M D format
       * @private
       * @name   encollab.dp.orders.Create#_getDateString
       * @method
       */
      _getDateString: function(date) {
        var y = date.getFullYear();
        var m = ((date.getMonth() + 1) < 10) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1);
        var d = (date.getDate() < 10) ? "0" + date.getDate() : date.getDate();

        return y + m + d;
      },
      /**
       * On creation, navigate to the new order
       * @private
       * @name   encollab.dp.orders.Create#_onCreateSuccess
       * @method
       */
      //BOC-C006/C007
      _onCreateSuccess: function(data) {
          console.log(data);
        this.getView().setBusy(false);
         var data1 = data.Reference;
        data1 = encodeURIComponent(data1);
        MessageToast.show('Order ' + data.OrderNr + ' succesfully created.');
        this.myRouter.navTo("ordercall", {
          orderPath: data1,
           DocType:encodeURIComponent(data.DocType),
           SoldTo:encodeURIComponent(data.SoldTo)
        });
        //EOC-C006/C007
      }
    });
  });