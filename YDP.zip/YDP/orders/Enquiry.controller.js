// ******************************************************************************************************
// *  Changed on:  Changed by:   Change ID:  TR Number:        Description:
// *  2017.10.17   Subha         C001        GKAK907751          Link enable & disable in Ordernr & PO Number
// *  2018.01.10   Subha         C002        GKAK908267          Special char with PO ENCODE
// *  2018.01.24   Subha         C003        GKAK908333          Key Changes
// *  2018.01.31   Nisha         C004        GKAK908349          Duplication of items in sale order selection
// *  2018.02.02   SUBHA         C004        GKAK908349          item count in header
// *  2018.02.20   Nisha         C005        GKAK908360/GKAK908364  Net price correction
// ********************************************************************************************************
sap.ui.define([
        "encollab/dp/BaseController",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/Sorter",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/format/DateFormat"
    ],
  /**
   * <p>Order Enquiry controller, the methods in this class look after searching orders</p>
   * <h4>OData services used</h4>
   * <ul>
   * <li>Orders</li>
   * </ul>
   * <h4>Templates used</h4>
   * <ul>
   * <li>encollab.dp.orders.Enquiry.view.xml</li>
   * </ul>
   * @class Enquiry
   * @memberOf encollab.dp.orders
   * @extends {encollab.dp.BaseController}
   * @param  {encollab.dp.BaseController} Controller
   * @param  {sap.ui.movel.Filter} Filter
   * @param  {sap.ui.model.FilterOperator} FilterOperator
   * @param  {sap.ui.model.Sorter} Sorter
   * @param  {sap.ui.model.json.JSONModel} JSONModel
   * @param  {sap.ui.core.format.DateForms} DateFormat
   * @return {encollab.dp.orders.Enquiry}
   */
  function(Controller, Filter, FilterOperator, Sorter, JSONModel, DateFormat) {

    "use strict";

    return Controller.extend("encollab.dp.orders.Enquiry", {
      /**
       * List of user parameters required to search for orders
       * @name   encollab.dp.orders.Detail#_userParameters
       * @type {array<string>}
       * @member
       */
      _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
      /**
       * Holds all the activate calls
       * @name   encollab.dp.orders.Detail#_activeCalls
       * @type {array<function>}
       * @member
       */
      _activeCalls: [],
      /**
       * placeholder for the right formatting function
       * @name   encollab.dp.orders.Detail#_prepare
       * @type {function}
       * @member
       */
      _prepare: null,

      /**
       * On initialization, this method sets up a local model to hold the results of the search. Orders are fetched based
       * on a date range, further filtering and sorting is done on this local JSON model instead of on the oData service.
       *
       * @method
       * @name   encollab.dp.orders.Detail#onInit
       */
      onInit: function() {
        Controller.prototype.onInit.apply(this, arguments);
      this.myRouter.getRoute("orders").attachPatternMatched(this._onObjectMatched, this);
        this.model = new JSONModel({
          count: 0,
          orders: [],
          price: 0,
          priceuom: 'IDR',
          table: 'ordersTableHeader'
        });

        this.setModel(this.model, 'data');

        this._prepare = this._prepareHeaderResults;
        this._ordersTable = this.byId('ordersTableHeader');
        this.byId('ordersTableDetail').setVisible(false);

      },

      /**
       * Sets up the dates and initializes a search when the route "orders" is matched
       * @name   encollab.dp.orders.Detail#_onObjectMatched
       * @method
       * @param  {sap.ui.base.Event} oEvent
       */
      _onObjectMatched: function(oEvent) {
        var dates = this.byId('ordersSearchBar').getDateRange();
        this._search(dates.first, dates.last);
              },
      /**
       * Adds a filter to the json data set up on the table
       * @name   encollab.dp.orders.Detail#onSearchFilter
       * @method
       * @param  {sap.ui.base.Event} oEvent
       */
      onSearchFilter: function(oEvent) {
        var searchString = oEvent.getParameter('filter');

        var binding = this._ordersTable.getBinding('rows');
        var filters = new Filter([
                    new Filter("Searcher", FilterOperator.Contains, searchString.toUpperCase())
                ], false);
        binding.filter(filters, sap.ui.model.FilterType.Control);
      },
      /**
       * Executes a new search on the oData channel when the date range changes
       * @name   encollab.dp.orders.Detail#onSearchSearch
       * @param  {sap.ui.base.Event} oEvent
       * @method
       */
      onSearchSearch: function(oEvent) {
        var firstDate = oEvent.getParameter('first');
        var lastDate = oEvent.getParameter('last');
        this._search(firstDate, lastDate);
      },
      /**
       * Switches between display order header data only, or order and line item data
       * @name   encollab.dp.orders.Detail#onTypeSelect
       * @param  {sap.ui.base.Event} oEvent
       * @method
       */
      onTypeSelect: function(oEvent) {
        this._ordersTable.setVisible(false);
        switch (oEvent.getParameter('key')) {
          case 'l':
            this._ordersTable = this.byId('ordersTableDetail');
            this._prepare = this._prepareResults;
            break;
          case 'h':
            this._ordersTable = this.byId('ordersTableHeader');
            this._prepare = this._prepareHeaderResults;
            break;
        }
        this._ordersTable.setVisible(true);
        var dates = this.byId('ordersSearchBar').getDateRange();
        this._search(dates.first, dates.last);
      },
      /**
       * Performs the actual search on the oData channel. It does several things:
       * <ul>
       * <li>Cancels all current active calls to the odata model</li>
       * <li>Adds filters for the first and last date in the range</li>
       * <li>On success, sends results to the proper formatter.</li>
       * </ul>
       * @name   encollab.dp.orders.Detail#_search
       * @param  {date} firstDate
       * @param  {date} lastDate
       * @method
       */
      _search: function(firstDate, lastDate) {
        this._ordersTable.setBusy(true);
        //cancel all active calls

        $.each(this._activeCalls, function(i, a) {
          a.call();
        });

        var filters = [
                    new Filter('CreatedDate', FilterOperator.BT, firstDate, lastDate)
                ]

        this.getModel('orders').setUseBatch(false);

        //push the current active call's ABORT function into the active calls.
        this._activeCalls.push(this.getModel('orders').read('/SalesOrderSearchSet', { //SalesOrderSet
          filters: filters,
          sorters: [
                        new Sorter('CreatedDate', true, false)
                    ],
          urlParameters: {
            '$top': 999999,
            //'$expand': 'ItemsSimple',
            '$format': 'json'
          },
          success: function(data) {
            //set active calls to nothing.
            this._activeCalls = [];
            this.model.setProperty('/orders', this._prepare(data.results));
            this._ordersTable.setBusy(false);
            this.getModel('orders').setUseBatch(true);
          }.bind(this)
        }).abort);
      },
      /**
       * Formats data with line items. In order to do the local search, and in order to get the sorters right,
       * some values are converted to strings that are actually numbers, and it converts dates from JS Date objects
       * to formatter strings. It also creates a field that is not displayed called 'searcher' to make filtering later easier.
       * @name   encollab.dp.orders.Detail#_prepareResults
       * @param  {object} data
       * @return {object}
       * @method
       */
       //BOC-C003
      _prepareResults: function(data) {
        this.unformatted = data;
        var items, item, fp, value = 0,
          uom, d = {},
          newData = [];

        data = data.sort(function(a, b) {
          return (b.OrderNr - a.OrderNr) - (b.PosnNr - a.PosnNr);
        });
        for (var i = 0; i < data.length; i++) {
          if (data[i].ItemNr !== "000000") {
          d = data[i];
                  // BOC-C001
          d.OrderNr = d.OrderNr;
        //  EOC-C001
          d.NetPrice = parseInt(d.NetPrice);
          d.NetPriceItem = parseInt(d.NetPriceItem);
          d.SalesQuantity = parseInt(d.SalesQuantity);

          d.Searcher = [
                        d.OrderNr.toString(),
                        this.formatter.ShortDate(data[i].CreatedDate),
                        d.CreatedBy,
                        d.Reference,
                        d.NetPrice.toString(),
                        d.Material,
                        d.MaterialDescr,
                        d.FPNumbers,
                        d.MaterialGroup,
                        d.MatGroupDesc,
                        d.SoldTo
                    ].join().toUpperCase();

          value += (d.DeliveryBlock == 'YP') ? 0 : parseInt(d.NetPrice);
          uom = d.DocumentCurrency;

          newData.push(d);
        }
        }
        newData = newData.sort(function(a, b) {
          return (b.OrderNr - a.OrderNr);
        });

        this.model.setProperty('/price', value);
        this.model.setProperty('/priceuom', uom);
        this.model.setProperty('/count', newData.length + ' Order lines found');
        this.model.setProperty('/table', 'ordersTableDetail');

        return newData;
      },
      /**
       * Formats data as headers only. In order to do the local search, and in order to get the sorters right,
       * some values are converted to strings that are actually numbers, and it converts dates from JS Date objects
       * to formatter strings. It also creates a field that is not displayed called 'searcher' to make filtering later easier.
       * @name   encollab.dp.orders.Detail#_prepareHeaderResults
       * @param  {object} data
       * @return {object}
       * @method
       */
      _prepareHeaderResults: function(data) {
        if (data.length === 0) return [];
        this.unformatted = data;
        var items, item, fp, value = 0,
          uom, d = {},
          newData = [];
//boc c004
        //data = data.sort(function(a, b) {
          //return (b.OrderNr - a.OrderNr);
        //});
//eoc c004
        d = data.shift();
        // BOC-C001
        d.OrderNr = d.OrderNr;
        d.Reference = d.Reference;
        d.NetPrice = parseInt(d.NetPrice);
        d.NumberOfItems = (d.ItemNr === "000000") ? 0 : 1;
        d.NumberOfParts = parseInt(d.SalesQuantity);
        d.NetPrice = parseInt(d.NetPrice);
        d.NetPriceItem = parseInt(d.NetPriceItem);
        d.SoldTo = d.SoldTo;
          d.DocType = d.DocType;
        uom = d.DocumentCurrency;
        for (var i = 0; i < data.length; i++) {
            if ((d.Reference === data[i].Reference) && (d.SoldTo === data[i].SoldTo) &&
            (d.OrderNr === data[i].OrderNr) && (d.DocType === data[i].DocType)){
                var test = data[i].ItemNr;
               //boc c005
              //d.NetPrice += parseInt(data[i].NetPrice);

               var lastDigit = test.toString().slice(-1);
               if ((d.OrderNr !== "") && (lastDigit !== '1') && data[i].ItemNr !== "000000")
               {
                   d.NetPrice = parseInt(data[i].NetPrice);
               }
            if (d.OrderNr === "") {
              d.NetPrice += parseInt(data[i].NetPrice);
            }
             //eoc c005
                //BOC-C004
                if ((data[i].ItemNr !== "000000") && (lastDigit !== '1')) {
                //EOC-C004
                  d.NumberOfItems += (d.ItemNr === "000000") ? 0 : 1;
                }
                if (lastDigit !== '1') {
                  d.NumberOfParts += parseInt(data[i].SalesQuantity);
                }
          }else {
            if ((d.OrderNr) || (d.OrderNr === '')){
              newData.push(d);
            }
            d = data[i];
            d.OrderNr = d.OrderNr;
            d.Reference =d.Reference;
            d.NetPrice = parseInt(d.NetPrice);
            d.NumberOfItems = (d.ItemNr === "000000") ? 0 : 1;
            d.NumberOfParts = parseInt(d.SalesQuantity);
            d.NetPrice = parseInt(d.NetPrice);
            d.NetPriceItem = parseInt(d.NetPriceItem);
            d.SoldTo = d.SoldTo;
              d.DocType = d.DocType;
                    //  EOC-C001
            d.Searcher = [
                            d.OrderNr.toString(),
                            this.formatter.ShortDate(data[i].CreatedDate),
                            d.CreatedBy,
                            d.Reference,
                            d.NetPrice.toString(),
                            d.Material,
                            d.MaterialDescr,
                            d.FPNumbers,
                            d.MaterialGroup,
                            d.MatGroupDesc,
                            d.SoldTo
                        ].join().toUpperCase();

            value += (d.DeliveryBlock == 'YP') ? 0 : d.NetPrice;
          }
        }
        newData.push(d);
        newData = newData.sort(function(a, b) {
          return (b.OrderNr - a.OrderNr);
        });

        this.model.setProperty('/price', (value + d.NetPrice));
        this.model.setProperty('/priceuom', uom);
        this.model.setProperty('/count', newData.length + ' Orders found');
        this.model.setProperty('/table', 'ordersTableHeader');

        return newData;
      },

      onSearchOrders: function(evt) {
        var string = evt.getSource().getValue();
        if (string.length && string.length > 3) {
          this.myRouter.navTo('ordersenquiry', {
            searchTerm: evt.getSource().getValue()
          });
        }
      },
      /**
       * When pressing an order number, navigates to the order detail screen
       * @name   encollab.dp.orders.Detail#onPress
       * @param  {sap.ui.base.Event} oEvent The event object
       * @method
       */
      onPress: function(oEvent) {
        var oItem = oEvent.getSource();

        this.myRouter.navTo("ordersdetail", {
          orderPath: oItem.getBindingContext('data').getProperty('OrderNr')
        });
      },
//      BOC-C001/C002
       onPressPO: function(oEvent) {
        var oItem = oEvent.getSource();
        this.myRouter.navTo("ordercall", {
          orderPath:encodeURIComponent(oItem.getBindingContext('data').getProperty('Reference')) ,
          DocType:encodeURIComponent(oItem.getBindingContext('data').getProperty('DocType')),
           SoldTo:encodeURIComponent(oItem.getBindingContext('data').getProperty('SoldTo'))
          });
                 },
//      EOC-C001/C002
      /**
       * When pressing the Order Create button, navigate to the order creation screen
       * @name   encollab.dp.orders.Detail#onCreatePress
       * @method
       */
      onCreatePress: function() {
        this.myRouter.navTo("orderscreate");
      },
      /**
       * Formatter. Shows an icon based on the presence of a delivery block
       * @name   encollab.dp.orders.Detail#onCreatePress
       * @param {string} deliveryBlock
       * @return {icon}
       * @method
       */
      submitted: function(deliveryBlock) {
        return (deliveryBlock !== 'YP') ? 'sap-icon://accept' : 'sap-icon://decline'
      },
      /**
       * Formatter. Sets the color of the 'submitted' icon.
       * @name   encollab.dp.orders.Detail#onCreatePress
       * @param {string} deliveryBlock
       * @return {string}
       * @method
       */
      submittedState: function(deliveryBlock) {
        return (deliveryBlock !== 'YP') ? 'Success' : 'Error'
      },
      /**
       * Formatter. Shows the order type or a generic title
       * @name   encollab.dp.orders.Detail#onCreatePress
       * @param {string} title
       * @param {string} orderType
       * @method
       */
      titlePicker: function(title, orderType) {
        return (orderType) ? orderType : title;
      }
    });
  });