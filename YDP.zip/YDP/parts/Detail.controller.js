sap.ui.define([
        "encollab/dp/BaseController",
        "sap/m/MessageToast"
    ],
    /**
     * <p>Here you'll find all methods and functions related to displaying a part</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Part</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.parts.Detail.view.xml <small>main view</small></li>
     * <li>encollab.dp.parts.PartHeader.fragment.xml</li>
     * <li>encollab.dp.parts.attachment.Attachment.fragment.xml</li>
     * <li>encollab.dp.parts.characteristics.characteristics.fragment.xml</li>
     * <li>encollab.dp.parts.component.Component.fragment.xml</li>
     * <li>encollab.dp.parts.dimensions.Dimensions.fragment.xml</li>
     * <li>encollab.dp.parts.inventory.Inventory.fragment.xml</li>
     * <li>encollab.dp.parts.supercession.SuperCessionListItem.js</li>
     * <li>encollab.dp.parts.supercessions.fragment.xml</li>
     * <li>encollab.dp.parts.superCessionsTemplate.fragment.xml</li>
     * </ul>
     * @class Detail
     * @memberOf encollab.dp.parts
     * @extends {encollab.dp.BaseController}
     * @return {encollab.dp.parts.Detail}
     * 
     * @param  {encollab.dp.BaseController} Controller
     * @param  {sap.m.MessageToast} MessageToast
     */
    function(Controller, MessageToast) {
        "use strict";
        return Controller.extend("encollab.dp.parts.Detail", {
            _userAuthorisations: ['PartEnquiry'],
            /**
             * This array holds the user parameters required to run this controller. In this case, the user has to be set up
             * with SPA, VKO, VTW (the entire sales area), and WRK (plant)
             *
             * @private
             * @member
             * @name   encollab.dp.parts.Detail#_userParameters
             */
            _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],

            /**
             * Initialization of the controller
             * @name   encollab.dp.parts.Detail#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);

                this.myRouter.getRoute("partsdetail").attachPatternMatched(this._onObjectMatched, this);
            },
            /**
             * If the current route is "partsdetail", bind an oData call to the current view, for the current material. 
             * Whenever data is received, it is formatted to the desired CSV layout for download. 
             * @name   encollab.dp.parts.Detail#_onObjectMatched
             * @param  {sap.ui.base.Event} oEvent The event object
             * @method
             */
            _onObjectMatched: function(oEvent) {

                this.myView.bindElement({
                    model: 'part',
                    path: "/Parts('" + oEvent.getParameter("arguments").partPath + "')",
                    parameters: {
                        expand: 'Supersession,Inventory,Attachments,Characteristics'
                    },
                    events: {
                        change: this._onBindingChange.bind(this),
                        dataRequested: function() {
                            this.getView().setBusy(true);
                        }.bind(this),
                        dataReceived: function(oEvent) {
                            this.getView().setBusy(false);
                            var path = this.getView().getBindingContext('part').getPath();
                            var data = this._expandElementBindingToData(path, this.getModel('part'));
                            var out = this._formatForDownload(data);
                            this.byId('idPartsButtonDownload').setData(out);
                        }.bind(this)
                    }
                });
            },
            /**
             * If the binding changes, check if there's actual data. Otherwise, the "Not Found" screen is displayed. Otherwise, 
             * some bindings have to be updated to reflect the new data
             * @name   encollab.dp.parts.Detail#_onBindingChange
             * @param  {sap.ui.base.Event} oEvent The event object
             * @method
             */
            _onBindingChange: function() {
                var oView = this.getView(),
                    oElementBinding = oView.getElementBinding('part');

                // No data for the binding
                if (!oElementBinding.getBoundContext()) {
                    oView.setBusy(false);
                    this.getRouter().getTargets().display("objectNotFound");
                    return;
                }

                this.byId('idSupercessionTable').updateBindings();

            },
            /**
             * Formatter. Goes through the supercession change and returns the role of the current material
             * @name   encollab.dp.parts.Detail#supercessionRole
             * @param  {string} matnr 
             * @return {string}       
             * @method
             */
            supercessionRole: function(matnr) {
                if (!matnr) {
                    return 'Unknown';
                }

                var oData = this.myView.getBindingContext('part');
                var aSupercessions = oData.getProperty('Supersession');
                var parent = oData.getProperty('PartID');

                if (parent === matnr) {
                    return 'Self';
                } else {
                    for (var i = 0; i < aSupercessions.length; i++) {
                        if (aSupercessions[i].match(matnr)) {
                            return 'Descendant'; //'Ancestor';
                        }
                        if (aSupercessions[i].PartID === oData.getProperty('PartID')) {
                            break;
                        }

                    }
                    return 'Ancestor'; //'Descendant';
                }
            },
            /**
             * Formatter. Goes through the supercession change and returns the position of the current material
             * @name   encollab.dp.parts.Detail#supercessionRole
             * @param  {string} matnr 
             * @return {string}       
             * @method
             */
            supercessionRole2: function(matnr) {
                if (!matnr) {
                    return 'Unknown';
                }

                var oData = this.myView.getBindingContext('part');
                var aSupercessions = oData.getProperty('Supersession');
                var parent = oData.getProperty('PartID');

                if (parent === matnr) {
                    return 'Self';
                } else {
                    if (aSupercessions[0].match(matnr)) {
                        return 'Top';
                    }
                    if (aSupercessions[aSupercessions.length - 1].match(matnr)) {
                        return 'Bottom';
                    }
                    return 'Unknown';
                }
            },
            /**
             * Formatter. Shows the age of the dealer entered stock levels
             * @name   encollab.dp.parts.Detail#stockAgeStatus
             * @param  {date} date 
             * @return {string}     
             * @method  
             */
            stockAgeStatus: function(date) {
                var diff = (new Date() - date) / (1000 * 60 * 60 * 24); // difference converted to days

                if (diff > 14) {
                    return 'Error'
                } else if (diff > 7) {
                    return 'Warning'
                }

                return 'Success'
            },
            /**
             * Formatter. Fetches a classname of the current material in the supercession chain
             * @name   encollab.dp.parts.Detail#stockAgeStatus
             * @param  {date} date 
             * @return {string}       
             * @method
             */
            supercessionText: function(matnr) {
                return this.getText('partsDetailSupercessionChain' + this.supercessionRole2(matnr));
            },
            /**
             * If a materialnumber is pressed, navigate to that material
             * @name   encollab.dp.parts.Detail#stockAgeStatus
             * @param  {date} date 
             * @return {string}       
             * @method
             */
            onMaterialPress: function(oEvent) {
                var oData = oEvent.getSource().getBindingContext('part').getObject();
                if (oData.PartID) {
                    this.myRouter.navTo("partsdetail", {
                        partPath: oData.PartID
                    });
                }
            },
            /**
             * Fetch the actual URL of an attachment. 
             * @name   encollab.dp.parts.Detail#attachmentURL
             * @param  {date} date 
             * @return {string}       
             * @method
             */
            attachmentURL: function(docid) {
                return this.getModel('part').sServiceUrl + "/Attachments('" + docid + "')/$value";
            },
            /**
             * Navigates back to the part enquiry screen
             * @name   encollab.dp.parts.Detail#onNavBack
             * @override
             * @param  {date} date 
             * @return {string}       
             * @method
             */
            onNavBack: function() {
                Controller.prototype.onNavBack.apply(this, ["parts"]);
            }
        });
    });