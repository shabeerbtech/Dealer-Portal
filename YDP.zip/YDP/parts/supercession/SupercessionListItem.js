sap.ui.define([
    "sap/m/ColumnListItem"
], function(ColumnListItem) {
    ColumnListItem.extend("encollab.dp.parts.supercession.SupercessionListItem", {
        metadata: {
            properties: {
                supercessionRole: {
                    type: "string",
                    defaultValue: "Ancestor"
                }
            }
        },

        renderer: {

            renderLIAttributes: function(rm, oLI) {
                rm.addClass("sapMListTblRow");
                var vAlign = oLI.getVAlign();
                if (vAlign != sap.ui.core.VerticalAlign.Inherit) {
                    rm.addClass("sapMListTblRow" + vAlign);
                }

                rm.addClass("super" + oLI.getSupercessionRole());
            }
        }
    });
});