/**
 ****************************************************************************************
 *  Changed on:  Changed by:   Change ID:  TR Number:        Description:
 *  2018.01.08   Subha          initial   GKAK908271       Parts Information new tile
 *****************************************************************************************
 */
sap.ui.define([
        "encollab/dp/BaseController",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/Sorter",
        "sap/ui/model/json/JSONModel"
    ],
	/**
	 * <p>Here you'll find all methods and functions related to searching a part</p>
	 * <h4>OData services used</h4>
	 * <ul>
	 * <li>Part</li>
	 * </ul>
	 * <h4>Templates used</h4>
	 * <ul>
	 * <li>encollab.dp.parts.Enquiry.view.xml <small>main view</small></li>
	 * </ul>
	 * @class Enquiry
	 * @memberOf encollab.dp.parts
	 * @extends {encollab.dp.BaseController}
	 * @return {encollab.dp.parts.Enquiry}
	 *
	 * @param  {encollab.dp.BaseController} Controller
	 * @param  {sap.ui.model.Filter} Filter
	 * @param {sap.ui.model.FilterOperator} FilterOperator
	 * @param {sap.ui.model.Sorter} Sorter
	 * @param {sap.ui.model.json.JSONModel} JSONModel
	 */
	function(Controller, Filter, FilterOperator, Sorter, JSONModel) {
		"use strict";
		return Controller.extend("encollab.dp.PartsInf.Enquiry", {
			_userAuthorisations: ['PartEnquiry'],
			_userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
			_activeCalls: [],

			onInit: function() {
				Controller.prototype.onInit.apply(this, arguments);

				this.model = new JSONModel({
					count: 0,
					parts: []
				});

				this.setModel(this.model, 'data');
				this._perform1Search();
			},
			attachmentURL: function(oEvent) {
			   var oSource = oEvent.getSource(); 
			   var path = oSource.getBindingContext('data').getPath();
			   var line = this.getModel('data').getProperty(path);
			   var docid = line.DOC_ID;
				var sDocumentRead = window.location.origin +"/sap/opu/odata/sap/Y_DP_PARTS_SRV/Attachments('" + docid + "')/$value";
		    	window.open(sDocumentRead);
			
			},
			/**
			 * This event is fired when the search box is used. Displays a message when the length of the enquiry is less than
			 * 3 characters
			 * @name encollab.dp.parts.Detail#onSearchParts
			 * @param  {sap.ui.base.Event} oEvent The search event from UI
			 * @method
			 */
// 			onSearchParts: function(evt) {
// 				var string = evt.getSource().getValue();
// 				if (string.length && string.length > 3) {
// 					this.byId('partsSearchLength').setVisible(false);
// 					this._performSearch(string.toUpperCase());
// 				} else {
// 					this.byId('partsSearchLength').setVisible(true);
// 				}
// 			},
			/**
			 * Navigates to the parts detail screen when a material number is pressed
			 * @name encollab.dp.parts.Detail#onSearchParts
			 * @param  {sap.ui.base.Event} oEvent The search event from UI
			 * @method
			 */
		
			/**
			 * <p>Function that performs the actual search. It cancels all active calls when a user performs a new search.
			 * It also formats the data for download.</p>
			 * <p>If only one part is found, automatically navigates to that part.</p>
			 * @name encollab.dp.parts.Detail#_performSearch
			 * @private
			 * @param  {string} searchString
			 * @method
			 */
			_perform1Search: function(searchString) {
				this._activeCalls.push(this.getModel('part').read('/PartsInfoSet', {
					success: function(data) {
						console.log(data.results);
						var parts = data.results;
						this.model.setProperty('/parts', parts);
						
					}.bind(this)
				}).abort);
			
			},
			/**
			 * Prepares the results, mostly by removing the actual number of stocks and displaying "Yes" or "No" instead
			 * @name encollab.dp.parts.Detail#_prepareResults
			 * @private
			 * @param  {array<object>} data
			 * @method
			 */
// 			_prepareResults: function(data) {
// 				for (var i = 0; i < data.length; i++) {
// 					delete data[i].__metadata;
// 					data[i].RRP = parseInt(data[i].RRP);
// 					data[i].Stockonhand = (parseInt(data[i].Stockonhand) === 0) ? 'No' : 'Yes';
// 				}
// 				return data;
// 			}
		});
	});