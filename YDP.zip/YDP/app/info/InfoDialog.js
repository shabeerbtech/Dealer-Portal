sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/model/json/JSONModel"
], function(Object, JSONModel) {
    "use strict";
    return Object.extend("encollab.dp.info.InfoDialog", {
        _Component: null,
        _getDialog: function() {
            // create dialog lazily
            if (!this._oDialog) {
                // create dialog via fragment factory
                this._oDialog = sap.ui.xmlfragment("encollab.dp.info.InfoDialog", this);
                this._oDialog.setModel(this._setupModel());
            }
            return this._oDialog;
        },
        setComponent: function(component) {
            this._Component = component;
        },
        open: function(oView) {
            var oDialog = this._getDialog();

            // forward compact/cozy style into Dialog
            jQuery.sap.syncStyleClass(oView.getController().getOwnerComponent().getContentDensityClass(), oView, oDialog);

            // connect dialog to view (models, lifecycle)
            oView.addDependent(oDialog);
            // open dialog
            oDialog.open();
        },
        onCloseDialog: function() {
            this._getDialog().close();
        },
        _setupModel: function() {
            var data = {
                name: "Info",
                settings: [{
                    name: "SAPUI5 Version",
                    value: sap.ui.getVersionInfo().version
                }, {
                    name: "Customer",
                    value: this._Component.Customer //getMySettingValue('CUSTOMER')
                }, {
                    name: "UserId",
                    value: this._Component.getMyId()
                }]
            };
            return new JSONModel(data);
        }
    });
});