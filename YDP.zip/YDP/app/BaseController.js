sap.ui.define([
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/routing/History",
        "sap/m/MessageToast",
        "sap/ui/core/MessageType",
        "sap/m/ButtonType",
        "sap/m/BusyDialog",
        "encollab/dp/util/formatter"
    ],
    /**
     * <p>The BaseController is the controller that *every* other controller inherits from. It contains a whole range of 
     * methods that make it easier to deal with commonalities that are used throughout the application, such as helper
     * methods to retrieve the router, helper methods to populate the message box (directly or via oData returns), 
     * and helper methods for user related information such as parameters and authorizations.</p>
     *
     * <p>
     * Worth mentioning is the date issues we seem to be experiencing. Sending a date to the server tries to do a UTC conversion
     * even though the date might already be a UTC date, which results in a <span style="font-family: "Times New Roman", Georgia, Serif;">
     * new Date().getTimeZoneOffset()</span> number of minutes difference in the wrong direction. That's what method 
     * <span style="font-family: "Times New Roman", Georgia, Serif;">accountForUTCDate</span> is for. 
     * </p>
     * 
     * @class BaseController
     * @memberOf encollab.dp
     * @extends {sap.ui.core.mcv.Controller}
     * @return {encollab.dp.BaseController} BaseController [the definition of the controller for the About module]
     * 
     * @param  {encollab.dp.BaseController} Controller
     * @param  {sap.m.List} List       
     * @param  {sap.m.StandardListItem} StandardListItem  
     * @param  {sap.m.MessagePopover} MessagePopover    
     * @param  {sap.m.MessagePopoverItem} MessagePopoverItem 
     * @param  {sap.ui.model.json.JSONModel} JSONModel    
     */
    function(Controller, History, MessageToast, MessageType, ButtonType, BusyDialog, formatter) {
        "use strict";

        return Controller.extend("encollab.dp.BaseController", {
            /**
             * Holds an instance of the Owner Component
             *
             * @member
             * @name   encollab.dp.BaseController#myComponent
             */
            myComponent: null,

            /**
             * Holds an instance of the Application Router
             *
             * @member
             * @name   encollab.dp.BaseController#myRouter
             */
            myRouter: null,

            /**
             * Holds an instance of the current view used to instantiate this controller
             *
             * @member
             * @name   encollab.dp.BaseController#myView
             */
            myView: null,

            /**
             * An instance of a busy dialog that can be used for the entire screen
             *
             * @member
             * @name   encollab.dp.BaseController#busyDialog
             */
            busyDialog: null,

            /**
             * An instance of a message toast, so we can display messages on the screen
             *
             * @member
             * @name   encollab.dp.BaseController#MessageToast
             */
            MessageToast: MessageToast,

            /**
             * An instance of all global formatters, found in app.util.formatters.js. These formatters are used 
             * in most views so that dates, times etc are handled in a uniform manner
             *
             * @member
             * @name   encollab.dp.BaseController#formatter
             */
            formatter: formatter,

            /**
             * Holds a boolean to see if the currently logged in user is valid. 
             *
             * @member
             * @private
             * @name   encollab.dp.BaseController#_userAccountIsValid
             */
            _userAccountIsValid: false,

            /**
             * Initialisation method for the Base controller. There are no arguments, 
             * and it sets a range of class members such as the component, router, view and 
             * busy dialog. It also checks the user settings to see if all criteria are met. 
             *
             * @method
             * @name   encollab.dp.BaseController#onInit
             */
            onInit: function() {
                this.myComponent = this.getOwnerComponent();
                this.myRouter = this.getRouter();
                this.myView = this.getView();
                this.busyDialog = new BusyDialog();

                this.myView.addEventDelegate({
                    onAfterRendering: $.proxy(this.onAfterViewRendered, this)
                });

                this.myView.addStyleClass(this.myComponent.getContentDensityClass());
                this.myView.setBusyIndicatorDelay(0);

                this.myComponent.resetMessagePopover();

                if (this._checkUserSettings()) {
                    this._userAccountIsValid = true;
                } else {
                    if (this.myView.getControllerName() !== 'encollab.dp.App') {
                        if (this.myView && this.myView.getContent && this.myView.getContent()[0] && this.myView.getContent()[0].destroyContent) {
                            this.myView.getContent()[0].destroyContent();
                        }
                    }
                }

                // TODO Remove this later
                this.getOwnerComponent().getModel('core').setUseBatch(false);

            },

            /**
             * An event is fired after the view is rendered. This is the method that is executed when it does. 
             * It can be extended by the child controller.
             * 
             * @method
             * @name   encollab.dp.BaseController#onAfterViewRendered
             */
            onAfterViewRendered: function(oEvent) {

            },
            /**
             * Convenience method for accessing the router in every controller of the application.
             * @public
             * @method
             * @name   encollab.dp.BaseController#getRouter
             * @returns {sap.ui.core.routing.Router} the router for this component
             */
            getRouter: function() {
                return this.getOwnerComponent().getRouter();
            },

            /**
             * Convenience method for getting the view model by name in every controller of the application.
             * @public
             * @method
             * @name   encollab.dp.BaseController#getModel
             * @param {string} sName the model name
             * @returns {sap.ui.model.Model} the model instance
             */
            getModel: function(sName) {
                return this.getView().getModel(sName) ? this.getView().getModel(sName) : this.getOwnerComponent().getModel(sName);
            },

            /**
             * Convenience method for setting the view model in every controller of the application.
             * @public
             * @method
             * @name   encollab.dp.BaseController#setModel
             * @param {sap.ui.model.Model} oModel the model instance
             * @param {string} sName the model name
             * @returns {sap.ui.mvc.View} the view instance
             */
            setModel: function(oModel, sName) {
                return this.getView().setModel(oModel, sName);
            },

            /**
             * Convenience method for getting the resource bundle.
             * @public
             * @name   encollab.dp.BaseController#getResourceBundle
             * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
             */
            getResourceBundle: function() {
                return this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },

            /**
             * Event handler  for navigating back.
             * It checks if there is a history entry. If yes, history.go(-1) will happen.
             * If not, it will replace the current entry of the browser history with the master route.
             * @public
             * @method
             * @name   encollab.dp.BaseController#onNavBack
             * @param {sap.ui.route} route [the route that is currently active]
             */
            onNavBack: function(route) {
                var sPreviousHash = History.getInstance().getPreviousHash();

                if (sPreviousHash !== undefined) {
                    // The history contains a previous entry
                    history.go(-1);
                } else {
                    // Otherwise we go backwards with a forward history
                    var bReplace = true;
                    this.getRouter().navTo(route, {}, bReplace);
                }
            },
            /**
             * Convenience method to open the information dialog
             * @public
             * @method
             * @name   encollab.dp.BaseController#onOpenInfoDialog
             */
            onOpenInfoDialog: function() {
                this.getOwnerComponent().infoDialog.open(this.myView);
            },
            /**
             * Method to navigate back to the dashboard
             * @public
             * @method
             * @name   encollab.dp.BaseController#onBackToDashboardButton
             */
            onBackToDashboardButton: function() {
                this.myRouter.navTo('dashboard');
            },
            /**
             * Convenience method for getting the resource bundle.
             * @public
             * @method
             * @name   encollab.dp.BaseController#isUserAuthorised
             * @returns {boolean} true [Always returns true. Auth model not used at NMI]
             */
            isUserAuthorised: function(auth) {
                return true; // Turning off auth checking at Tony D request
                return this.getOwnerComponent().getMyAuthorisation(auth);
            },
            /**
             * Private function to find a UI5 /HTML element in an array of elements by ID.
             * @private
             * @method
             * @name   encollab.dp.BaseController#_findElementIn
             * @returns {any} Any element held in the array by it's ID. 
             */
            _findElementIn: function(id, arrayCtrls) { //Pass in an array of controls and return element by id
                for (var i = 0; i < arrayCtrls.length; i++) {
                    if (arrayCtrls[i].getId() === id) {
                        return arrayCtrls[i];
                    }
                }
            },
            /**
             * Private method to check the user authorizations. This is government by object Y_PORTAL in ABAP, which in 
             * turn is used to populate a list of actions the user has, and doesn't have, access to. 
             * @private
             * @method
             * @name   encollab.dp.BaseController#_checkUserAuthorisations
             * @returns {boolean} [Yes or No]
             */
            _checkUserAuthorisations: function(aAuths) {
                return true; // Turning off auth checking at Tony D request

                var allOk = true;
                // 'Portal' is minimum authorisation required. We check this everytime.
                if (!this.isUserAuthorised('Portal')) {
                    this.errorMessage('Portal', 'AuthCheck Failed');
                    allOk = false;
                } else {
                    //this.successMessage('Portal', 'AuthCheck Passed');
                }
                if (aAuths && aAuths.length) {
                    for (var i = 0; i < aAuths.length; i++) {
                        if (!this.isUserAuthorised(aAuths[i])) {
                            this.errorMessage(aAuths[i], 'AuthCheck Failed');
                            allOk = false;
                        } else {
                            //this.successMessage(aAuths[i], 'AuthCheck Passed');
                        }
                    }
                }
                return allOk;
            },
            /**
             * Checks if the user's parameters. These are maintained in SAP backend on the user (SU01) or by the user
             * themselves. These are variables like BUK, VKO and SPA. 
             * @private
             * @method
             * @name   encollab.dp.BaseController#_checkUserSettings
             * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
             */
            _checkUserSettings: function() {
                var allOk = true;
                allOk = this._checkUserAuthorisations(this._userAuthorisations) && this._checkUserDealer();
                if (this._userParameters) {
                    // This is where we check user parameters are maintained in SAP system
                    var map = this.formatter.UserParamMap; //Texts map
                    for (var j = 0; j < this._userParameters.length; j++) {
                        if (!this.myComponent.getMySettingValue(this._userParameters[j])) {
                            var paramName = map[this._userParameters[j]] ? map[this._userParameters[j]] : this._userParameters[j];
                            this.errorMessage(
                                'Parameter ' + this._userParameters[j] + ' not found',
                                'Parameter ' + paramName + ' not found'
                            );
                            allOk = false;
                        }
                    }
                }
                return allOk;
            },
            /**
             * Checks if the user has any dealers set up. Will display an error message if not. 
             * @private
             * @method
             * @name   encollab.dp.BaseController#_checkUserDealer
             * @returns {boolean} 
             */
            _checkUserDealer: function() {
                var allOk = true;
                if (this.myComponent.getMyDealers().length === 0) {
                    this.errorMessage(this.getText('accountSetupError'), this.getText('noDealer'));
                    allOk = false;
                }
                return allOk;
            },
            /**
             * Get the current URL if only a file name is presented. 
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#getRelativeUrl
             * @returns {string} [url] 
             */
            getRelativeUrl: function(file) {
                return window.location.href.match(/^([^#]*\/)/gi)[0] + file;
            },
            /**
             * Resets the message popover box found at the bottom left of the screen
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#resetMessagePopover
             */
            resetMessagePopover: function() {
                this.getOwnerComponent().resetMessagePopover();
            },
            /**
             * Opens the message popover box found at the bottom left of the screen
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#onMessageButtonPress
             */
            onMessageButtonPress: function(oEvent) {
                this.getOwnerComponent().messagePopover.openBy(oEvent.getSource());
            },
            /**
             * Fires the "press" event of the message box
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#showMessagePopover
             */
            showMessagePopover: function() {
                if (this.myView && this.myView.byId('messageButton')) {
                    this.myView.byId('messageButton').firePress();
                }
            },
            /**
             * Adds an error message to the message box
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#addMessage
             * @param {string} [messageType] [the type of the message]
             * @param {string} [messageTitle] [the title of the message]
             * @param {string} [messageText] [the body of the message]
             */
            addMessage: function(messageType, messageTitle, messageText) {
                this.getOwnerComponent().addMessage(messageType, messageTitle, messageText);
            },
            /**
             * Adds an error message to the message box
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#errorMessage
             * @param {string} [messageTitle] [the title of the message]
             * @param {string} [messageText] [the body of the message]
             */
            errorMessage: function(messageTitle, messageText) {
                this.addMessage(MessageType.Error, messageTitle, messageText);
            },
            /**
             * Adds a warning message to the message box
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#warningMessage
             * @param {string} [messageTitle] [the title of the message]
             * @param {string} [messageText] [the body of the message]
             */
            warningMessage: function(messageTitle, messageText) {
                this.addMessage(MessageType.Warning, messageTitle, messageText);
            },
            /**
             * Adds a success message to the message box
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#successMessage
             * @param {string} [messageTitle] [the title of the message]
             * @param {string} [messageText] [the body of the message]
             */
            successMessage: function(messageTitle, messageText) {
                this.addMessage(MessageType.Success, messageTitle, messageText);
            },
            /**
             * Adds an info message to the message box
             * 
             * @public
             * @method
             * @name   encollab.dp.BaseController#infoMessage
             * @param {string} [messageTitle] [the title of the message]
             * @param {string} [messageText] [the body of the message]
             */
            infoMessage: function(messageTitle, messageText) {
                this.addMessage(MessageType.Information, messageTitle, messageText);
            },
            /**
             * Adds an error message to the message box and opens it straight away
             *
             * @method
             * @public
             * @name   encollab.dp.BaseController#errorMessage
             * @param {string} [messageTitle] [the title of the message]
             * @param {string} [messageText] [the body of the message]
             */
            popErrorMessage: function(messageTitle, messageText) {
                this.errorMessage(messageTitle, messageText);
                this.showMessagePopover();
            },
            /**
             * This changes the type of the message box' opening button. If it contains errors, it sets
             * the status to 'Reject'. If the box contains warnings, set the status to 'Emphasized'. On success 
             * messages, the button will be in status 'Accept. Otherwise, it sets the status to 'Default'. 
             *
             * @method
             * @public
             * @name   encollab.dp.BaseController#messageButtonType
             */
            messageButtonType: function(value) {
                var oMsg = this.myView.getModel('msg').getData();

                if (oMsg) {
                    if (oMsg.errorMessages !== '0') {
                        return ButtonType.Reject;
                    }
                    if (oMsg.warningMessages !== '0') {
                        return ButtonType.Emphasized;
                    }
                    if (oMsg.successMessages !== '0') {
                        return ButtonType.Accept;
                    }
                }
                return ButtonType.Default;
            },
            /**
             * This changes the icon of the opening button. See 'messageButtonType'. 
             *
             * @method
             * @public
             * @name   encollab.dp.BaseController#messageButtonIcon
             */
            messageButtonIcon: function(value) {
                var oMsg = this.myView.getModel('msg').getData();

                if (oMsg) {
                    if (oMsg.errorMessages !== '0') {
                        return 'sap-icon://message-error';
                    }
                    if (oMsg.warningMessages !== '0') {
                        return 'sap-icon://message-warning';
                    }
                    if (oMsg.successMessages !== '0') {
                        return 'sap-icon://message-success';
                    }
                }
                return 'sap-icon://message-information';
            },
            /**
             * This changes the text of the opening button. See 'messageButtonType'. 
             * @method
             * @public
             * @name   encollab.dp.BaseController#messageButtonText
             */
            messageButtonText: function(value) {
                var oMsg = this.myView.getModel('msg').getData();

                if (oMsg) {
                    if (oMsg.errorMessages !== '0') {
                        return oMsg.errorMessages;
                    }
                    if (oMsg.warningMessages !== '0') {
                        return oMsg.warningMessages;
                    }
                    if (oMsg.successMessages !== '0') {
                        return oMsg.successMessages;
                    }
                }
                return value;
            },
            /**
             * This adds an error to the message box based on the return object of a gateway error. The error object, 
             * which is going to be XML, will be parsed and the relevant title and body will be loaded into the box and 
             * displayed immediately. 
             * @method
             * @public
             * @name   encollab.dp.BaseController#gatewayError
             * @param {Object} [oError] [This is the error object returned by a gateway service]
             */
            gatewayError: function(oError) {
                // Error message text might be JSON or XML
                var errorMessage = '?';
                var errorCode = 'Error';
                try {
                    var oErr = JSON.parse(oError.responseText).error;
                    errorMessage = oErr.message.value;
                    errorCode = oErr.code || oError.statusText;
                } catch (err) {
                    var xmlDoc = $($.parseXML(oError.responseText));
                    errorMessage = xmlDoc.find('message').text();
                    errorCode = oError.statusText ? oError.statusText : 'Error';
                }
                this.popErrorMessage(errorCode, errorMessage);
                return errorMessage;
            },
            _parseMessages: function(messageData) {
                var errorMsg = false;
                this.resetMessagePopover();
                for (var i = 0; i < messageData.length; i++) {
                    this.addMessage(messageData[i].type, messageData[i].message);
                    if (messageData[i].type === MessageType.Error) {
                        this.showMessagePopover();
                    }
                }
            },
            /**
             * This gets a text element out of the resource bundle, which is the i18n file
             * @method
             * @name   encollab.dp.BaseController#getText
             * @param  {string} textId     [Id of the text message]
             * @param  {object} textParams [optional parameters]
             * @return {string}            [description]
             */
            getText: function(textId, textParams) {
                return this.getResourceBundle().getText(textId, textParams);
            },
            /**
             * This adds the timezone offset to a date object. For some reason there are odditities in the way 
             * date objects are considered to be in UTC, when they're not. This means UI5 will remove a timezone that was 
             * not on it to begin with. 
             * @method
             * @name   encollab.dp.BaseController#accountForUTCDate
             * @param  {Date} date     [the date object]
             * @return {Date}            [modified Date object]
             */
            accountForUTCDate: function(date) {
                if (date instanceof Date) {
                    return new Date(date.getTime() - (date.getTimezoneOffset() * 60 * 1000));
                } else {
                    return date;
                }
            },
            /**
             * Convenience method to clone an object
             * @private
             * @method
             * @name   encollab.dp.BaseController#_clone
             * @param  {Object} obj
             * @return {Object}     [Cloned object]
             */
            _clone: function(obj) {
                if (obj === null || typeof(obj) !== 'object' || 'isActiveClone' in obj)
                    return obj;

                if (obj instanceof Date)
                    var temp = new obj.constructor(); //or new Date(obj);
                else
                    var temp = obj.constructor();

                for (var key in obj) {
                    if (Object.prototype.hasOwnProperty.call(obj, key)) {
                        obj['isActiveClone'] = null;
                        temp[key] = this._clone(obj[key]);
                        delete obj['isActiveClone'];
                    }
                }

                return temp;
            },
            /**
             * Convenience method to format UI5 binding data into objects
             * @private
             * @method
             * @name   encollab.dp.BaseController#_expandElementBindingToData
             * @param  {string} path [Model path]
             * @param  {sap.ui.model.odata.OData} path [An odata model]
             * @return {Object}     [The data from the binding path without all the oData related stuff]
             */
            _expandElementBindingToData: function(path, model) {
                var oData = model.getProperty(path);
                var data = this._clone(oData);

                for (var d in data) {
                    //we dont care about metadata, nor do we care about non-expanded objects
                    if (data[d] === null) {
                        data[d] === '';
                    } else if (d === '__metadata' || typeof data[d].__deferred !== 'undefined') {
                        delete data[d];
                        continue;
                    } else if (data[d].__list) {
                        /* supercession broke my recursion. a part inside of a part inside of a part */
                        var x = []
                        for (var l in data[d].__list) {
                            var expand = this._clone(model.getProperty('/' + data[d].__list[l]));
                            for (var e in expand) {
                                //we dont care about metadata, nor do we care about non-expanded objects
                                if (expand[e] === null) {
                                    expand[e] === '';
                                } else if (e === '__metadata' || typeof expand[e].__deferred !== 'undefined') {
                                    delete expand[e];
                                    continue;
                                }
                            }
                            x.push(expand);
                        }
                        data[d] = x;
                    }
                }

                return data;
            },
            /**
             * Formats a data object to CSV
             * @method
             * @name   encollab.dp.BaseController#_expandElementBindingToData
             * @param  {Object} data 
             * @return {string}      [A CSV string]
             */
            _formatForDownload: function(data) {
                var filtered = {};
                var formatter = this.formatter;
                var additional = {};
                var out = [];
                var self = this;

                $.each(data, function(a, b) {
                    if (b instanceof Array) {
                        var keys = $.map(b[0], function(v, k) {
                            return quote(k);
                        });

                        additional[a] = {
                            data: b,
                            header: keys
                        };
                    } else {
                        out.push([quote(a), quote(self._format(b))].join(','))
                    }
                });

                $.each(additional, function(a, b) {
                    out.push('\n\n' + quote(a));
                    out.push(b.header.join(','));
                    $.each(b.data, function(c, d) {
                        var data = []
                        $.each(d, function(e, f) {
                            data.push(quote(self._format(f)));
                        })
                        out.push(data.join(','));
                    })
                });

                return out.join('\n');

                function quote(a) {
                    return '"' + a + '"';
                }
            },

            /**
             * A quick method to generate a CSV from an array containing objects.  
             * @private
             * @method
             * @name   encollab.dp.BaseController#_formatSimpleArrayForDownload
             * @param  {array<object>} data    [description]
             * @return {string}         
             */
            _formatSimpleArrayForDownload: function(data, columns) {
                var out = '';

                for (var d in data[0]) {
                    if (d !== '__metadata') {
                        out += '"' + d + '",';
                    }
                }

                out += '\n';

                for (var i = 0; i < data.length; i++) {
                    for (var d in data[i]) {
                        if (d !== '__metadata') {
                            out += '"' + this._format(data[i][d]) + '",';
                        }
                    }
                    out += '\n';
                }
                return out;
            },
            /**
             * Formats a field based on the EDM time so that date objects are formatted the way they are on the 
             * portal
             * @private
             * @method
             * @name   encollab.dp.BaseController#_format
             * @param  {Any} b 
             * @return {Any}   [Formatted element]
             */
            _format: function(b) {
                if (b === null || typeof b === 'undefined') {
                    return '';
                } else if (b.__edmType === "Edm.Time") {
                    b = (b.ms > 0) ? formatter.Time(b.ms).toString() : '';
                } else if (b instanceof Date) {
                    b = formatter.ShortDate(b);
                } else if (typeof b === 'number') {
                    b = b.toString().trim();
                } else {
                    b = b.toString().trim();
                }

                return b.replace(/[,]/gi, '-');
            }
        });
    });