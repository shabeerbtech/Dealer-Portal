/** @namespace encollab */
/** @namespace encollab.dp */
/** @namespace encollab.dp.about */
/** @namespace encollab.dp.orders */
/** @namespace encollab.dp.vin */
/** @namespace encollab.dp.parts */
/** @namespace encollab.dp.reports */
/** @namespace encollab.dp.wty */

sap.ui.define([
    "encollab/dp/BaseController"
], 
/**
 * The App controller. This controller has no methods but serves as the base of the application.
 * 
 * @class App
 * @memberOf encollab.dp
 * @extends {encollab.dp.BaseController}
 * @return {encollab.dp.App} App [the definition of the controller for the App module]
 * @param  {encollab.dp.Basecontroller} Controller
 */
function(Controller) {
    "use strict";
    return Controller.extend("encollab.dp.App", {

        /**
         * Initialisation method for the About module. There are no arguments and contains
         * no logic. 
         *
         * @method
         * @name   encollab.dp.App#onInit
         */
        onInit: function() {
            Controller.prototype.onInit.apply(this, arguments);
        }
    });
});