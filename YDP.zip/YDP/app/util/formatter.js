/**
 ****************************************************************************************
 *  Changed on:  Changed by:   Change ID:  TR Number:        Description:
 *  2017.11.02   Z009780        C001       GKAK907892/7970   PCR - 19 Added ZCR Order Type
 *****************************************************************************************
 */
sap.ui.define([
    "encollab/dp/util/formatter"
], function() {
    "use strict";
    var formatters = {
        UserParamMap: {
            "VKO": "Sales Organisation",
            "USERBP": "User Business Partner",
            "DP_KUNNR": "Dealer Portal Current customer"
        },
        statusText: function(sStatus) {
            var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
            switch (sStatus) {
                case "A":
                    return resourceBundle.getText("invoiceStatusA");
                case "B":
                    return resourceBundle.getText("invoiceStatusB");
                case "C":
                    return resourceBundle.getText("invoiceStatusC");
                default:
                    return sStatus;
            }
        },
        Date: function(value) {
            if (value) {
                var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "E dd MMMM yyyy" //"dd-MM-yyyy"
                });
                return oDateFormat.format(new Date(value));
            } else {
                return value;
            }
        },
        ShortDate: function(value) {
            if (value) {
                var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "dd MMM yyyy" //"dd-MM-yyyy"
                });
                return oDateFormat.format(formatters.dateToUTC(new Date(value)));
            } else {
                return value;
            }
        },
       wtyDate: function(value) {
            if (value) {
                var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "dd/MM/yyyy" //"dd-MM-yyyy"
                });
                return oDateFormat.format(formatters.dateToUTC(new Date(value)));
            } else {
                return value;
            }
        },
        sapDate: function(value) {
            return value && value.length > 7 ? value.substr(6, 2) + '/' + value.substr(4, 2) + '/' + value.substr(0, 4) : value;
        },
        Time: function(value) {
            if (!value) return '';

            value = value.ms || value;

            if (new Date(value).getTime() % (60 * 60 * 1000) === 0) return ''; //don't return time when its exactly midnight

            if (value && value > 0) {
                return sap.ui.core.format.DateFormat.getTimeInstance({
                    pattern: "kk:mm:ss a"
                }).format(new Date(value));
            } else {
                return '';
            }
        },
        dateToUTC: function(date) {
            var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
            return new Date(date.getTime() + TZOffsetMs);
        },
        TZOffsetDate: function(utcDate) {
            // timezoneOffset is in hours convert to milliseconds  
            var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
            return new Date(utcDate.getTime() - TZOffsetMs);
        },
        Number: function(value) {
            return isNaN(value) ? value : this.formatter.Quantity(value);
        },
        NumberWithThousandsSeparator: function(value) {
            return isNaN(parseFloat(value)) ? '' : Number(parseFloat(value).toFixed(0)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },
        MaxTwoDecimals: function(value) {
            try {
                return (value) ? Number(parseFloat(value).toFixed(2)).toString() : value;
            } catch (err) {
                return "Not-A-Number";
            }
        },
        GreaterThan: function(a, b) {
            return isNaN(a) || isNaN(b) ? false : Number(a) > Number(b);
        },
        Value: function(value) {
            try {
                return (value) ? parseFloat(value).toFixed(2) : value;
            } catch (err) {
                return "Not-A-Number";
            }
        },
        parseFloat: function(value) {
            return parseFloat(value);
        },
        exists: function(object) {
            return object ? true : false;
            //        return (object && object.length > 0);
        },
        arrayCount: function(oArray) {
            return jQuery.isArray(oArray) ? oArray.length === 0 ? null : oArray.length : 0;
        },
        arrayCountVisible: function(oArray) {
            if (!oArray) return;

            if (jQuery.isArray(oArray)) {
                return oArray.length === 0 ? false : true;
            } else {
                return false;
            }
        },
        Quantity: function(value) {
            try {
                return (value) ? parseFloat(value).toFixed(0) : value;
            } catch (err) {
                return "Not-A-Number";
            }
        },
        currencyValue: function(value) {
            return isNaN(value) ? parseFloat(value).toFixed(2) : value;
        },
        isInteger: function(value) {
            return !(isNaN(value) || value !== parseFloat(value).toFixed(0));
        },
        quantityValue: function(value) {
            if (!value) return;
            var qty = isNaN(value) ? 0 : parseFloat(value).toFixed(0);
            return qty >= 10 ? '10+' : qty;
        },
        quantityState: function(value) {
            if (value === 0) {
                return sap.ui.core.ValueState.Error;
            }
            if (value < 5) {
                return sap.ui.core.ValueState.Warning;
            }
            return sap.ui.core.ValueState.Success;
        },
        yesOrNo: function(value) {
            return (parseFloat(value) > 0) ? 'Yes' : 'No';
        },
        yesOrNoState: function(value) {
            if (value === "Yes") return 'Success';
            if (value === "No") return 'Error';
            return (parseFloat(value) > 0) ? 'Success' : 'Error';
        },
        _statusStateMap: {
            "INP": "Error",
            "SUB": "Success"
        },
        SOStatusState: function(value) {
            return (value && this.formatter._statusStateMap[value]) ? this.formatter._statusStateMap[value] : "None";
        },
        _wtyStatusStateMap: {
            "INP": "Error",
            "SUB": "Success"
        },
        wtyStatusState: function(value) {
            return (value && this.formatter._wtyStatusStateMap[value]) ? this.formatter._wtyStatusStateMap[value] : "None";
        },

        wtyICOCValue: function(ICval, ICcur, OCval, OCcur) {
            ICval = formatters.NumberWithThousandsSeparator(ICval);
            OCval = formatters.NumberWithThousandsSeparator(OCval);
            return !OCcur || OCcur === null ? ICval + ' ' + ICcur : OCval + ' ' + OCcur;
        },
         serctICValue: function(ICval, ICcur) {
            ICval = formatters.NumberWithThousandsSeparator(ICval);
            return ICval + ' ' + ICcur ;
        },
        wtyICOCState: function(ICval, OCval) {
            return ICval === OCval ? 'Success' : 'Warning';
        },

        wtyVersionTextMap: {
            "IC": "Incoming Customer",
            "OV": "Outgoing Vendor",
            "IV": "Incoming Vendor",
            "OC": "Outgoing Customer"
        },

        dsDescription: {
            A: 'PFP - Return Pending',
            B: 'PFP - Part Returned By Dealer',
            C: 'PFP - Part Sent for Scrapping',
            D: 'PFP - Part Received By TCS',
            P: 'Replacement Part - Pending Return',
            R: 'Replacement Part - Returned by Dealer'
        },

        noDecimals: function(val) {
            return parseInt(val);
        },

        wtyVersionText: function(value) {
            var map = dp.util.Formatter.wtyVersionTextMap;
            return (value && map[value]) ? map[value] : value;
        },
        removeLeadingZeroes: function(value) {
            return (typeof value === 'string') ? value.replace(/^0+/, '') : value;
        },
        empty: function(value) {
            return value !== null;
        },
//BOC - C001
        orType: function(value) {
            if (value === "ZRE" || value === "ZCR" ){
                return true; }
            else{
                return false;
            }
        },
//EOC - C001
        directSwapDescription: function(status) {
            return formatters.dsDescription[status] || 'N/A';
        }
    };

    return formatters;
});