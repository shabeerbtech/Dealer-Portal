sap.ui.define([
    "encollab/dp/BaseController",
    "sap/m/List",
    "sap/m/StandardListItem",
    'sap/m/MessagePopover',
    'sap/m/MessagePopoverItem',
    'sap/ui/model/json/JSONModel'
], 
/**
 * This is the controller for the "About" button, which shows user information such as
 * dealerships and authorizations
 * <br /><h4>Templates in use</h4>
 * <ul>
 * <li>About.view.xml</li>
 * <li>MessageButton.fragment.xml</li>
 * </ul>
 * @class About
 * @memberOf encollab.dp.about
 * @extends {encollab.dp.BaseController}
 * @return {encollab.dp.about.About} AboutController the definition of the controller for the About module
 * 
 * @param  {encollab.dp.BaseController} Controller
 * @param  {sap.m.List} List       
 * @param  {sap.m.StandardListItem} StandardListItem  
 * @param  {sap.m.MessagePopover} MessagePopover    
 * @param  {sap.m.MessagePopoverItem} MessagePopoverItem 
 * @param  {sap.ui.model.json.JSONModel} JSONModel    
 */
function(Controller, List, StandardListItem, MessagePopover, MessagePopoverItem, JSONModel) {
    "use strict";

    var oMessageTemplate = new MessagePopoverItem({
        type: '{type}',
        title: '{title}',
        description: '{description}'
    });

    this.oMessagePopover = new MessagePopover({
        items: {
            path: '/',
            template: oMessageTemplate
        }
    });

    return Controller.extend("encollab.dp.about.About", {

        /**
         * Initialisation method for the About module. There are no arguments, and it only 
         * executes the private methods that builds the content of the popup. 
         *
         * @method
         * @name   encollab.dp.about.About#onInit
         */
        onInit: function() {
            Controller.prototype.onInit.apply(this, arguments);

            this._buildPageContent();

        },

        /**
         * This methods builds the content of the About window, as layed out in 
         * 'About.view.xml'. It's populated with some of the user's details such as
         * dealerships and authorizations
         *
         * @method
         * @private
         * @name   encollab.dp.about.About#_buildPageContent
         */
        _buildPageContent: function() {
            var userData = this.myComponent.getUserData();

            var oList = this.myView.byId('userDetails');

            oList.addItem(new StandardListItem({
                title: 'Logged on as: ' + userData.Id,
                description: 'Full Name: ' + userData.FullName
            }));

            // Authorisations
            var oAuthList = new List();
            for (var key in userData.Authorisations) {
                if (key !== '__metadata') {
                    oAuthList.addItem(new StandardListItem({
                        title: key,
                        info: userData.Authorisations[key],
                        infoState: userData.Authorisations[key] ? 'Success' : 'Error'
                    }));
                }
            }
            this.myView.byId('authPanel').addContent(oAuthList);

            // Roles
            var oRoleList = new List();
            for (var i = 0; i < userData.UserRoles.results.length; i++) {
                oRoleList.addItem(new StandardListItem({
                    title: userData.UserRoles.results[i].Description,
                    description: userData.UserRoles.results[i].RoleName,
                    info: userData.UserRoles.results[i].Enabled,
                    infoState: userData.UserRoles.results[i].Enabled ? 'Success' : 'Error'
                }));
            }
            this.myView.byId('rolePanel').addContent(oRoleList);

            // Settings
            var oSettingsList = new List();
            for (i = 0; i < userData.UserSettings.results.length; i++) {
                oSettingsList.addItem(new StandardListItem({
                    title: userData.UserSettings.results[i].Name,
                    description: userData.UserSettings.results[i].Description,
                    info: userData.UserSettings.results[i].Value
                }));
            }
            this.myView.byId('settingsPanel').addContent(oSettingsList);

            // Dealers
            var oDealerList = new List();
            for (i = 0; i < userData.Customers.results.length; i++) {
                oDealerList.addItem(new StandardListItem({
                    title: userData.Customers.results[i].CustomerNr,
                    description: userData.Customers.results[i].Name
                }));
            }
            this.myView.byId('dealerPanel').addContent(oDealerList);
            if(userData.Customers.results.length===0) {
                this.errorMessage('No Dealer Found','This user is not linked to any dealers');
            }

        },
        /**
         * This event handler navigates back to the dashboard
         * @method
         * @name   encollab.dp.about.About#onOpenInfoDialog
         */
        onOpenInfoDialog: function() {
            this._oRouter.navTo("dashboard", true);
        },

        /**
         * This event handler opens the popover message 
         * @method
         * @name   encollab.dp.about.About#handleMessagePopoverPress
         */
        handleMessagePopoverPress: function(oEvent) {
            oMessagePopover.openBy(oEvent.getSource());
        }
    });
});