// *********************************************************************************
//  Changed on:  Changed by:   Change ID:  TR Number:              Description:-->
//  2018.01.10   Subha           C001      GKAK908289            partsinformation tile
//  2018.11.11   Nisha          C005        GKAK908806            Credit chk change
// **********************************************************************************
sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "encollab/dp/info/InfoDialog",
    'sap/m/MessagePopover',
    'sap/m/MessagePopoverItem',
    "sap/ui/Device"
],

  /**
   * The Component is a standard object at the root of every UI5 Application. Combined with the manifest.json, it
   * is used as the shaffolding for the application. It initializes the router, all the oData models,
   * registers all the module paths and it fetches
   * the user details from the CORE service before firing up the router and navigating to the appropriate paths.
   * <br /><br />
   * For the different parts of the Component and manifest.json, please refer to the following parts of the
   * {@link  https://sapui5.hana.ondemand.com/#docs/guide/dc9e11c3889441429a60ee871da6f3cb.html|documentation}.
   * <br />
   * @class Component
   * @memberOf encollab.dp
   * @extends {sap.ui.core.UIComponent}
   * @return {encollab.dp.Component}
   * @param  {sap.ui.core.UIComponent} UIComponent       The standard UI Component
   * @param  {sap.ui.model.json.JSONModel} JSONModel
   * @param  {encollab.dp.info.InfoDialog} InfoDialog         The Encollab info dialog
   * @param  {sap.m.MessagePopover} MessagePopover
   * @param  {sap.m.MessagePopoverItem} MessagePopoverItem
   * @param  {sap.ui.Device} Device
   */
  function(UIComponent, JSONModel, InfoDialog, MessagePopover, MessagePopoverItem, Device) {
    "use strict";

    return UIComponent.extend("encollab.dp.Component", {
      metadata: {
        manifest: "json"
      },
      /**
       * On component initialization, which is the first thing that the app does, the following takes place:
       *
       * <ul>
       * <li>Checks the availability of the oData channels. Displays a message if there's no contact</li>
       * <li>Registers all modules</li>
       * <li>Sets up the info dialog</li>
       * <li>Fetches the user data. If succesfull, starts the router</li>
       * <ul>
       * @method
       * @name   encollab.dp.Component#init
       */
      init: function() {
        jQuery.sap.require("jquery.sap.storage");

        // call the init function of the parent
        UIComponent.prototype.init.apply(this, arguments);

        String.prototype.replaceAll = function(search, replacement) {
          var target = this;
          return target.split(search).join(replacement);
        };

        this.getModel('core').attachMetadataFailed(function(oEvent) {
          this.addMessage(sap.ui.core.MessageType.Error, 'Service Error', 'Unable to contact oData service');
        }, this);

        this.getModel('vin').setSizeLimit(25);

        // Register module prefixes
        jQuery.sap.registerModulePath('encollab.dp.controls', './controls');
        jQuery.sap.registerModulePath('encollab.dp.vin', './vin');
        jQuery.sap.registerModulePath('encollab.dp.parts', './parts');
        jQuery.sap.registerModulePath('encollab.dp.wty', './wty');
        jQuery.sap.registerModulePath('encollab.dp.orders', './orders');
        jQuery.sap.registerModulePath('encollab.dp.stock', './stock');
        jQuery.sap.registerModulePath('encollab.dp.reports', './reports');
        jQuery.sap.registerModulePath('encollab.dp.fp', './fp');
        jQuery.sap.registerModulePath('encollab.dp.returns', './returns');
        jQuery.sap.registerModulePath('encollab.dp.ROrders', './ROrders');

          // BOC-C001
        jQuery.sap.registerModulePath('encollab.dp.PartsInf', './PartsInf');
        jQuery.sap.registerModulePath('encollab.dp.serct', './serct');
// EOC-C001

        // set device model
        var oDeviceModel = new JSONModel(Device);
        oDeviceModel.setDefaultBindingMode("OneWay");
        this.setModel(oDeviceModel, "device");

        //this._setupMessagePopover();

        // Setup Info Dialog
        this.infoDialog = new InfoDialog();
        this.infoDialog.setComponent(this);

        // get user settings
        this.getModel('core').read("/Users('SY-UNAME')", {
          async: true,
          urlParameters: {
            "$expand": "UserRoles,UserSettings,UserMenu,Dealers"
          },
          success: $.proxy(function(oEvent) {
            this._userData = oEvent;
            if (this.getMyId() === 'PRX-00016') {
              this.getModel('part').setUseBatch(false);
              this.getModel('vin').setUseBatch(false);
              // this.getModel('vin').setDefaultCountMode(sap.ui.model.odata.CountMode.Inline);
              this.getModel('wty').setUseBatch(false);
            }
            this._getCustomerDetails();
            this.getRouter().initialize();
          }, this),
          error: jQuery.proxy(function(oError) {
            this.busyDialog.close();
            this.popErrorMessage(
              oError.statusText,
              JSON.parse(oError.responseText).error.message.value
            );
          }, this)
        });
      },
      _alert: function() {
        console.warn('alert');
      },
      _getCustomerDetails: function() {
        this.Customer = 'NMI'; //this.getMySettingValue('CUSTOMER');
      },

      /**
       * Sets up the data for the message popover box.
       *
       * @method
       * @private
       * @name   encollab.dp.Component#_setupMessagePopover
       */
      _setupMessagePopover: function() {
        if (this.messagePopover) return;
        // set MessagePopover
        this.messagePopover = new MessagePopover({
          items: {
            path: '/',
            template: new MessagePopoverItem({
              type: '{type}',
              title: '{title}',
              description: '{description}'
            })
          },
          itemSelect: $.proxy(this.onMessagePopoverItemSelect, this)
        });

        // set message info model
        var oMessageModel = new JSONModel();
        oMessageModel.setData({
          errorMessages: '0',
          warningMessages: '0',
          sucessMessages: '0',
          infoMessages: '0',
          totalMessages: '0'
        });

        this.setModel(oMessageModel, "msg");
      },
      /**
       * Sets up the data for the message popover box.
       *
       * @method
       * @name   encollab.dp.Component#resetMessagePopover
       */
      resetMessagePopover: function() {
        if (this.messagePopover) {
          this.messagePopover.removeAllItems();
          this._recalcMessageCounters();
        }
      },

      onMessagePopoverItemSelect: function(oEvent) {
        //oEvent.getSource().removeItem(oEvent.getParameter('item'));
        //this._recalcMessageCounters();
      },

      /**
       * Sets up the data for the message popover box.
       * @method
       * @name   encollab.dp.Component#addMessage
       * @param {String} messageType
       * @param {String} messageTitle
       * @param {String} messageText
       */
      addMessage: function(messageType, messageTitle, messageText) {
        if (this.getRouter()._bIsInitialized) {
          this._setupMessagePopover();
          this.messagePopover.addItem(new MessagePopoverItem({
            type: messageType || sap.ui.core.MessageType.Information,
            title: messageTitle || 'No title',
            description: messageText
          }));
          this._recalcMessageCounters();
        }
      },
      /**
       * Recalculate the message count in the message popover box
       *
       * @method
       * @private
       * @name   encollab.dp.Component#_recalcMessageCounters
       */
      _recalcMessageCounters: function() {
        var oMessages = this.messagePopover.getItems(),
          error = 0,
          warning = 0,
          success = 0,
          info = 0;
        for (var i = 0; i < oMessages.length; i++) {
          switch (oMessages[i].getType()) {
            case sap.ui.core.MessageType.Error:
              error++;
              break;
            case sap.ui.core.MessageType.Warning:
              warning++;
              break;
            case sap.ui.core.MessageType.Success:
              success++;
              break;
            default:
              info++;
              break;
          }
        }
        this.getModel('msg').setProperty('/errorMessages', error + '');
        this.getModel('msg').setProperty('/warningMessages', warning + '');
        this.getModel('msg').setProperty('/successMessages', success + '');
        this.getModel('msg').setProperty('/infoMessages', info + '');
        this.getModel('msg').setProperty('/totalMessages', oMessages.length + '');
      },
      /**
       * Fetches the density class for the application. It's wider on desktops than mobiles
       *
       * @method
       * @name   encollab.dp.Component#getContentDensityClass
       * @return {String} density class name
       */
      getContentDensityClass: function() {
        if (!this._sContentDensityClass) {
          if (sap.ui.Device.support.touch) {
            this._sContentDensityClass = "sapUiSizeCompact";
          } else {
            this._sContentDensityClass = "sapUiSizeCozy";
          }
        }
        return this._sContentDensityClass;
      },
      /**
       * Convenience method to fetch all user data
       *
       * @method
       * @name   encollab.dp.Component#getUserData
       * @return {Object} User data
       */
      getUserData: function() {
        return this._userData;
      },
      /**
       * Convenience method to fetch user ID
       *
       * @method
       * @name   encollab.dp.Component#getMyId
       * @return {string} ID
       */
      getMyId: function() {
        return this._userData.Id;
      },
      /**
       * Convenience method to fetch sale block for user
       *
       * @method
       * @name   encollab.dp.Component#getMySaleBlock
       * @return {string} Name
       */
      getMySaleBlock: function() {
        return this._userData.SaleBlock;
      },
      /**
       * Convenience method to fetch user name
       *
       * @method
       * @name   encollab.dp.Component#getMyName
       * @return {string} Name
       */
      getMyName: function() {
        return this._userData.FullName;
      },
      /**
       * Convenience method to fetch all user dealers
       *
       * @method
       * @name   encollab.dp.Component#getMyDealers
       * @return {array<object>} Dealers
       */
      getMyDealers: function() {
        return this._userData && this._userData.Dealers ? this._userData.Dealers.results : [];
      },
      /**
       * Convenience method to fetch all a user setting
       *
       * @method
       * @name   encollab.dp.Component#getMySetting
       * @param {string} param    The parameter name
       * @return {Object} Parameter value
       */
      getMySetting: function(param) {
        for (var i = 0; i < this._userData.UserSettings.results.length; i++) {
          if (this._userData.UserSettings.results[i].Name === param) {
            return this._userData.UserSettings.results[i];
          }
        }
      },
      /**
       * Convenience method to fetch all user data
       *
       * @method
       * @name   encollab.dp.Component#getMySettingValue
       * @param {string} param    The parameter name
       * @return {object} User data
       */
      getMySettingValue: function(param) {
        return this.getMySetting(param) ? this.getMySetting(param).Value : null;
      },
      /**
       * Convenience method to fetch all user authorizzation
       *
       * @method
       * @name   encollab.dp.Component#getMyAuthorisation
       * @param {string} auth    The authorization name
       * @return {object} User authorization
       */
      getMyAuthorisation: function(auth) {
        if (this._userData) {
          return this._userData.Authorisations[auth];
        }
      }
    });
  });