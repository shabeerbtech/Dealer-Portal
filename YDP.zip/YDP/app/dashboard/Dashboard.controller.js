/**
****************************************************************************************
*  Changed on:  Changed by:   Change ID:  TR Number:        Description:
*  2017.05.24   Subha          C001       GKAK907247    PerformanceIssue in PartsReturn
*               z019767
*  31.10.2017   Praseeda                  GKAK907894       return order tile
*  2017.11.22   subha          C002       GKAK908047        Count query
*  2018.11.11   Nisha          C005       GKAK908806        Credit chk change
****************************************************************************************
*/

sap.ui.define([
    "encollab/dp/BaseController",
    "sap/ui/core/ValueState",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], 
/**
 * <p>Dashboard looks after all the tiles, updating the tile count, and handles rearranging or remove and restoring tiles.  
 * <h4>OData services used</h4>
 * <ul>
 * <li>Orders</li>
 * <li>Wty</li>
 * <li>Core</li>
 * </ul>
 * <h4>Templates used</h4>
 * <ul>
 * <li>encollab.dp.dashboard.Dashboard.view.xml</li>
 * </ul>
 * @class Dashboard
 * @memberOf encollab.dp.dashboard
 * @extends {encollab.dp.BaseController}
 * @return {encollab.dp.dashboard.Dashboard} Dashboard the definition of the controller for the dashboard module
 * 
 * @param  {encollab.dp.BaseController} Controller
 * @param  {sap.ui.core.ValueState} ValueState       
 * @param  {sap.ui.model.Filter} Filter  
 * @param  {sap.ui.FilterOperator} FilterOperator  
 */
function(Controller, ValueState, Filter, FilterOperator) {
    "use strict";
    return Controller.extend("encollab.dp.dashboard.Dashboard", {
        /**
         * Initialisation method for the Dashboard controller. It binds the user to the controller
         *
         * @method
         * @name   encollab.dp.dashboard.Dashboard#onInit
         */
        onInit: function() {
            Controller.prototype.onInit.apply(this, arguments);

            this.getView().bindElement({
                model: 'core',
                path: "/Users('SY-UNAME')"
            });
             this._SetCustomerstatus();
        },
        /**
         * After the dashboard is rendered, this method does the following things: schedule all the updates to the tile counts
         * in 5 minute intervals, en initialize a localstorage with key: <userid>dealerportal. This is to store tile settings.
         *
         * @method
         * @name   encollab.dp.dashboard.Dashboard#onInit
         */

         _SetCustomerstatus:function(){

             var custstatus =  this.myView.byId('Custstat');
             if (this.myComponent.getMySaleBlock() === true)
             {
                 custstatus.setText("Sale Order Creation Blocked");

              }
              else
              {
                  custstatus.setText(" ");
              }

         },
        onAfterViewRendered: function(oEvent) {
            Controller.prototype.onAfterViewRendered.apply(this, arguments);

            this.store = $.sap.storage($.sap.storage.Type.local, this.myComponent.getMyId() + "dealerportal");
            this._restoreTilesFromStorage();

            if (this._userAccountIsValid) {
                $.proxy(this._updateFPCount(300000), this); // Every 5 minutes
                $.proxy(this._updateUnsubmittedWtyClaims(300000), this); // Every 5 minutes
                $.proxy(this._updateUnsubmittedOrders(300000), this); // Every 5 minutes
                $.proxy(this._updateUnsubmittedSCWtyClaims(300000), this); // Every 5 minutes
                $.proxy(this._updateUnsubmittedEXWtyClaims(300000), this); // Every 5 minutes
                //BOC-C001
               // $.proxy(this._updateReturnPartsClaims(1800000), this); // Every 30 minutes
               //EOC-C001
                $.proxy(this._updateDSClaims(300000), this); // Every 5 minutes
                $.proxy(this._updateDeliveries(300000), this); // Every 5 minutes
                $.proxy(this._updatePOD(300000), this); // Every 5 minutes
//BOC-C002
               // $.proxy(this._updateROrders(300000), this); // Every 5 minutes
//EOC-C002
            }
        },
        /**
         * On pressing a tile, this method will nagivate to the tile's route pattern. 
         *
         * @method
         * @name   encollab.dp.dashboard.Dashboard#onPressTile
         * @method
         * @param {Object} oEvent   The tile press event 
         */
        onPressTile: function(oEvent) {
            var oTile = oEvent.getSource();
            this.myRouter.navTo(oTile.data().routePattern);
        },

        /**
         * If the user is an admin, return true. Else, return false.
         * @name   encollab.dp.dashboard.Dashboard#adminAuthCheck
         * @method
         * @param  {string} Id User ID
         * @return {boolean}    
         */
        adminAuthCheck: function(Id) {
            return Id ? this.getOwnerComponent().getMyAuthorisation('AdminView') : false;
        },
        /**
         * The event handler for the "edit" button. This triggers when the button is pressed, and it'll either 
         * open the edit menu, or stop editting in case it's already being editted. 
         * @method
         * @name   encollab.dp.dashboard.Dashboard#handleEditPress
         * @param  {Object} evt Press event  
         */
        handleEditPress: function(evt) {
            var dashboard = this.byId('dashboard');

            if (dashboard.getEditable() === true) {
                evt.getSource().setText(this.getModel('i18n').getProperty('dashboardOptions'));
                dashboard.setEditable(false);
                this._persistTiles();
            } else {
                this.byId('dashboardActions').openBy(evt.getSource());
            }
        },
        /**
         * The event handler for moving a tile. This method is triggered whenever a tile is dragged and dropped, 
         * in which case the new order of tiles is stored
         * @name   encollab.dp.dashboard.Dashboard#handleTileMove
         * @method
         * @param  {Object} evt Press event  
         */
        handleTileMove: function(evt) {
            this._persistTiles();
        },
        /**
         * The event handler for deleting a tile. This method is triggered whenever a tile is deleted, 
         * in which case the new order of tiles is stored
         * @name   encollab.dp.dashboard.Dashboard#handleTileDelete
         * @method
         * @param  {Object} evt Press event  
         */
        handleTileDelete: function(evt) {
            evt.getParameter('tile').setVisible(false);
            this._persistTiles();
        },
        /**
         * The event handler triggers the dashboard's editable state.  
         * @method
         * @name   encollab.dp.dashboard.Dashboard#handleEdit 
         */
        handleEdit: function(evt) {
            this.byId('dashboard').setEditable(true);
            this.byId('editButton').setText(this.getModel('i18n').getProperty('dashboardDone'));
        },
        /**
         * The event handler for the 'show' menu option. This method unhides all the previously hidden tiles
         * @name   encollab.dp.dashboard.Dashboard#handleShow
         * @method
         * @param  {Object} evt Press event  
         */
        handleShow: function(evt) {
            var tiles = this.byId('dashboard').getTiles();
            for (var i = 0; i < tiles.length; i++) {
                tiles[i].setVisible(true);
            }
            this._persistTiles();
        },
        /**
         * This method removes the local storage object
         * @method
         * @name   encollab.dp.dashboard.Dashboard#handleDelete 
         */
        handleDelete: function() {
            this.store.remove('dashboard');
        },
        /**
         * This method resets the whole dashboard, so it deletes the current preferences, moves and unhides all tiles
         * to their original positions and stores it in local storage again. 
         * @method
         * @name   encollab.dp.dashboard.Dashboard#handleRestore
         */
        handleRestore: function(evt) {

            var stored = this.store.get('dashboard');
            var dashboard = this.byId('dashboard');
            var tiles = dashboard.getTiles();

            for (var i = 0; i < tiles.length; i++) {
                tiles[i].setVisible(true);
            }

            //this, because the moveTile can't happen on an invisible tile
            //and it'll turn into a race condition. yuck. 
            window.setTimeout(function() {
                for (var i = 0; i < tiles.length; i++) {
                    if (stored && stored[tiles[i].getId()]) {
                        var pos = stored[tiles[i].getId()];
                        dashboard.moveTile(tiles[i], pos.original);
                    }
                }
                this._persistTiles();
            }.bind(this), 1)
        },
        /**
         * The event handler for deleting a tile. This method is triggered whenever a tile is deleted, 
         * in which case the new order of tiles is stored
         * @private
         * @method
         * @name   encollab.dp.dashboard.Dashboard#handleTileDelete
         * @param  {Object} evt Press event  
         */
        _restoreTilesFromStorage: function() {
            var stored = this.store.get('dashboard');
            var dashboard = this.byId('dashboard');
            var tiles = dashboard.getTiles();

            if (stored) {
                for (var i = 0; i < tiles.length; i++) {
                    if (stored && stored[tiles[i].getId()]) {
                        var pos = stored[tiles[i].getId()];
                        dashboard.moveTile(tiles[i], pos.position);
                        tiles[i].setVisible(pos.visible);
                    } else {
                        tiles[i].setVisible(true);
                    }
                }
            } else {
                var order = {};
                for (var i = 0; i < tiles.length; i++) {
                    order[tiles[i].getId()] = {
                        original: i,
                        position: i,
                        visible: true
                    }
                }
                this.store.put('dashboard', order);
            }
        },
        /**
         * The event handler for deleting a tile. This method is triggered whenever a tile is deleted, 
         * in which case the new order of tiles is stored
         * @name   encollab.dp.dashboard.Dashboard#handleTileDelete
         * @method
         * @param  {Object} evt Press event  
         */
        _persistTiles: function() {
            var stored = this.store.get('dashboard');
            var tiles = this.byId('dashboard').getTiles();
            var order = {};
            for (var i = 0; i < tiles.length; i++) {
                var obj = {
                    position: i,
                    original: i,
                    visible: tiles[i].getVisible()
                };

                if (stored && stored[tiles[i].getId()]) {
                    obj.original = stored[tiles[i].getId()].original
                }
                order[tiles[i].getId()] = obj;
            }
            this.store.put('dashboard', order);
        },

        /**
         * This method is called every 5 minutes and will use the orders oData model to update the number of unsubmitted orders on the tile
         * @name   encollab.dp.dashboard.Dashboard#_updateUnsubmittedOrders
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateUnsubmittedOrders: function(timerDelay) {
            var oTile = this.myView.byId('orderTile');
            var myId = this.myComponent.getMyId();
            if (!this._timerFuncUnsubmittedOrders) {
                this._timerFuncUnsubmittedOrders = $.proxy(function() {
                    this.getModel('orders').setUseBatch(false);
                    this.getModel('orders').read('/SalesOrderSet/$count', {
                        filters: [
                            new Filter('DeliveryBlock', FilterOperator.EQ, 'YP')
                        ],
                        urlParameters: {
                            '$top': 99999
                        },
                        success: function(oEvent, oResponse) {
                            this.getModel('orders').setUseBatch(true);
                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardPartsOrderUnit'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                        }.bind(this)
                    }, function() {
                        this.getModel('orders').setUseBatch(true);
                    }.bind(this));
                }, this);
                this._timerFuncUnsubmittedOrders();
                setInterval(this._timerFuncUnsubmittedOrders, timerDelay);
            }
        },

/**
         * This method is called every 5 minutes and will use the orders oData model to update the number of return orders on the tile
         * @name   encollab.dp.dashboard.Dashboard#_updateROrders
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds
         */
        _updateROrders: function(timerDelay) {
            var oTile = this.myView.byId('ReturnOrderTile');
            var myId = this.myComponent.getMyId();
            var firstDate = '20171031';
            var lastDate = '20171031';
            if (!this._timerFuncROrders) {
                this._timerFuncROrders = $.proxy(function() {
                    this.getModel('ROrders').setUseBatch(false);
                    this.getModel('ROrders').read('/ReturnOrderSet/$count', {
                        // filters: [
                        //   new Filter('OrdDate', FilterOperator.BT, firstDate, lastDate)
                        // ],
                        urlParameters: {
                            '$top': 99999
                        },
                        success: function(oEvent, oResponse) {
                            this.getModel('ROrders').setUseBatch(true);
                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                        }.bind(this)
                    }, function() {
                        this.getModel('ROrders').setUseBatch(true);
                    }.bind(this));
                }, this);
                this._timerFuncROrders();
                setInterval(this._timerFuncROrders, timerDelay);
            }
        },

        /**
         * This method is called every 5 minutes and will use the orders oData model to update the number of
         * orders that still need to be updated with a proof of delivery date
         * @name   encollab.dp.dashboard.Dashboard#_updatePOD
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updatePOD: function(timerDelay) {
            var oTile = this.myView.byId('podTile');
            var myId = this.myComponent.getMyId();
            if (!this._timerFuncPOD) {
                this._timerFuncPOD = $.proxy(function() {

                    this.getModel('orders').read('/Deliveries/$count', {
                        filters: [
                            new Filter('PODDate', FilterOperator.EQ, null)
                        ],
                        urlParameters: {
                            '$top': 99999
                        },
                        success: function(oEvent, oResponse) {

                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardPODDate'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                        }.bind(this)
                    });
                }, this);
                this._timerFuncPOD();
                setInterval(this._timerFuncPOD, timerDelay);
            }
        },
        /**
         * This method is called every 5 minutes and will use the orders oData model to update the number of 
         * deliveries due today
         * @name   encollab.dp.dashboard.Dashboard#_updateDeliveries
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateDeliveries: function(timerDelay) {
            var oTile = this.myView.byId('deliveriesTile');
            var myId = this.myComponent.getMyId();
            if (!this._timerFuncDel) {
                this._timerFuncDel = $.proxy(function() {

                    this.getModel('orders').read('/Deliveries/$count', {
                        filters: [
                            new Filter('Delivered', FilterOperator.EQ, this.accountForUTCDate(new Date()))
                        ],
                        success: function(oEvent, oResponse) {

                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardDeliveryUnit'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                        }.bind(this),
                        error: function() {

                        }.bind(this)
                    });
                }, this);
                this._timerFuncDel();
                setInterval(this._timerFuncDel, timerDelay);
            }
        },
        /**
         * This method is called every 5 minutes and will use the wty oData model to update the number of 
         * return parts claims
         * @name   encollab.dp.dashboard.Dashboard#_updateReturnPartsClaims
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateReturnPartsClaims: function(timerDelay) {
            var oTile = this.myView.byId('returnsTile');
            var myId = this.myComponent.getMyId();
            if (!this._timerFuncDS) {
                this._timerFuncRet = $.proxy(function() {
                     
                    this.getModel('wty').read('/WarrantyClaimsWithReturnItems/$count', {
                        success: function(oEvent, oResponse) {

                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardReturnsUnit'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                             
                        }.bind(this)
                    });
                }, this);
                this._timerFuncRet();
                setInterval(this._timerFuncRet, timerDelay);
            }
        },
        /**
         * This method is called every 5 minutes and will use the wty oData model to update the number of 
         * direct swap claims
         * @name   encollab.dp.dashboard.Dashboard#_updateDSClaims
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateDSClaims: function(timerDelay) {
            var oTile = this.myView.byId('dsTile');
            var myId = this.myComponent.getMyId();
            if (!this._timerFuncDS) {
                this._timerFuncDS = $.proxy(function() {
                     
                    this.getModel('wty').read('/WarrantyClaimsWithDirectSwap/$count', {
                        success: function(oEvent, oResponse) {
                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardReturnsUnit'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                             
                        }.bind(this)
                    });
                }, this);
                this._timerFuncDS();
                setInterval(this._timerFuncDS, timerDelay);
            }
        },
        /**
         * This method is called every 5 minutes and will use the wty oData model to update the number of 
         * unsubmitted wty claims
         * @name   encollab.dp.dashboard.Dashboard#_updateUnsubmittedWtyClaims
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateUnsubmittedWtyClaims: function(timerDelay) {
            var oTile = this.myView.byId('wtyTile');
            var myId = this.myComponent.getMyId();
            var statusFilter = new Filter([
                new Filter('StatusId', FilterOperator.EQ, '0005'),
                new Filter('StatusId', FilterOperator.EQ, '0135')
            ], false);

            if (!this._timerFunc) {
                this._timerFuncWty = $.proxy(function() {
                     
                    this.getModel('wty').read('/FPClaims/$count', {
                        filters: [statusFilter],
                        urlParameters: {
                            '$top': 99999
                        },
                        success: function(oEvent, oResponse) {

                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardWarrantyClaimsUnsubmitted'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                             
                        }.bind(this)
                    });
                }, this);
                this._timerFuncWty();
                setInterval(this._timerFuncWty, timerDelay);
            }
        },
        /**
         * This method is called every 5 minutes and will use the wty oData model to update the number of 
         * spare parts claims    
         * @name   encollab.dp.dashboard.Dashboard#_updateUnsubmittedSPWtyClaims
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateUnsubmittedSPWtyClaims: function(timerDelay) {
            var oTile = this.myView.byId('wtySPTile');
            var myId = this.myComponent.getMyId();
            var statusFilter = new Filter([
                new Filter('StatusId', FilterOperator.EQ, '0005'),
                new Filter('StatusId', FilterOperator.EQ, '0135')
            ], false);

            if (!this._timerFunc) {
                this._timerFuncWty = $.proxy(function() {
                    
                    this.getModel('wty').read('/WarrantyClaims/$count', {
                        filters: [
                            new Filter([
                                statusFilter,
                                new Filter('Qualifier', FilterOperator.EQ, 'SP')
                            ], true)
                        ],
                        success: function(oEvent, oResponse) {

                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardWarrantyClaimsUnsubmitted'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                             
                        }.bind(this)
                    });
                }, this);
                this._timerFuncWty();
                setInterval(this._timerFuncWty, timerDelay);
            }
        },
        /**
         * This method is called every 5 minutes and will use the wty oData model to update the number of
         * unsubmitted shipment cost claims
         * @name   encollab.dp.dashboard.Dashboard#_updateUnsubmittedSCWtyClaims
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateUnsubmittedSCWtyClaims: function(timerDelay) {
            var oTile = this.myView.byId('wtySCTile');
            var myId = this.myComponent.getMyId();
            var statusFilter = new Filter([
                new Filter('StatusId', FilterOperator.EQ, '0005'),
                new Filter('StatusId', FilterOperator.EQ, '0135')
            ], false);

            if (!this._timerFunc) {
                this._timerFuncWty = $.proxy(function() {
                     
                    this.getModel('wty').read('/WarrantyClaims/$count', {
                        filters: [
                            new Filter([
                                statusFilter,
                                new Filter('Qualifier', FilterOperator.EQ, 'SC')
                            ], true)
                        ],
                        success: function(oEvent, oResponse) {

                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardWarrantyClaimsUnsubmitted'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                             
                        }.bind(this)
                    });
                }, this);
                this._timerFuncWty();
                setInterval(this._timerFuncWty, timerDelay);
            }
        },
        /**
         * This method is called every 5 minutes and will use the wty oData model to update the number of
         * EX claims
         * @name   encollab.dp.dashboard.Dashboard#_updateUnsubmittedEXWtyClaims
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateUnsubmittedEXWtyClaims: function(timerDelay) {
            var oTile = this.myView.byId('wtyEXTile');
            var myId = this.myComponent.getMyId();
            var statusFilter = new Filter([
                new Filter('StatusId', FilterOperator.EQ, '0005'),
                new Filter('StatusId', FilterOperator.EQ, '0135')
            ], false);

            if (!this._timerFunc) {
                this._timerFuncWty = $.proxy(function() {
                     
                    this.getModel('wty').read('/WarrantyClaims/$count', {
                        filters: [
                            new Filter([
                                statusFilter,
                                new Filter('Qualifier', FilterOperator.EQ, 'EX')
                            ], true)
                        ],
                        success: function(oEvent, oResponse) {

                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardWarrantyClaimsUnsubmitted'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                             
                        }.bind(this)
                    });
                }, this);
                this._timerFuncWty();
                setInterval(this._timerFuncWty, timerDelay);
            }
        },
        /**
         * This method is called every 5 minutes and will use the wty oData model to update the number FP updates
         * @name   encollab.dp.dashboard.Dashboard#_updateFPCount
         * @method
         * @private
         * @param  {Object} timerDelay delay in milliseconds 
         */
        _updateFPCount: function(timerDelay) {
            var oTile = this.myView.byId('fpTile');
            var myId = this.myComponent.getMyId();
            if (!this._timerFuncFp) {
                this._timerFuncFp = $.proxy(function() {
                     
                    this.getModel('wty').read('/FPClaims/$count', {
                        filters: [
                            new Filter({
                                filters: [new Filter('StatusId', FilterOperator.EQ, '0125')],
                                and: false
                            }),
                            new Filter('ReceiptNo', FilterOperator.EQ, ''),
                        ],
                        urlParameters: {
                            '$top': 99999
                        },
                        success: function(oEvent, oResponse) {

                            var count = Number(oResponse.body);
                            oTile.setNumber(count);
                            oTile.setInfo(count + ' ' + this.getModel('i18n').getProperty('dashboardFakturPajakOutstanding'));
                            if (count > 0) {
                                oTile.setInfoState(ValueState.Error);
                            } else {
                                oTile.setInfoState(ValueState.Success);
                            }
                             
                        }.bind(this)
                    });
                }, this);
                this._timerFuncFp();
                setInterval(this._timerFuncFp, timerDelay);
            }
        }
    });
});