/**
****************************************************************************************
*  Changed on:  Changed by:   Change ID:  TR Number:        Description:
*  2017.05.10   Subha          C001      GKAK907167        SUBMIT and ADD button
*               z019767                                 enable & disable based on condition.
*                                                       Mileage checks
* 2017.05.18   Subha-z019767   C002      GKAK907208     MessageToast Text
*****************************************************************************************
*/

sap.ui.define([
        "encollab/dp/serct/BaseController",
        "sap/m/MessageBox",
        "sap/m/MessageToast",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/unified/FileUploaderParameter",
        "sap/ui/core/Item",
        "sap/ui/model/json/JSONModel",
        "sap/m/UploadCollectionParameter"
    ],
    /**
     * <p>This acts as the controller for the creation of every qualifier claim, some of which have their own tile, while others go through 
    
     */
    function(Controller, MessageBox, MessageToast, Filter, FilterOperator, FileUploaderParameter, Item, JSONModel, UploadCollectionParameter) {
        "use strict";
        return Controller.extend("encollab.dp.serct.ServicePgmDetail", {
            _userAuthorisations: ['WarrantyClaims'],
            
            
                        _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
            /**
             * Variable that tracks wether the current claim is related to a vehicle or not
             * @type {boolean}
             * @name   encollab.dp.wty.Detail#_vehicleClaim
             */
            _vehicleClaim: false,
            /**
             * Initialization of the controller
             * @name   encollab.dp.wty.Detail#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);

                if (this._userAccountIsValid) {
                    this.setModel(new JSONModel(), "viewModel");
                    this.myRouter.getRoute("serctdetail").attachPatternMatched(this._onObjectMatched, this);
                }
            },
            /**
             * When the route matches, the current claim is fetched from SAP and bound to the view. 
             * @name   encollab.dp.wty.Detail#_onObjectMatched
             * @method
             */
            _onObjectMatched: function(oEvent) {
                var oView = this.myView;
                oView.setBusy(true);
                var sserctPath = "/" + oEvent.getParameter("arguments").serctPath;
                this.resetMessagePopover();
                oView.bindElement({
                    model: 'serct',
                    path: sserctPath,
                    parameters: {
                        expand: 'ServiceCtItems,ServctAttachments' //,Changer' //,WtyHeaderAttachments'
                    },
                    events: {
                        dataRequested: this._dataRequested.bind(this),
                        dataReceived: this._dataReceived.bind(this),
                        change: this._dataChanged.bind(this)
                    }
                });
                //Check if the data is already on the client
                if (!this.getModel('serct').getData(sserctPath + '/ServiceCtItems')) {
                    // Check that the part specified actually was found.
                    oView.getElementBinding('serct').attachEventOnce("dataReceived", jQuery.proxy(function() {
                        var oData = this.getModel('serct').getData(sserctPath);
                        if (!oData) {
                            this.fireDetailNotFound();
                        } else {
                            this.fireDetailChanged(sserctPath);
                        }
                    }, this));
                    oView.setBusy(false);
                } else {
                    this.fireDetailChanged(sserctPath);
                }
            },
             _dataRequested: function() {
                this.getView().setBusy(true);
            },
            _dataReceived: function(oEvent) {
                this._setup(oEvent.getParameter('data'));
            },
            _dataChanged: function(oEvent) {
                if (this.getView().getBindingContext('serct')) {
                    var data = this.getModel('serct').getProperty(this.getView().getBindingContext('serct').getPath());
                    this._setup(data);
                }

            },
            
             fireDetailChanged: function(sWtyPath) {
                this.getView().setBusy(false);
            },
            fireDetailNotFound: function() {},
            _setup: function(oData) 
            {
                this.getView().setBusy(true);
                var path = this.getView().getBindingContext('serct').getPath();
                var data = this._expandElementBindingToData(path, this.getModel('serct'));
                var out = this._formatForDownload(data);
                this.byId('idWtyButtonDownload').setData(out);

                // Set all flags to false
                var viewModel = this.getModel('viewModel');
                viewModel.setProperty('/isMyDealer', false);
                viewModel.setProperty('/isChangeable', false);
                viewModel.setProperty('/isTextsChangeable', false);
                viewModel.setProperty('/isAttachmentsChangeable', false);
                viewModel.setProperty('/isSubmitable', false);
                viewModel.setProperty('/isReadyToSubmit', false);
               
                viewModel.setProperty('/isVehicleClaim', true);
                  if (this.getOwnerComponent().getMyDealers().filter(
                        function(a) {
                            return a.Id === oData.Dealer;
                        }).length !== 0) {
                    viewModel.setProperty('/isMyDealer', true);
                    viewModel.setProperty('/isDeleteable', true);
                    viewModel.setProperty('/isAttachmentsChangeable', true);
                    viewModel.setProperty('/isChangeable', true);
                        }
                this.getView().setBusy(false);
            },
            
            itemRoleFormatter: function(itemtype, causalPart) {
                if (causalPart) {
                    switch (itemtype) {
                        case 'MAT':
                            return 'CausalPart';
                        case 'FR':
                            return 'CausalLabour';
                        default:
                            return 'CausalOther';
                    }
                }
            },
            
               onIconTabBarSelect: function(oEvent) {
                var oTabItem = oEvent.getParameter('item');
                if (oTabItem.getId().indexOf('iconTabTexts') != -1) {
                    //this._checkInchcapeTexts();
                }
            },
            /**
             * Should the attachments be displayed?
             * @name   encollab.dp.wty.Detail#attachmentsVisible
             * @method
             */
            attachmentsVisible: function(obj) {
                return this.isChangeable() || this.formatter.arrayCountVisible(obj);
            },
            /**
             * Creates the URL for an attachment
             * @name   encollab.dp.wty.Detail#attachmentURL
             * @param {string} docid
             * @method
             */
            attachmentURL: function(docid) {
                return this.getModel('serct').sServiceUrl + "/ServctAttachments('" + docid + "')/$value";
            },
            /**
             * Creates the URL for an attachment
             * @name   encollab.dp.wty.Detail#thumbnailURL
             * @param {string} mimetype 
             * @param {string} docid
             * @method
             */
            thumbnailURL: function(mimetype, docid) {
                return mimetype.substr(0, 5) === 'image' ? this.attachmentURL(docid) : null;
            },
            /**
             * Can the current claim be submitted
             * @name   encollab.dp.wty.Detail#isReadyToSubmit
             * @method
             */
             isReadyToSubmit: function(obj) {
                if (this.isChangeable()) {
                    if (this.getView().getBindingContext('serct')) {
                        return this._checkDataComplete();
                    }
                }
            },
            
            /**
             * @name   encollab.dp.wty.Detail#itemTypeFormatter
             * @param {string} itemType
             * @param {causal} causal
             * @return {string}
             * @method
             */
            itemTypeFormatter: function(itemType, causal) {
                return causal ? this.getText('causal' + itemType) : this.getText('itemText' + itemType);
            },
            
              onExit: function() {
                if (this._oPopover) {
                    this._oPopover.destroy();
                }
            },
            
             onVINPressed: function(oEvent) {
                this.getRouter().navTo("vindetail", {
                    vehiclePath: this.getView().getBindingContext('serct').getProperty("VIN") //getPath().substr(1)
                });

            },
            
            
            onItemPress: function(oEvent) {
                var partId = oEvent.getSource().getBindingContext('serct').getObject().Part;
                if (partId) {
                    this.myRouter.navTo("partsdetail", {
                        partPath: partId
                    });
                }
            },
            materialPopoverGo: function(oEvent) {
                this.materialPopoverClose();
                var oItem = oEvent.getSource();
                if (oItem) {
                    this.myRouter.navTo("partsdetail", {
                        materialPath: oItem.getBindingContext('serct').getPath().substr(1)
                    });
                }
            },
            materialPopoverClose: function(oEvent) {
                this._oMaterialPopover.close();
            },
            
             onClaimSubmit: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.serct.claimSubmitDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('serct').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            onSubmitClaimDialogConfirm: function(oEvent) {
                this._performAction('Z006'); //, this.getText("submitWtyDialogSuccessMsg"));
            },
                onClaimDelete: function(oEvent) {
                this._oDialog = sap.ui.xmlfragment("encollab.dp.serct.claimDeleteDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('serct').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            onDeleteOrderDialogConfirm: function(oEvent) {
                // get texts
                var successMsg = this.getText("deleteWtyDialogSuccessMsg");

                this.busyDialog.open();
                this.onDialogCancel();
                this.resetMessagePopover();
                this._performAction('Z007', successMsg);
            },
            
             onDialogCancel: function(oEvent) {
                try {
                    this._oDialog.close().destroy();
                } catch (err) {}
            },
                /**
             * Callback for upload change. 
             * @name   encollab.dp.wty.Detail#onAttachUploadChange
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAttachUploadChange: function(oEvent) {
                var csrf = this.getModel('serct').getSecurityToken();
                var oUploader = oEvent.getSource();
                var fileName = oEvent.getParameter('files')[0].name;
                oUploader.removeAllHeaderParameters();
                oUploader.insertHeaderParameter(new UploadCollectionParameter({
                    name: 'x-csrf-token',
                    value: csrf
                }));
                oUploader.insertHeaderParameter(new UploadCollectionParameter({
                    name: 'Slug',
                    value: fileName
                }));
            },
            /**
             * Callback for upload delete. 
             * @name   encollab.dp.wty.Detail#onAttachDelete
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAttachDelete: function(oEvent) {
                var sPath = oEvent.getParameter('item').getBindingContext('serct').getPath();
                var oModel = this.getModel('serct');
                this.busyDialog.open();
                this.resetMessagePopover();
                oModel.remove(sPath, {
                    success: jQuery.proxy(function(odata, response) {
                        this.busyDialog.close();
                        oModel.refresh();
                    }, this),
                    error: jQuery.proxy(function(oError) {
                        this.busyDialog.close();
                        this.gatewayError(oError);
                    }, this)
                });
            },
            /**
             * Callback for upload complete. 
             * @name   encollab.dp.wty.Detail#onAttachUploadComplete
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAttachUploadComplete: function(oEvent) {
                this.resetMessagePopover();
                var mParams = oEvent.getParameter('mParameters');
                if (mParams.status > 299) {
                    this.errorMessage('Status ' + mParams.status, mParams.response);
                } else {
                    this.getModel('serct').refresh();
                }
            },
            headerUrl: function(guid) {
                return guid ?
                    this.getModel('serct').sServiceUrl + this.getView().getBindingContext('serct').getPath() :
                    guid;
            },
            
            
             _performAction: function(action, successMsg) {

                this.busyDialog.open();
                this.onDialogCancel();
                this.resetMessagePopover();

                var oClaim = this.getView().getBindingContext('serct').getObject();
                //var oParams = {
               //     ClaimNo: oClaim.ClaimNo
                  
              //  };

                this.getModel('serct').remove("/Servicects('"+oClaim.ClaimNo+"')", {
                    method: 'DELETE',
                    
                    success: $.proxy(function(oData,response)
                    {
                        if (successMsg) {
                            MessageToast.show(successMsg);
                        }
                        this._parseMessages(sap.ui.getCore().getMessageManager().getMessageModel().getData());
                        //  For some reason a model refresh didn't work for the buttons
                        this.getModel('serct').refresh();
                        //this.getModel('wty').updateBindings(true);
                        this.busyDialog.close();

                        //location.reload(); // Last resort
                    }, this),
                    error: $.proxy(function(oError) {
                        this.gatewayError(oError);
                    }, this)
                });
            },
            
            
               onNavBack: function() {
                Controller.prototype.onNavBack.apply(this, ["serct"]);
            }
        });
    });