sap.ui.define([
	"encollab/dp/controls/SearchToolBar",
	"sap/m/ToolbarRenderer",
	"sap/m/Select",
	"sap/ui/core/Item"
], function(Toolbar, Renderer, Select, Item) {

	return Toolbar.extend('encollab.dp.controls.OrderSearchToolbar', {
		metadata: {
			events: {
				type: {}
			}
		},
		renderer: function(elem, control) {
			Renderer.render(elem, control);
		},

		init: function() {
			Toolbar.prototype.init.apply(this, arguments);

			this._typeselect = new Select({
				change: this._onTypeSelect.bind(this),
				items: [
					new Item({
						key: 'h',
						text: 'Order headers'
					}),
					new Item({
						key: 'l',
						text: 'Order details'
					})
				]
			});

			this.addContent(this._typeselect);
		},

		_onTypeSelect: function(oEvent) {
			this.fireType({
				key: this._typeselect.getSelectedKey()
			});
		}
	});
});