sap.ui.define([
    "sap/m/Button",
    "sap/m/ButtonRenderer",
    "sap/m/MessageToast",
    "sap/m/ButtonType",
    "encollab/dp/controls/FileSaver",
    "encollab/dp/util/formatter"
], function(Button, Renderer, Msg, ButtonType, FileSaver, formatter) {

    return Button.extend("encollab.dp.controls.DownloadTableButton", {
        metadata: {
            properties: {
                table: 'string',
                expand: 'string',
                header: 'function'
            }
        },

        _controls: {},
        _view: {},
        _table: null,

        renderer: function(elem, control) {
            Renderer.render(elem, control);
        },

        onAfterRendering: function() {
            this._view = this.getParent(),
                i = 0;

            //keep getting parent until byId is defined. This is in all likelyhood the
            //view. try 10 times, it's not gonna be nested that deeply. 
            while (typeof this._view.byId !== 'function' && i++ < 10) {
                this._view = this._view.getParent();
            }

            this._table = this._view.byId(this.getTable());

            try {
                var isFileSaverSupported = !!new Blob;
            } catch (e) {}

            if (isFileSaverSupported !== true || typeof this._table === 'undefined') {
                this.setEnabled(false);
            }

            this.setIcon('sap-icon://download-from-cloud');
        },

        init: function() {
            this.attachPress(this._onPress.bind(this));
        },
        _onPress: function() {
            var visible = this._table.getBinding('rows').getContexts();
            var data = [];
            for (var i = 0; i < visible.length; i++) {
                var d = visible[i].oModel.getProperty(visible[i].sPath);
                var copy = $.extend({}, d);

                delete copy.__metadata;
                delete copy.Searcher;
                $.each(copy, function(k, v) {
                    if (v && v.__deferred) delete copy[k];
                });

                if (copy[this.getExpand()] && d[this.getExpand()].results && d[this.getExpand()].results.length > 0) {
                    var expand = $.extend({}, d[this.getExpand()].results);
                    delete copy[this.getExpand()];

                    $.each(expand, function(ek, ev) {
                        var newcopy = $.extend({}, copy);
                        $.each(ev, function(k, v) {
                            v = v || {};
                            if (k !== '__metadata' && typeof v.__deferred === 'undefined' && typeof copy[k] === 'undefined') {
                                newcopy[k] = v;
                            }
                        });
                        data.push(newcopy);
                    });
                } else {
                    $.each(copy, function(k, v) {
                        if (v && v.results) delete copy[k];
                    });
                    data.push(copy);
                }
            }

            this._download(data);
        },
        _download: function(data) {
            var csv = this._dataToCSV(data);

            var blob = new Blob([csv], {
                type: "data:text/csv;charset=utf-8"
            });
            FileSaver(blob, this.getTable() + '.csv');
        },
        _dataToCSV: function(data) {
            var string = '';
            var line = [];
            var header = 0;
            //find longest line in case of expand
            $.each(data, function(k, v) {
                if (v.length > data[header].length) header = k;
            });
            //make header line
            for (var a in data[header]) {
                line.push('"' + this._format(a) + '"')
            }
            string += line.join(',') + '\n';

            for (var d = 0; d < data.length; d++) {
                line = [];
                for (var a in data[d]) {
                    line.push('"' + this._format(data[d][a]) + '"');
                }
                string += line.join(',') + '\n';
            }
            return string;
        },
        _format: function(b) {
            if (b === null || typeof b === 'undefined') {
                return '';
            } else if (b.__edmType === "Edm.Time") {
                b = formatter.Time(b.ms).toString();
            } else if (b instanceof Date) {
                b = formatter.ShortDate(b);
            } else if (typeof b === 'number') {
                b = b.toString().trim();
            } else if (typeof b === 'object') {
                b = '';
            } else {
                b = b.toString().trim();
            }

            return b.replace(/[,]/gi, '-');
        }
    });
});