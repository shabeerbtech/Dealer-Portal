sap.ui.define([
	"sap/m/Dialog",
	"sap/m/DialogRenderer",
	"sap/m/Title",
	"sap/m/VBox",
	"sap/m/Input",
	"sap/m/Button"
], function(Dialog, Renderer, Text, VBox, Input, Button) {

	return Dialog.extend("encollab.dp.controls.ValueDialog", {
		metadata: {
			properties: {
				question: 'string',
				value: 'string',
				inputClass: 'string',
				positive: {
					type: "boolean",
					defaultValue: true
				}
			},
			events: {
				liveChange: {},
				onConfirm: {}
			}
		},

		_controls: {},

		renderer: function(elem, control) {
			Renderer.render(elem, control);
		},

		onAfterRendering: function() {
			this._controls.question.setText(this.getQuestion());
			this._controls.input.setValue(parseInt(this.getValue()));
			this._controls.input.addStyleClass(this.getInputClass())
		},

		init: function() {

			Dialog.prototype.init.apply(this, arguments);

			this.setContentWidth("30rem");
			this.setContentHeight("8rem");

			var flex = new VBox({
				alignItems: "Start",
				justifyContent: "Center",
			});

			flex.addStyleClass('sapUiSmallMargin')

			this._controls.question = new Text({
				styleClass: "sapUiSmallMarginBottom"
			});

			this._controls.input = new Input({
				type: 'Number',
				width: '28rem',

				liveChange: this._onLiveChange.bind(this)
			});

			this._controls.input.addStyleClass('itemQtyChange');

			flex.addItem(this._controls.question);
			flex.addItem(this._controls.input);

			this.addContent(flex);

			this.addButton(new Button({
				text: 'Cancel',
				press: this._onValueDialogCancel.bind(this)
			}));

			this.addButton(new Button({
				text: 'Confirm',
				press: this._onValueDialogConfirm.bind(this)
			}));
		},

		_onLiveChange: function(oEvent) {

			if (this.getPositive() === true && this._controls.input.getValue() < 0) {
				this._controls.input.setValue(0)
			}
			this.fireLiveChange({
				value: this._controls.input.getValue()
			});
		},

		_onValueDialogCancel: function(oEvent) {
			this.close();
		},

		_onValueDialogConfirm: function(oEvent) {
			if (this.getPositive() === true && this._controls.input.getValue() < 0) {
				this._controls.input.setValue(0)
			} else {
				this.setValue(this._controls.input.getValue());
				this.fireOnConfirm({
					value: this._controls.input.getValue()
				});
				this.close();
			}
		}
	});
});