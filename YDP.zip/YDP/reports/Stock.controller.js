sap.ui.define([
        "encollab/dp/BaseController",
        "sap/m/MessageToast",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/json/JSONModel",
    ],
    /**
     * <p>Controller for the Stock upload program. Dealers can maintain a list of stock, so that other dealers can find out who in the area 
     * has spare parts if they are in a hurry, or not available from Nissan at the time</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Parts</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.reports.Stock.view.xml <small>main view</small></li>
     * </ul>
     * @class Stock
     * @memberOf encollab.dp.reports
     * @extends {encollab.dp.BaseController}
     * @return {encollab.dp.reports.Stock}
     * 
     * @param  {encollab.dp.BaseController} Controller     
     * @param  {sap.m.MessageToast} MessageToast   
     * @param  {sap.ui.model.Filter} Filter         
     * @param  {sap.ui.model.FilterOperator} FilterOperator 
     * @param  {sap.ui.model.json.JSONModel} JSONModel
     */
    function(Controller, MessageToast, Filter, FilterOperator, JSONModel) {
        "use strict";
        return Controller.extend("encollab.dp.reports.Stock", {
            _userAuthorisations: ['PartEnquiry'],
            /**
             * This array holds the user parameters required to run this controller. In this case, the user has to be set up
             * with SPA, VKO, VTW (the entire sales area), and WRK (plant)
             *
             * @private
             * @member
             * @name   encollab.dp.parts.Detail#_userParameters
             */
            _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
            /**
             * Initialization of the controller
             * @name   encollab.dp.reports.Returns#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);
                this.model = new JSONModel({
                    count: 0,
                    orders: [],
                    url: this.getRelativeUrl()
                });
                this.model.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
                this.setModel(this.model, 'data');
                this.myRouter.getRoute("stock").attachPatternMatched(this._onObjectMatched, this);
            },
            /**
             * When starting the report, Stock is loaded from SAP. This is stored in a custom table
             * @name   encollab.dp.reports.Returns#_onObjectMatched
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _onObjectMatched: function(oEvent) {

                this.byId('stockTable').setBusy(true);
                this.getModel('part').read('/InventorySet', {
                    urlParameters: {
                        '$top': 999999
                    },
                    success: function(data) {
                        this.byId('stockTable').setBusy(false);
                        this.model.setProperty('/stock', []);
                        this.model.setProperty('/stock', this._prepareResults(data.results));
                        this.model.setProperty('/count', data.results.length);
                    }.bind(this)
                });

            },
            /**
             * Data is prepared before it's loaded into the report. The main thing that gets calculated is how old the current stock levels are
             * for the parts that have already been uploaded
             * @name   encollab.dp.reports.Returns#_prepareResults
             * @return {array<object>} 
             * @param {array<object>} data
             * @method
             */
            _prepareResults: function(data) {

                for (var d = 0; d < data.length; d++) {
                    var diff = (new Date() - data[d].CreatedDate) / (1000 * 60 * 60 * 24);
                    data[d].Overdue = (diff > 14) ? 2 : (diff > 7) ? 1 : 0
                }

                return data;
            },
            _onBindingChange: function() {

                var oView = this.getView(),
                    oElementBinding = oView.getElementBinding('part');

            },
            /**
             * Dealer interacts with the report by dropping a CSV onto it. CSV has three columns: part dealer and qty. This parses the data, puts 
             * it in the correct JSON formats and finally, uploads it to SAP. Due to SAP Gateway's rules, this is done one by one. 
             * @name   encollab.dp.reports.Returns#onFileDrop
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onFileDrop: function(oEvent) {
                var dealerError = this.getModel('i18n').getProperty('stockDealerError');
                var fileError = this.getModel('i18n').getProperty('stockFileError');
                var failed = false;
                var msg;

                this.byId('stockTable').setBusy(true);
                var data = oEvent.getParameter('data');

                var structure = [];

                for (var i = 0; i < data.length && failed === false; i++) {
                    if (typeof data[i] !== 'undefined' && data[i].length !== 0 && data[i].join() !== "") {
                        if (data[i].length === 3) {
                            var dealer = this._checkDealerAllowed(data[i][1].trim());
                            var num = parseInt(data[i][2]).toFixed(2).trim();
                            if (dealer !== false) {
                                failed = true
                            }
                            structure.push(this._getItemStructure(data[i][0].trim(), data[i][1].trim(), num));
                        } else {
                            this.dropped = 0;
                            failed = true;
                        }
                    }
                }

                if (failed !== false || structure.length === 0) {
                    msg = (dealer !== false) ? dealerError + ': ' + dealer : fileError
                    this.errorMessage(this.getModel('i18n').getProperty('stockUploadError'), msg);
                    this.byId('stockTable').setBusy(false);
                    MessageToast.show(this.getModel('i18n').getProperty('stockUploadError'));
                } else {
                    this.dropped = structure.length;
                    for (var s in structure) {
                        this.getModel('part').create('/InventorySet', structure[s], {
                            success: this._onCreateItemSuccess.bind(this),
                            error: this._onCreateItemError.bind(this)
                        });
                    }
                }

            },
            /**
             * Checks if the dealer entered in the CSV is valid for the person logged in. 
             * @name   encollab.dp.reports.Returns#_checkDealerAllowed
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _checkDealerAllowed: function(dealer) {
                var dealers = this.getModel('core').getProperty("/Users('" + this.myComponent.getMyId() + "')/Dealers");
                for (var d = 0; d < dealers.length; d++) {
                    if (dealers[d].match(/'(.*)'/i)[1] === dealer) {
                        return false;
                    }
                }
                return dealer;
            },
            /**
             * When the uploads are succesful, refresh the list. 
             * @name   encollab.dp.reports.Returns#_onCreateItemSuccess
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _onCreateItemSuccess: function(oEvent) {
                var title = this.getModel('i18n').getProperty('stockUploadSuccessTitle');
                var msg = this.getModel('i18n').getProperty('stockUploadSuccessMessage');
                this.byId('stockTable').setBusy(false);
                this.dropped--;
                if (this.dropped === 0) {
                    this._onObjectMatched();
                    this.successMessage(title, msg);
                    MessageToast.show(title);
                }
            },
            /**
             * Shows an error on Gateway fail
             * @name   encollab.dp.reports.Returns#_onCreateItemError
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _onCreateItemError: function(oEvent) {
                this.byId('stockTable').setBusy(false);
                this.gatewayError(oEvent);
            },
            /**
             * Sets the icon based on overdue status
             * @name   encollab.dp.reports.Returns#overdueIcon
             * @param {string} status
             * @method
             */
            overdueIcon: function(status) {
                return (status === 2) ? 'sap-icon://error' : (status === 1) ? 'sap-icon://warning' : 'sap-icon://accept'
            },
            /**
             * Adds text based on the overdue status
             * @name   encollab.dp.reports.Returns#overdueText
             * @param {string} status
             * @method
             */
            overdueText: function(status) {
                var success = this.getModel('i18n').getProperty('stockDetailSuccess');
                var warning = this.getModel('i18n').getProperty('stockDetailWarning');
                var error = this.getModel('i18n').getProperty('stockDetailError');
                return (status === 2) ? error : (status === 1) ? warning : success;
            },
            /**
             * Opens the "how to" dialog information window
             * @name   encollab.dp.reports.Returns#onHowToButton
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onHowToButton: function(oEvent) {
                this.byId('stockDialog').open();
            },
            /**
             * Closes the "how-to" window
             * @name   encollab.dp.reports.Returns#onDialogCancel
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onDialogCancel: function(oEvent) {
                this.byId('stockDialog').close();
            },
            /**
             * Sets the status for the overdue field
             * @name   encollab.dp.reports.Returns#overdueStatus
             * @return {string} 
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            overdueStatus: function(status) {
                return (status === 2) ? 'Error' : (status === 1) ? 'Warning' : 'Success'
            },
            /**
             * Calculates the age status. 
             * @name   encollab.dp.reports.Returns#stockAgeStatus
             * @return {string} 
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            stockAgeStatus: function(date) {
                var diff = (new Date() - date) / (1000 * 60 * 60 * 24); // difference converted to days

                if (diff > 14) {
                    return 'Error'
                } else if (diff > 7) {
                    return 'Warning'
                }

                return 'Success'
            },
            /**
             * Displays an error when the file fails
             * @name   encollab.dp.reports.Returns#onFileError
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onFileError: function(oEvent) {
                var text = oEvent.getParameter('message');
                MessageToast.show(text);
                this.errorMessage('File upload error', text);
            },
            onNavBack: function() {
                Controller.prototype.onNavBack.apply(this, ["parts"]);
            },
            /**
             * Returns a JSON structure for the Stock dataset
             * @name   encollab.dp.reports.Returns#_getItemStructure
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _getItemStructure: function(mat, cust, amount) {
                return {
                    City: "X",
                    CreatedBy: "X",
                    CreatedDate: new Date(),
                    Customer: cust,
                    Material: mat,
                    MaterialDescr: "X",
                    Name: "X",
                    PhoneNumber: "X",
                    Stock: amount,
                    Street: "X",
                    Uom: "EA"
                }
            }
        });
    });