sap.ui.define([
        "encollab/dp/BaseController",
        "sap/m/MessageToast",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/ValueState"
    ],
    /**
     * <p>Controller for the ATP / Backorder report. It's based on calling the same ABAP classes as deliverable AS036. Please refer
     * to the spec of this development to learn more about the data displayed here.</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Wty</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.reports.Returns.view.xml <small>main view</small></li>
     * <li>encollab.dp.reports.returns.print.fragment.xml</li>
     * <li>encollab.dp.reports.returns.printDialog.fragment.xml</li>
     * <li>encollab.dp.reports.returns.table.fragment.xml</li>
     * </ul>
     * @class Returns
     * @memberOf encollab.dp.reports
     * @extends {encollab.dp.BaseController}
     * @return {encollab.dp.reports.Returns}
     * 
     * @param  {encollab.dp.BaseController} Controller     
     * @param  {sap.m.MessageToast} MessageToast   
     * @param  {sap.ui.model.Filter} Filter         
     * @param  {sap.ui.model.FilterOperator} FilterOperator 
     * @param  {sap.ui.model.json.JSONModel} JSONModel      
     * @param  {sap.ui.core.ValueState} State          
     */
    function(Controller, MessageToast, Filter, FilterOperator, JSONModel, State) {
        "use strict";
        return Controller.extend("encollab.dp.reports.Returns", {
            _userAuthorisations: ['PartEnquiry'],
            /**
             * This array holds the user parameters required to run this controller. In this case, the user has to be set up
             * with SPA, VKO, VTW (the entire sales area), and WRK (plant)
             *
             * @private
             * @member
             * @name   encollab.dp.reports.Returns#_userParameters
             */
            _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
            /**
             * Initialization of the controller
             * @name   encollab.dp.reports.Detail#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);
                this.model = new JSONModel({
                    returns: [],
                    print: [],
                    date: new Date(),
                    counts: []
                });

                this.model.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
                this.setModel(this.model, 'data');
                this.myRouter.getRoute("returns").attachPatternMatched(this._onObjectMatched, this);
            },
            /**
             * On start of the report, all data is fetched from the WarrantyClaimsWithReturnItems channel on the wty service
             * @name   encollab.dp.reports.Detail#_onObjectMatched
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _onObjectMatched: function(oEvent) {
                this.byId('returnsTable').setBusy(true);
                this.getModel('wty').read('/WarrantyClaimsWithReturnItems', {
                    success: function(data) {
                        this.byId('returnsTable').setBusy(false);
                        this.byId('returnsTable').setVisibleRowCount(((data.results.length || 10) > 10) ? 10 : data.results.length);
                        this.model.setProperty('/returns', []);
                        this.model.setProperty('/returns', this._prepareResults(data.results));
                        this.model.setProperty('/count', data.results.length);
                    }.bind(this)
                });
            },
            /**
             * Prepares the data before it's loaded into the returns table
             * @name   encollab.dp.reports.Detail#_prepareResults
             * @param {array<object>} data
             * @method
             */
            _prepareResults: function(data) {
                var counts = {
                    total: {
                        count: 0,
                        description: 'All',
                        show: true,
                        status: "0000"
                    }
                };
                var statusses = [];
                for (var d = 0; d < data.length; d++) {
                    data[d].age = (data[d].ApprovalDate) ? Math.floor((new Date() - data[d].ApprovalDate) / 86400000) + ' days' : '';

                    data[d].Status = this.formatter.directSwapDescription(data[d].VehicleType);

                    counts.total.count++;
                    if (counts[data[d].VehicleType]) {
                        counts[data[d].VehicleType].count++
                    } else {
                        counts[data[d].VehicleType] = {
                            count: 1,
                            description: data[d].Status,
                            show: false,
                            status: data[d].VehicleType
                        }
                    }

                    data[d].Searcher = [
                        data[d].ClaimNo,
                        data[d].ClaimDescr,
                        data[d].StatusDescr,
                        data[d].VIN,
                        data[d].DealerName,
                        data[d].QualifierText,
                        data[d].PFP,
                        data[d].PFPText,
                    ].join().toUpperCase();
                }

                this.getModel('data').setProperty('/counts', counts);

                return data;
            },
            /**
             * Closes the print dialog
             * @name   encollab.dp.reports.Detail#onPrintCancel
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onPrintCancel: function(oEvent) {
                this.byId('printReturnsDialog').close();
            },
            /**
             * Takes the selected items and populates the Print Dialog, for easier printing
             * @name   encollab.dp.reports.Detail#onPrintPress
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onPrintPress: function(oEvent) {

                var table = this.byId('returnsTable');
                var selection = table.getSelectedIndices();
                var rows = table.getRows();
                var data = [];
                for (var i = 0; i < selection.length; i++) {
                    var index = parseInt(table.getContextByIndex(selection[i]).getPath().match(/[0-9]$/)[0]);
                    data.push(this.getModel('data').getData().returns[index]);
                }

                if (data.length > 0) {
                    var dialog = this.byId('printReturnsDialog');
                    this.getModel('data').setProperty('/print', data);
                    this.getModel('data').setProperty('/counts/print', (data.length <= 0) ? 1 : data.length);
                    dialog.setModel(this.getModel('data'), 'data');
                    dialog.setModel(this.getModel('i18n'), 'i18n');
                    dialog.setModel(this.getModel('wty'), 'wty');
                    dialog.open();

                    window.print();
                } else {
                    MessageToast.show(this.getModel('i18n').getProperty('retusnNoItems'))
                }
            },
            /**
             * Filters the list based on the selection of the icon tab bar
             * @name   encollab.dp.reports.Detail#onIconTabBarSelect
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onIconTabBarSelect: function(oEvent) {
                var searchString = oEvent.getParameter("key");
                var binding = this.byId('returnsTable').getBinding('rows');

                if (searchString !== 'All') {
                    var filters = new Filter([
                        new Filter("Status", FilterOperator.EQ, searchString.toUpperCase()),
                    ], false);

                    binding.filter(filters, sap.ui.model.FilterType.Control)
                } else {
                    binding.aFilters = null;
                    this.getModel('data').refresh(true);
                }
            },
            /**
             * Navigates to the warranty claim when a claim number is pressed
             * @name   encollab.dp.reports.Detail#onPress
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onPress: function(oEvent) {
                var oItem = oEvent.getSource();
                this.myRouter.navTo("wtydetail", {
                    wtyPath: "WarrantyClaims('" + oItem.getBindingContext('data').getProperty('ClaimNo') + "')"
                });
            },
            onNavBack: function() {
                Controller.prototype.onNavBack.apply(this, ["parts"]);
            },
            /**
             * Filters the list based on a search string
             * @name   encollab.dp.reports.Detail#onFilter
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onFilter: function(oEvent) {
                var searchString = oEvent.getSource().getValue().trim().toUpperCase();

                var binding = this.byId('returnsTable').getBinding('rows');
                var filters = new Filter([
                    new Filter("Searcher", FilterOperator.Contains, searchString.toUpperCase()),
                ], false);

                binding.filter(filters, sap.ui.model.FilterType.Control)
            },
            ageState: function(age, days) {
                if (age === '') return State.Warning;
                return (parseInt(age) > days) ? State.Error : State.Success;
            },
            ageIcon: function(age, days) {
                if (age === '') return 'sap-icon://question-mark';

                return (parseInt(age) > days) ? 'sap-icon://decline' : 'sap-icon://accept';
            }
        });
    });