sap.ui.define([
		"encollab/dp/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"
	],
	/**
	 * <p>Controller for the ATP / Backorder report. It's based on calling the same ABAP classes as deliverable AS036. Please refer
	 * to the spec of this development to learn more about the data displayed here.</p>
	 * <h4>OData services used</h4>
	 * <ul>
	 * <li>Orders</li>
	 * </ul>
	 * <h4>Templates used</h4>
	 * <ul>
	 * <li>encollab.dp.reports.ATP.view.xml <small>main view</small></li>
	 * </ul>
	 * @class ATP
	 * @memberOf encollab.dp.reports
	 * @extends {encollab.dp.BaseController}
	 * @return {encollab.dp.reports.ATP}
	 * 
	 * @param  {encollab.dp.BaseController} Controller
	 * @param {sap.ui.model.json.JSONModel} JSONModel 
	 * @param  {sap.ui.model.Filter} Filter
	 * @param {sap.ui.model.FilterOperator} FilterOperator 
	 */
	function(Controller, JSONModel, Filter, FilterOperator) {
		"use strict";
		return Controller.extend("encollab.dp.reports.ATP", {
            /**
             * Initialization of the controller
             * @name   encollab.dp.reports.Detail#onInit
             * @method
             */
			onInit: function() {
				Controller.prototype.onInit.apply(this, arguments);

				var model = new JSONModel({
					Backorders: []
				});

				this.getView().setModel(model, 'data');
				this.myRouter.getRoute("reportATP").attachPatternMatched(this._onObjectMatched, this);
			},
            /**
             * Navigates to a material when a material is pressed
             * @name   encollab.dp.reports.Detail#onMaterialPress
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
			onMaterialPress: function(oEvent) {
				var key = oEvent.getSource().getText();
				this.myRouter.navTo("partsdetail", {
					partPath: key
				});
			},
            /**
             * Navigates to an order when an order is pressed
             * @name   encollab.dp.reports.Detail#onOrderPress
             * @method
             */
			onOrderPress: function(oEvent) {
				var key = oEvent.getSource().getText();
				this.myRouter.navTo("ordersdetail", {
					orderPath: key
				});
			},
            /**
             * When the current route is "reportATP", data is fetched from the oData channel, formatted for download, and attached to a JSON model. 
             * @name   encollab.dp.reports.Detail#_onObjectMatched
             * @private
             * @method
             */
			_onObjectMatched: function() {
				this.byId('idATPTable').setBusy(true);
				this.getModel('orders').read('/Backorders', {
					success: function(data) {
						this.byId('idATPTable').setBusy(false);
						this.getModel('data').setProperty('/Backorders', this._prepareData(data.results));
						this.getModel('data').setProperty('/count', data.results.length);
					}.bind(this)
				});
			},
            /**
             * Format data. This skips all lines that have an empty BO qty, and it adds a searcher field. 
             * @name   encollab.dp.reports.Detail#_prepareData
             * @method
             */
			_prepareData: function(data) {
				var ret = [];
				for (var d = 0; d < data.length; d++) {
					if (data[d].BOQty > 0) {
						data[d].Searcher = [
							data[d].PurchaseOrder,
							data[d].OrderNumber,
							data[d].MaterialDescr,
							data[d].MaterialNr,
						].join().toUpperCase();

						ret.push(data[d]);
					}
				}

				return ret;
			},
            /**
             * Filters the JSON model
             * @name   encollab.dp.reports.Detail#onFilter
             * @method
             */
			onFilter: function(oEvent) {
				var searchString = oEvent.getSource().getValue().trim().toUpperCase();

				var binding = this.byId('idATPTable').getBinding('rows');
				var filters = new Filter([
					new Filter("Searcher", FilterOperator.Contains, searchString.toUpperCase()),
				], false);

				binding.filter(filters, sap.ui.model.FilterType.Control)
			},
            /**
             * Opens a print dialog
             * @name   encollab.dp.reports.Detail#onPrintPress
             * @method
             */
			onPrintPress: function() {
				window.print();
			},
            /**
             * Returns an icon based on the current BO quantity
             * @name   encollab.dp.reports.Detail#onInit
             * @return {string} Icon
             * @method
             */
			BOFormatter: function(val) {
				return (parseInt(val) > 0) ? "sap-icon://decline" : "sap-icon://accept";
			},
            /**
             * Sets the BO icon to a particular color
             * @name   encollab.dp.reports.Detail#onInit
             * @return {string} Red or green
             * @method
             */
			BOState: function(val) {
				return (parseInt(val) > 0) ? "Error" : "Success";
			},

			onDownloadPress: function(oEvent) {
				var visible = this.byId('idATPTable').getBinding('rows').getContexts();
			}
		});
	});