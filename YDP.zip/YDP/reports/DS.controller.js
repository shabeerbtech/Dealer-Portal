sap.ui.define([
        "encollab/dp/BaseController",
        "sap/m/MessageToast",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/ValueState"
    ],
    /**
     * <p>Direct Swap shows a list of warranty claims that contain a direct swap part on it</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Wty</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.reports.ATP.view.xml <small>main view</small></li>
     * </ul>
     * @class ATP
     * @memberOf encollab.dp.reports
     * @extends {encollab.dp.BaseController}
     * @return {encollab.dp.reports.ATP}
     * 
     * @param  {encollab.dp.BaseController} Controller
     * @param {sap.ui.model.json.JSONModel} JSONModel 
     * @param  {sap.ui.model.Filter} Filter
     * @param {sap.ui.model.FilterOperator} FilterOperator 
     */
    function(Controller, MessageToast, Filter, FilterOperator, JSONModel, State) {
        "use strict";
        return Controller.extend("encollab.dp.reports.DS", {
            _userAuthorisations: ['PartEnquiry'],
            /**
             * This array holds the user parameters required to run this controller. In this case, the user has to be set up
             * with SPA, VKO, VTW (the entire sales area), and WRK (plant)
             *
             * @private
             * @member
             * @name   encollab.dp.parts.Detail#_userParameters
             */
            _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
            /**
             * Initialization of the controller. Sets up a local JSON model
             * @name   encollab.dp.reports.DF#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);
                this.model = new JSONModel({
                    ds: [],
                    print: [],
                    date: new Date(),
                    counts: []
                });

                this.model.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
                this.setModel(this.model, 'data');
                this.myRouter.getRoute("ds").attachPatternMatched(this._onObjectMatched, this);
            },
            /**
             * On matching the Direct Swap route, this reads the Direct Swap oData channel and displays the results
             * @name   encollab.dp.reports.DF#_onObjectMatched
             * @method
             * @private
             */
            _onObjectMatched: function(oEvent) {
                this.byId('dsTable').setBusy(true);
                this.getModel('wty').read('/WarrantyClaimsWithDirectSwap', {
                    success: function(data) {
                        this.byId('dsTable').setBusy(false);
                        this.model.setProperty('/ds', []);
                        this.model.setProperty('/ds', this._prepareResults(data.results));
                        this.model.setProperty('/count', data.results.length);
                    }.bind(this)
                });
            },
            /**
             * Prepares the results of the query:
             * <ul>
             * <li>Add formats to several fields.</li>
             * <li>Tally the various claim statusses included in the results and add a count for each</li>
             * <li>Add a Searcher field for easier filtering</li>
             * <li>Calculate the age of the Claim cased on Approval date in days</li>
             * </ul>
             * @name   encollab.dp.reports.DF#_prepareResults
             * @method
             * @private
             */
            _prepareResults: function(data) {
                var counts = {
                    total: {
                        count: 0,
                        description: 'All',
                        show: true,
                        status: "0000"
                    }
                };
                var statusses = [];
                for (var d = 0; d < data.length; d++) {
                    data[d].age = (data[d].ApprovalDate) ? Math.floor((new Date() - data[d].ApprovalDate) / 86400000) + ' days' : '';

                    counts.total.count++;
                    if (counts[data[d].DirectSwapStatus]) {
                        counts[data[d].DirectSwapStatus].count++
                    } else {
                        counts[data[d].DirectSwapStatus] = {
                            count: 1,
                            description: data[d].DirectSwapDescr,
                            show: false,
                            status: data[d].DirectSwapStatus
                        }
                    }

                    data[d].Searcher = [
                        data[d].ClaimNo,
                        data[d].ClaimDescr,
                        data[d].StatusDescr,
                        data[d].VIN,
                        data[d].DealerName,
                        data[d].QualifierText,
                        data[d].PFP,
                        data[d].PFPText,
                        data[d].DirectSwapDescr,
                    ].join().toUpperCase();
                }

                this.getModel('data').setProperty('/counts', counts);

                return data;
            },
            onPrintCancel: function(oEvent) {
                this.byId('printdsDialog').close();
            },
            onPrintPress: function(oEvent) {

                var table = this.byId('dsTable');
                var selection = table.getSelectedIndices();
                var rows = table.getRows();
                var data = [];
                for (var i = 0; i < selection.length; i++) {
                    var index = parseInt(table.getContextByIndex(selection[i]).getPath().match(/[0-9]$/)[0]);
                    data.push(this.getModel('data').getData().ds[index]);
                }

                if (data.length > 0) {
                    var dialog = this.byId('printdsDialog');
                    this.getModel('data').setProperty('/print', data);
                    this.getModel('data').setProperty('/counts/print', (data.length <= 0) ? 1 : data.length);
                    dialog.setModel(this.getModel('data'), 'data');
                    dialog.setModel(this.getModel('i18n'), 'i18n');
                    dialog.setModel(this.getModel('wty'), 'wty');
                    dialog.open();

                    window.print();
                } else {
                    MessageToast.show(this.getModel('i18n').getProperty('retusnNoItems'))
                }
            },
            /**
             * When selecting statusses from the icon tab bar, this shows only the requested status by
             * filtering the list
             * @name   encollab.dp.reports.DF#onIconTabBarSelect
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onIconTabBarSelect: function(oEvent) {
                var searchString = oEvent.getParameter("key");
                var binding = this.byId('dsTable').getBinding('rows');

                if (searchString !== 'All') {
                    var filters = new Filter([
                        new Filter("DirectSwapDescr", FilterOperator.EQ, searchString),
                    ], false);

                    binding.filter(filters, sap.ui.model.FilterType.Control)
                } else {
                    binding.aFilters = null;
                    this.getModel('data').refresh(true);
                }
            },
            /**
             * Navigates to the warranty claim if a claim number is pressed
             * @name   encollab.dp.reports.DF#onPress
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onPress: function(oEvent) {
                var oItem = oEvent.getSource();
                this.myRouter.navTo("wtydetail", {
                    wtyPath: "WarrantyClaims('" + oItem.getBindingContext('data').getProperty('ClaimNo') + "')"
                });
            },
            onNavBack: function() {
                Controller.prototype.onNavBack.apply(this, ["parts"]);
            },
            /**
             * Filters the list based on the input of the input box
             * @name   encollab.dp.reports.DF#onFilter
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onFilter: function(oEvent) {
                var searchString = oEvent.getSource().getValue().trim().toUpperCase();

                var binding = this.byId('dsTable').getBinding('rows');
                var filters = new Filter([
                    new Filter("Searcher", FilterOperator.Contains, searchString.toUpperCase()),
                ], false);

                binding.filter(filters, sap.ui.model.FilterType.Control)
            },
            /**
             * Returns a state for the age field (red or green, error or success)
             * @name   encollab.dp.reports.DF#onFilter
             * @param {number} age
             * @param {number} days  
             * @return {string} Status
             * @method
             */
            ageState: function(age, days) {
                if (age === '') return State.Warning;
                return (parseInt(age) > days) ? State.Error : State.Success;
            },
            /**
             * Returns an icon for the age field 
             * @name   encollab.dp.reports.DF#onFilter
             * @param {number} age
             * @param {number} days  
             * @return {string} Icon
             * @method
             */
            ageIcon: function(age, days) {
                if (age === '') return 'sap-icon://question-mark';

                return (parseInt(age) > days) ? 'sap-icon://decline' : 'sap-icon://accept';
            }
        });
    });