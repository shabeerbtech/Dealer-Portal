/**
**********************************************************************************************************
*  Changed on:  Changed by:   Change ID:  TR Number:        Description:
*  2017.08.30   Subha          C001       GKAK907485      FP&invoice date converted into UTC date format
*              z019767
**********************************************************************************************************
*/
sap.ui.define([
        "encollab/dp/BaseController",
        "sap/m/MessageToast",
        "sap/ui/model/Sorter",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/format/DateFormat"
    ],
    /**
     * <p>FP report is a list of claims that are in status "Waiting for FP", so the dealer can go and provide 
     * Invoice #, FP #, Receipt # and dates.</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Wty</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.reports.FP.view.xml <small>main view</small></li>
     * <li>encollab.dp.reports.fp.claimsToUpdate.fragment.xml</li>
     * <li>encollab.dp.reports.claimsUpdated.fragment.xml</li>
     * </ul>
     * @class FP
     * @memberOf encollab.dp.reports
     * @extends {encollab.dp.BaseController}
     * @return {encollab.dp.reports.FP}
     * 
     * @param  {encollab.dp.BaseController} Controller
     * @param {sap.ui.MessageToast} MessageToast
     * @param  {sap.ui.model.Sorter} Sorter
     * @param {sap.ui.model.Filter} Filter 
     * @param {sap.ui.model.FilterOperator} FilterOperator 
     * @param {sap.ui.model.json.JSONModel} JSONModel 
     * @param {sap.ui.core.format.DateFormat} Format 
     */
    function(Controller, MessageToast, Sorter, Filter, FilterOperator, JSONModel, Format) {
        "use strict";
        return Controller.extend("encollab.dp.reports.FP", {
            _userAuthorisations: ['PartEnquiry'],
            /**
             * This array holds the user parameters required to run this controller. In this case, the user has to be set up
             * with SPA, VKO, VTW (the entire sales area), and WRK (plant)
             *
             * @private
             * @member
             * @name   encollab.dp.parts.Detail#_userParameters
             */
            _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
            _filteredData: [],
            _togo: 0,
            /**
             * Initialization of the controller
             * @name   encollab.dp.reports.Detail#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);
                this.model = new JSONModel({
                    count: 0,
                    countu: 0,
                    date: [],
                    fp: [],
                    receipt: null,
                    updated: []
                });
                this.model.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
                this.setModel(this.model, 'data');
                this.myRouter.getRoute("fp").attachPatternMatched(this._onObjectMatched, this);
            },
            /**
             * On matching route "fp", the list of claims that need to be updated is fetched from SAP
             * @name   encollab.dp.reports.Detail#_onObjectMatched
             * @method
             * @private
             */
            _onObjectMatched: function(oEvent) {
                this._updateToUpdate();
            },
            /**
             * Calls FPClaims on wty Odata set and pulls 250 claims in status 0125, sorted by Approval date. 
             * Also filters on date range through the dropdown and on Claim Description and Claim Number in the
             * search box itself. 
             * @name   encollab.dp.reports.Detail#_updateToUpdate
             * @method
             * @private
             */
            _updateToUpdate: function(search) {
                this.byId('fpTable').setBusy(true);
                this.getModel('wty').setSizeLimit(250);
                var dates = this.byId('fpSearchBar1').getDateRange();
                var filters = [];

                if (search !== '' && typeof search !== 'undefined' && search !== null) {
                    filters = [new Filter({
                        filters: [
                            new Filter('StatusId', FilterOperator.EQ, '0125'),
                            new Filter("ApprovalDate", FilterOperator.BT, this.accountForUTCDate(dates.first), this.accountForUTCDate(dates.last)),
                            new Filter({
                                filters: [
                                    new Filter("ClaimDescr", FilterOperator.Contains, search),
                                    new Filter("ClaimNo", FilterOperator.Contains, search),
                                ],
                                and: false
                            })
                        ],
                        and: true
                    })];
                } else {
                    filters = [new Filter({
                        filters: [
                            new Filter('StatusId', FilterOperator.EQ, '0125'),
                            new Filter("ApprovalDate", FilterOperator.BT, this.accountForUTCDate(dates.first), this.accountForUTCDate(dates.last))
                        ],
                        and: true
                    })];
                }

                this.getModel('wty').read('/FPClaims', {
                    filters: filters,
                    sorters: [new Sorter('ApprovalDate', false)],
                    urlParameters: {
                        '$top': 250
                    },
                    success: function(data) {
                        this.byId('fpTable').setBusy(false);
                        this.getModel('wty').setSizeLimit(data.results.length);
                        this.model.setProperty('/fp', data.results);
                        this.model.setProperty('/count', data.results.length);

                        this.byId('fpTableDownload').setData(this._formatSimpleArrayForDownload(data.results));
                    }.bind(this)
                });
            },
            /**
             * Displays all claims in status 0126 that match the reference number provided, sorted by Approval Date
             * @name   encollab.dp.reports.Detail#_updateUpdated
             * @param {string} search  
             * @method
             * @private
             */
            _updateUpdated: function(search) {
                this.byId('fpUpdateTable').setBusy(true);
                var dates = this.byId('fpSearchBar2').getDateRange();

                var filters;

                if (search !== '' && typeof search !== 'undefined' && search !== null) {
                    filters = [new Filter({
                        filters: [
                            new Filter('StatusId', FilterOperator.EQ, '0126'),
                            new Filter("ReceiptNo", FilterOperator.EQ, search),
                            new Filter("ApprovalDate", FilterOperator.BT, this.accountForUTCDate(dates.first), this.accountForUTCDate(dates.last))
                        ],
                        and: true
                    })];
                } else {
                    filters = [new Filter({
                        filters: [
                            new Filter('StatusId', FilterOperator.EQ, '0126'),
                            new Filter("ApprovalDate", FilterOperator.BT, this.accountForUTCDate(dates.first), this.accountForUTCDate(dates.last))
                        ],
                        and: true
                    })];
                }

                this.getModel('wty').read('/FPClaims', {
                    filters: filters,
                    sorters: [new Sorter('ApprovalDate', false)],
                    urlParameters: {
                        '$top': 99999
                    },
                    success: function(data) {
                        this.byId('fpUpdateTable').setBusy(false);
                        this.getModel('wty').setSizeLimit(data.results.length);
                        this.model.setProperty('/updated', data.results);
                        this.model.setProperty('/countu', data.results.length);


                        this.byId('fpTableDownload').setData(this._formatSimpleArrayForDownload(data.results));
                    }.bind(this)
                });
            },
            /**
             * Opens a print dialog
             * @name   encollab.dp.reports.Detail#onPrint
             * @method
             */
            onPrint: function() {
                window.print();
            },
            /**
             * On selecting a radiobutton, open the dialog box to enter a receipt if receipt is still blank
             * @name   encollab.dp.reports.Detail#onRadioSelect
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onCheckboxSelect: function(oEvent) {
                this.byId('fpDialogButton').setEnabled(true);
                var dates = this.getModel('data').getProperty('/date');
                dates.push(oEvent.getSource().getText());
                this.getModel('data').setProperty('/date', dates);
                this._filter();
            },
            /**
             * On pressing the FP button, open the dialog box for FP details
             * @name   encollab.dp.reports.Detail#onFpDialogButtonPress
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onFpDialogButtonPress: function(oEvent) {
                this.byId('fpDialog').open();

            },
            /**
             * When pressing on a claim number, navigate to the claim details
             * @name   encollab.dp.reports.Detail#onClaimPress
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onClaimPress: function(oEvent) {
                var oItem = oEvent.getSource();
                this.myRouter.navTo("wtydetail", {
                    wtyPath: "WarrantyClaims('" + oItem.getBindingContext('data').getProperty('ClaimNo') + "')"
                });
            },

            /**
             * When entering a search, this will get the search value from the box and calls the refresh methods
             * @name   encollab.dp.reports.Detail#onSearchFilter
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onSearchFilter1: function(oEvent) {
                var searchString = this.byId('fpSearchBar1').getSearchValue();

                this._updateToUpdate(searchString);
            },

            /**
             * When entering a search, this will get the search value from the box and calls the refresh methods
             * @name   encollab.dp.reports.Detail#onSearch
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onSearch1: function(oEvent) {
                var searchString = this.byId('fpSearchBar1').getSearchValue();

                this._updateToUpdate(searchString);
            },

            /**
             * When entering a search, this will get the search value from the box and calls the refresh methods
             * @name   encollab.dp.reports.Detail#onSearchFilter
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onSearchFilter2: function(oEvent) {
                var searchString = this.byId('fpSearchBar2').getSearchValue();

                this._updateUpdated(searchString);
            },

            /**
             * When entering a search, this will get the search value from the box and calls the refresh methods
             * @name   encollab.dp.reports.Detail#onSearch
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onSearch2: function(oEvent) {
                var searchString = this.byId('fpSearchBar2').getSearchValue();

                this._updateUpdated(searchString);
            },
            /**
             * This method is called when confirming the detail in the FP dialog box:
             * FP date, FP, Invoice date and Invoice. It calls the _saveData method and clears out the input boxes. 
             * @name   encollab.dp.reports.Detail#onUploadConfirm
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onUploadConfirm: function() {
                var fp = this.byId('idFp').getValue().trim();
                var inv = this.byId('idFpInvoice').getValue().trim();
                var receipt = this.byId('idReceiptInvoice').getValue().trim();
                var invdate = this.byId('idFpInvoiceDate').getDateValue();

                //this is the data we're uploading!
                this._saveData(this._filteredData, fp, inv, new Date(invdate), receipt);

                this.byId('idFp').setValue('');
                this.byId('idFpInvoice').setValue('');
                this.byId('idFpInvoiceDate').setValue('');
                this.byId('idReceiptInvoice').setValue('');

                this.byId('fpDialog').close();
            },
            /**
             * Close the FP dialog
             * @name   encollab.dp.reports.Detail#onUploadCancel
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onUploadCancel: function(oEvent) {
                this.byId('fpDialog').close();
            },
            /**
             * Sets the Receipt number on the local JSON model for future use
             * @name   encollab.dp.reports.Detail#onReceiptConfirm
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onReceiptConfirm: function(oEvent) {
                this.model.setProperty('/receipt', this.byId('idFpReceipt').getValue());
                this.byId('fpReceipt').close();
            },
            /**
             * Closes the Receipt dialog box
             * @name   encollab.dp.reports.Detail#onReceiptCancel
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onReceiptCancel: function(oEvent) {
                this.byId('fpReceipt').close();
            },
            /**
             * Open the receipt dialog box
             * @name   encollab.dp.reports.Detail#onFpReceiptDialogButtonPress
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onFpReceiptDialogButtonPress: function() {
                this.byId('fpReceipt').open();
            },
            /**
             * Verifies all input from the FP dialog, and checks if all values have been provided. Only then 
             * is the Confirm button enabled so the user can save the details
             * @name   encollab.dp.reports.Detail#onInputVerify
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onInputVerify: function(oEvent) {
                //var fpdate = this.byId('idFpDate').getValue().trim();
                var fp = this.byId('idFp').getValue().trim();
                var inv = this.byId('idFpInvoice').getValue().trim();
                var invdate = this.byId('idFpInvoiceDate').getValue().trim();
                var receipt = this.model.getProperty('/receipt');


                if (receipt !== '' && fp !== "" && inv !== "" && invdate !== "") {
                    this.byId('fpUploadConfirmButton').setEnabled(true);
                } else {
                    this.byId('fpUploadConfirmButton').setEnabled(false);
                }

            },
            /**
             * On pressing the FP button, open the dialog box for FP details
             * @name   encollab.dp.reports.Detail#cancelAllowed
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            cancelAllowed: function(val) {
                return (val !== null)
            },
            /**
             * @name   encollab.dp.reports.Detail#cancelAllowedChange
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            cancelAllowedChange: function(oEvent) {
                if (oEvent.getSource().getValue() !== '') {
                    this.byId('fpReceiptConfirmButton').setEnabled(true);
                } else {
                    this.byId('fpReceiptConfirmButton').setEnabled(false);
                }
            },
            /**
             * Saves the data on all FP claims. Since there's no mass update on oData gateway services this updates every 
             * claim separately. Because all lists need to be updated when all updates are done, this keeps track of the number
             * of updates.
             * @name   encollab.dp.reports.Detail#_saveData
             * @param {string} selection
             * @param {string} fp 
             * @param {date} fpdate
             * @param {string} inv 
             * @param {date} invdate 
             * @param {string} receipt
             * @method
             */
            _saveData: function(selection, fp, /* fpdate, */ inv, invdate, receipt) {
            //BOC-C001
             var sDate = new Date(invdate);
                 sDate.getUTCDate();
                 sDate.setUTCDate(sDate.getDate());

                this._togo = selection.length;
                this.getView().setBusy(true);
                for (var i = 0; i < selection.length; i++) {

                    selection[i].FakturPrajakDate = sDate;
                    selection[i].FakturPrajakNo = fp;
                    selection[i].InvoiceDate = sDate;
                    selection[i].InvoiceNo = inv;
                    selection[i].ReceiptNo = receipt;
                    //EOC-C001

                    this.getModel('wty').update("/FPClaims('" + selection[i].ClaimNo + "')", selection[i], {
                        success: function() {
                            this._updateAll();
                        }.bind(this),
                        error: function(oError) {
                            this.gatewayError(oError);
                            this._updateAll();
                        }.bind(this)
                    });
                }
            },
            /**
             * Every success callback from the _saveData method, this gets executed. It decrements the variable
             * we're holding that has the number of active calls. Once it reaches zero, all lists are updated. 
             * @name   encollab.dp.reports.Detail#_updateAll
             * @method
             */
            _updateAll: function() {
                this._togo -= 1;
                if (this._togo === 0) {
                    this._updateUpdated();
                    this._updateToUpdate();
                    this.getView().setBusy(false);
                }
            },
            /**
             * Returns a JSON structure for the FP dialog
             * @name   encollab.dp.reports.Detail#_json
             * @param {string|number} claim
             * @param {string} id 
             * @param {string} value  
             * @method
             */
            _json: function(claim, id, value) {
                return {
                    ClaimNo: claim.toString(),
                    Id: id,
                    Description: '',
                    Value: value,
                    ValueDescription: '',
                    Datatype: ''
                };
            },
            /**
             * This groups data based on the reference date
             * @name   encollab.dp.reports.Detail#_filter
             * @method
             */
            _filter: function() {
                var data = this.getModel('data').getProperty('/fp');
                var date = this.getModel('data').getProperty('/date');

                this._filteredData = [];
                for (var d = 0; d < data.length; d++) {
                    for (var i = 0; i < date.length; i++) {
                        if (this.formatter.ShortDate(data[d].ApprovalDate) === date[i]) {
                            this._filteredData.push(data[d]);
                        }
                    }
                }
            }
        });
    });