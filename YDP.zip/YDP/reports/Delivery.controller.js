/**
****************************************************************************************
*  Changed on:  Changed by:   Change ID:  TR Number:        Description:
* 2017.09.15   Subha-z019767   C001      GKAK907549         POD FILTER
* 2017.10.16   Subha           C002      GKAK907749         POD FILTER CHANGE
* 2017.10.18   Subha          C003\C004  GKAK907764/
*                                         GKAK907766        POD FILTER CHANGE1
* 2017.11.14   subha           C005        GKAK908010      POD DATE FORMATE CHANGE.
* 2018.01.17  SUBHA           C006        GKAK908319       Reimport POD filter code.
*****************************************************************************************
*/
sap.ui.define([
    "encollab/dp/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    'sap/m/MessageToast'
  ],
  /**
   * <p>This class serves as the controller for two different routes: the Delivery report, and the POD report. Both are very similar
   * and use the same data sources.</p>
   * <h4>OData services used</h4>
   * <ul>
   * <li>Orders</li>
   * </ul>
   * <h4>Templates used</h4>
   * <ul>
   * <li>encollab.dp.reports.Delivery.view.xml <small>main view</small></li>
   * <li>encollab.dp.reports.deliveries.deliveries.fragment.xml</li>
   * <li>encollab.dp.reports.deliveries.pod.fragment.xml</li>
   * </ul>
   * @class Delivery
   * @memberOf encollab.dp.reports
   * @extends {encollab.dp.BaseController}
   * @return {encollab.dp.reports.Delivery}
   *
   * @param  {encollab.dp.BaseController} Controller
   * @param {sap.ui.model.json.JSONModel} JSONModel
   * @param  {sap.ui.model.Filter} Filter
   * @param {sap.ui.model.FilterOperator} FilterOperator
   * @param {sap.m.MessageToast} MessageToast
   */
  function(Controller, JSONModel, Filter, FilterOperator, MessageToast) {
    "use strict";
    return Controller.extend("encollab.dp.reports.Delivery", {
      /**
       * An array containing active oData calls
       * @name   encollab.dp.reports.Detail#_activeCalls
       * @type {array<function>}
       */
      _activeCalls: [],
      /**
       * Initialization of the controller. It sets up a local JSON model that holds internal data like the
       * number of entries, the list of deliveries, and which report to display: POD or Deliveries.
       * @name   encollab.dp.reports.Detail#onInit
       * @method
       */
      onInit: function() {
        Controller.prototype.onInit.apply(this, arguments);

        this.model = new JSONModel({
          count: 0,
          deliveries: [],
          table: null,
          visible: true,
          masspod: null
        });

        this.getView().setModel(this.model, 'data');
        this.myRouter.getRoute("reportDelivery").attachPatternMatched(this._onObjectMatchedDelivery, this);
        this.myRouter.getRoute("reportPOD").attachPatternMatched(this._onObjectMatchedPOD, this);
      },
      /**
       * If the user got here by navigating to the Delivery Report, all Delivery Report related objects are shown, and all
       * POD related objects are hidden. Also, a search is initiated.
       * @name   encollab.dp.reports.Detail#_onObjectMatchedDelivery
       * @method
       */
      _onObjectMatchedDelivery: function(oEvent) {
        this.table = this.byId('deliveryDeliveryTable');
        this.byId('deliveriesSearchBar').setVisible(true);
      // BOC-C006
        this.byId('deliveriesSearchBar1').setVisible(false);
        //EOC-C006
        this.table.setVisible(true);
        this.byId('deliveryPODTable').setVisible(false);
        this.model.setProperty('/table', 'deliveryDeliveryTable');
        this.model.setProperty('/visible', false);
        var dates = this.byId('deliveriesSearchBar').getDateRange();
        this._field = 'Delivered';
        this._search(dates.first, dates.last);
      },
      /**
       * If the user got here by navigating to the POD Report, all POD Report related objects are shown, and all
       * Delivery related objects are hidden. Also, a search is initiated. POD searches are not based on dates, it simply shows
       * all deliveries that do not have a Proof of Delivery date set up.
       * @name   encollab.dp.reports.Detail#_onObjectMatchedPOD
       * @method
       */
       //       BOD-C001/C002
      _onObjectMatchedPOD: function(oEvent) {
        this.table = this.byId('deliveryPODTable');
        this.byId('deliveriesSearchBar').setVisible(false);
        this.table.setVisible(true);
        this.byId('deliveryDeliveryTable').setVisible(false); //dt
        this.model.setProperty('/table', 'deliveryPODTable');
        this.model.setProperty('/visible', true); //dt
        var dates = this.byId('deliveriesSearchBar1').getDateRange();
        this._field = 'PODDate';
        this._search(dates.first, dates.last);

      },
      //      EOD-C001/C002
      /**
       * Filters the current list from the Searcher field.
       * @name   encollab.dp.reports.Detail#onSearchFilter
       * @method
       */
      onSearchFilter: function(oEvent) {
        var searchString = oEvent.getParameter('filter') || oEvent.getSource().getValue();

        var binding = this.table.getBinding('rows');
        var filters = new Filter([
          new Filter("Searcher", FilterOperator.Contains, searchString.toUpperCase()),
        ], false);
        binding.filter(filters, sap.ui.model.FilterType.Control)
      },
      /**
       * Fetches the value of the POD date and calls the update methods
       * @name   encollab.dp.reports.Detail#onPODDate
       * @method
       */
      onPODDate: function(oEvent) {
        var date = this.accountForUTCDate(oEvent.getSource().getDateValue());
        if (this._verifyDate(date) === true) {
          var data = this.getModel('data').getProperty(oEvent.getSource().getParent().getBindingContext('data').getPath());
          oEvent.getSource().setBusy(true);
          this._update(date, [data]);
        }

      },
      /**
       * On mass POD update, clear the current date and open the date popup dialog
       * @name   encollab.dp.reports.Detail#onPODUpdate
       * @method
       */
      onPODUpdate: function(oEvent) {
        if (this.table.getSelectedIndices().length > 0) {
          this.getModel('data').setProperty('/masspod', '');
          this.byId('reportsPODDialog').open();
        } else {
          MessageToast.show(this.getModel('i18n').getProperty('ordersPODSelection'));
        }
      },
      /**
       * Closes the POD dialog box
       * @name   encollab.dp.reports.Detail#onCancel
       * @method
       */
      onCancel: function(oEvent) {
        this.getModel('data').setProperty('/masspod', '');
        this.byId('reportsPODDialog').close();
      },
      /**
       * When a date is entered in the POD dialog, and the date is valid, all selected deliveries will be updated
       * with that POD date all at once.
       * @name   encollab.dp.reports.Detail#onAccept
       * @method
       */
      onAccept: function(oEvent) {
        var data = [];
        var date = this.getModel('data').getProperty('/masspod');
        this.onCancel();
        if (this._verifyDate(date) === true) {
          var selection = this.table.getSelectedIndices();
          for (var i = 0; i < selection.length; i++) {
            var line = this.getModel('data').getProperty(this.table.getContextByIndex(selection[i]).getPath());
            if (line.PODDate === null) {
              data.push(line);
            }
          }

          this._update(date, data);
        }
      },
      /**
       * A POD date is considered valid if it's a) a date object and b) not larger than today
       * @name   encollab.dp.reports.Detail#_verifyDate
       * @method
       * @private
       */
      _verifyDate: function(date) {
        if (date > new Date()) {
          MessageToast.show(this.getModel('i18n').getProperty('ordersDetailPODMessage'));
          return false;
        } else if (!(date instanceof Date)) {
          MessageToast.show(this.getModel('i18n').getProperty('ordersDetailPODMessage2'));
          return false;
        } else {
          return true;
        }
      },
      /**
       * Updates the deliveries with a particular date. These calls are made in a loop, as there is no mass update, only mass
       * create on the odata services. Thankfully, these calls are batched so it's still a single call.
       * @name   encollab.dp.reports.Detail#_update
       * @param {date} date
       * @param {array<object>} data
       * @method
       */
      _update: function(date, data) {
      //BOC-C003/C004
      var dates = this.byId('deliveriesSearchBar1').getDateRange();
       if (data.length > 0) {
          //var date = this.accountForUTCDate(oEvent.getSource().getDateValue());
          if (date > new Date()) {
            MessageToast.show(this.getModel('i18n').getProperty('ordersDetailPODMessage'));
            this.warningMessage(this.getModel('i18n').getProperty('ordersDetailPODMessage'))
            oEvent.getSource().setDateValue(null)
          } else {
            this.table.setBusy(true);
            for (var d = 0; d < data.length; d++) {
              var path = "/Deliveries(OrderNr='" + data[d].OrderNr + "',DeliveryNr='" + data[d].DeliveryNr + "',Posnr='" + data[d].Posnr + "')";

              data[d].PODDate = this.accountForUTCDate(date);
              delete data[d].__metadata;
              delete data[d].Searcher;

              this.getModel('orders').update(path, data[d], {
                success: function() {
                   this._search(dates.first, dates.last);
                }.bind(this),
                error: function(data) {
                   this._search(dates.first, dates.last);
        // EOC-C003/C004
                }.bind(this)
              });
            }
          }
        }
      },
      /**
       * Formatter, enables or disables the POD input box
       * @name   encollab.dp.reports.Detail#onPODEnabled
       * @method
       * @param {date} date Current POD date
       * @param {string} delivery Delivery number
       */
      onPODEnabled: function(date, delivery) {
        if (date !== null) return false;

        return (delivery !== '');
      },
      /**
       * Gets the first and last date if available, and perform a new search.
       * @name   encollab.dp.reports.Detail#onSearchSearch
       * @param {sap.ui.base.Event} oEvent The event object
       * @method
       */
      onSearchSearch: function(oEvent) {
        var firstDate = oEvent.getParameter('first');
        var lastDate = oEvent.getParameter('last');

        this._search(firstDate, lastDate);
      },
      /**
       * Performs a search. All currently active searches are cancelled. On success, the data are prepared for display and
       * download. Current selection is cleared, if any rows were selected.
       * @param {date} firstDate Optional.
       * @param {date} lastDate Optional.
       * @name   encollab.dp.reports.Detail#_search
       * @method
       */
      _search: function(firstDate, lastDate) {

        this.table.setBusy(true);
        //cancel all active calls

        $.each(this._activeCalls, function(i, a) {
          a.call();
        });
         //BOC-C005

        var filters = [
          new Filter(this._field, FilterOperator.BT, this.accountForUTCDate(firstDate), this.accountForUTCDate(lastDate))
        ]
//EOC-C005
        this.getModel('orders').setUseBatch(false);

        //push the current active call's ABORT function into the active calls.
        this._activeCalls.push(this.getModel('orders').read('/Deliveries', {
          filters: filters,
          urlParameters: {
            '$top': 999999,
            '$format': 'json'
          },
          success: function(data) {
            //set active calls to nothing.
            this._activeCalls = [];
            this.model.setProperty('/orders', this._prepareResults(data.results));
            this.model.setProperty('/count', data.results.length);
            this.table.setBusy(false);
            this.table.clearSelection();
            this.table.setVisibleRowCount(10);
            this.getModel('orders').setUseBatch(true);
          }.bind(this)
        }).abort);
      },
      /**
       * Sorts the results by Delivery Number, adds a Searcher field on the object for easier filtering
       * @name   encollab.dp.reports.Detail#_prepareResults
       * @param {array<object>} data
       * @return {array<object>}
       * @method
       */
      _prepareResults: function(data) {

        data = data.sort(function(a, b) {
          return a.DeliveryNr - b.DeliveryNr;
        });

        for (var i = 0; i < data.length; i++) {
          delete data.__metadata;
          data[i].Searcher = [
            data[i].OrderNr.toString(),
            data[i].DeliveryNr.toString(),
            this.formatter.ShortDate(data[i].Delivered),
            data[i].Material,
            data[i].MaterialDesc
          ].join().toUpperCase();
        }
        return data;

      },

      onSearchOrders: function(evt) {
        var string = evt.getSource().getValue();
        if (string.length && string.length > 3) {
          this.myRouter.navTo('ordersenquiry', {
            searchTerm: evt.getSource().getValue()
          });
        }
      },

      onPress: function(oEvent) {
        var oItem = oEvent.getSource();

        this.myRouter.navTo("ordersdetail", {
          orderPath: oItem.getBindingContext('data').getProperty('OrderNr')
        });
      },

      onCreatePress: function() {
        this.myRouter.navTo("orderscreate");
      },

      submitted: function(deliveryBlock) {
        return (deliveryBlock === '') ? 'sap-icon://accept' : 'sap-icon://decline'
      },

      submittedState: function(deliveryBlock) {
        return (deliveryBlock === '') ? 'Success' : 'Error'
      },

      titlePicker: function(title, orderType) {
        return (orderType) ? orderType : title;
      }
    });
  });