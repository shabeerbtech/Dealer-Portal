/*global history */
sap.ui.define([
    "encollab/dp/BaseController",
    "sap/ui/model/odata/v2/ODataModel"
], function(Controller, ODataModel) {
    "use strict";

    return Controller.extend("encollab.dp.wty.BaseController", {

        onInit: function() {
            Controller.prototype.onInit.apply(this, arguments);

            var oModel = new ODataModel({
                serviceUrl: "/sap/opu/odata/sap/Y_DP_VEHICLE_SRV/",
                defaultCountMode: "Inline"
            });
            // TODO - remove later
            oModel.setUseBatch(false);

            this.getView().setModel(oModel,'vin');
        }

    });

});