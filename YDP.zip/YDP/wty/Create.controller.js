/**
****************************************************************************************
*  Changed on:  Changed by:   Change ID:  TR Number:        Description:
*  2017.04.20   Subha          C001      GKAK907098     Dropdown-Qualifier control for
*               z019767                                    WTY Qualifier Out field.
*  2017.05.10   Shaik Shabeer  C002      GKAK907157     New Servie filter addition
*
*  2017.05.18   Subha-z019767  C003      GKAK907204/    Added logic for Milage check error message
*                                        GKAK907208/    UT correction - Change the error text message
*                                        GKAK907212     UT correction - Corrected the create claim Issue
* 2017.05.10   Subha-z019767   C004      GKAK907167/
*                                        GKAK907220     Mileage input validation
*2017.05.10   Subha-z019767    C005      GKAK907167/
*                                        GKAK907222     PartsMileage input validation
*2017.05.10   Subha-z019767    C006      GKAK907226      SC&EX mileage change
*****************************************************************************************
*/
sap.ui.define([
        "encollab/dp/wty/BaseController",
        "sap/ui/core/routing/History",
        "sap/ui/model/json/JSONModel",
        "sap/m/StandardListItem",
        "sap/ui/core/Item",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator"
    ],
    /**
     * <p>This acts as the controller for the creation of every qualifier claim, some of which have their own tile, while others go through 
     * the VIN detail screen.</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Wty</li>
     * <li>Core</li>
     * <li>VIN</li>
     * <li>Part</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.wty.Create.view.xml <small>main view</small></li>
     * <li>encollab.dp.wty.standardForm.fragment.xml</li>
     * </ul>
     * @class Create
     * @memberOf encollab.dp.wty
     * @extends {encollab.dp.BaseController}
     * @return {encollab.dp.wty.Create}
     * 
     * @param {encollab.dp.wty.BaseController} Controller   
     * @param {sap.ui.core.routing.History} History
     * @param {sap.ui.model.json.JSONModel} JSONModel 
     * @param {sap.m.StandardListItem} StandardListItem
     * @param {sap.m.Item} Item  
     * @param {sap.ui.model.Filter} Filter         
     * @param {sap.ui.model.FilterOperator} FilterOperator       
     */
    function(Controller, History, JSONModel, StandardListItem, Item, Filter, FilterOperator) {
        "use strict";
        return Controller.extend("encollab.dp.wty.Create", {
            _userAuthorisations: ['WarrantyClaims', 'WarrantyCreate'],
            /**
             * This array holds the user parameters required to run this controller
             *
             * @private
             * @member
             * @name   encollab.dp.orders.Create#_userParameters
             */
            _userParameters: ['VKO', 'VTW', 'WRK'],
            /**
             * Holds the current qualifier
             * @name   encollab.dp.wty.Create#_Qualifier
             * @member
             */
            _Qualifier: null,
            /**
             * Initialization of the controller. Sets up a new claim JSON model. 
             * @name   encollab.dp.wty.Create#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);
                this._Customer = this.myComponent.Customer;
                this.getView().setModel(new JSONModel(), "newClaim");
                this.myRouter.getRoute("createwty").attachPatternMatched(this._onVehicleClaim, this);
                this.myRouter.getRoute("createservice").attachPatternMatched(this._onVehicleClaim, this);
                this.myRouter.getRoute("createrecall").attachPatternMatched(this._onVehicleClaim, this);
                this.myRouter.getRoute("createSCwty").attachPatternMatched(this._onSCClaim, this);
                this.myRouter.getRoute("createEXwty").attachPatternMatched(this._onEXClaim, this);
            },
            /**
             * Executed after the entire view is rendered. User details are fetched from the Core service to see if the user has
             * any dealers defined. 
             * @name   encollab.dp.wty.Create#onAfterViewRendered
             * @method
             */
            onAfterViewRendered: function() {
                var aCust = this.getModel('core').getProperty("/Users('" + this.getOwnerComponent().getMyId() + "')/Dealers");
                if (!aCust || !aCust.length || aCust.length === 0) {
                    this.popErrorMessage('No Dealer', 'This user not linked to a dealer');
                    this.getView().getContent()[0].destroyContent();
                }
            },
            /**
             * This sets the Qualifier for VIN related claim creation, and fetches the VIN details
             * @name   encollab.dp.wty.Create#onInit
             * @param {sap.ui.base.Event} oEvent
             * @method
             * @private
             */
            _onVehicleClaim: function(oEvent) {
                this._Qualifier = null;
                var sVehiclePath = "/" + oEvent.getParameter("arguments").vehiclePath;
                var sWtyQual = oEvent.getParameter("arguments").qual;
                var sRecallMaster = oEvent.getParameter("arguments").recallMaster;
                this.getView().bindElement({
                    model: 'vin',
                    path: sVehiclePath,
                    events: {
                        change: this._onBindingChange.bind(this, sWtyQual, sRecallMaster)
                    }
                });
            },
            /**
             * This sets the Qualifier for SC claims
             * @name   encollab.dp.wty.Create#_onSCClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             * @private
             */
            _onSCClaim: function(oEvent) {
                this._Qualifier = 'SC';
                this.initializeNewClaimData();
                this._buildWizard();
            },
            /**
             * This sets the Qualifier for EX claims
             * @name   encollab.dp.wty.Create#_onEXClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             * @private
             */
            _onEXClaim: function(oEvent) {
                this._Qualifier = 'EX';
                this.initializeNewClaimData();
                this._buildWizard();
            },
            /**
             * When the binding changes, several checks are made and the wizard is reset. 
             * @name   encollab.dp.wty.Create#_onEXClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             * @private
             */
            _onBindingChange: function(qual, recallMaster, oEvent) {
                this.initializeNewClaimData(qual);
                this.getView().setBusy(false);
                this._buildWizard(qual);
                var oWtyQual = this._findElementIn('wtyQual', this._wizard.findElements(true));
                if (qual && qual.length > 0) {
                    this.getView().getModel("newClaim").setProperty('/Qualifier/Value', qual);
                    oWtyQual.setEnabled(false);
                } else {
                    oWtyQual.setEnabled(true);
                }
                if (qual && qual === 'RC' && recallMaster) {
                    var recallId = recallMaster;
                    while (recallId.length < 12) recallId = "0" + recallId; //Pad to 12 characters
                    this.getView().getModel("newClaim").setProperty('/RecallMaster/Value', recallId);
                }
            },
            /**
             * Function to build a new wizard
             * @name   encollab.dp.wty.Create#_onEXClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             * @private
             */
            _buildWizard: function(qual) {
                var oPage = this.getView().byId('createClaimPage');
                if (!this._wizard) {
                    this._wizard = sap.ui.xmlfragment("encollab.dp.wty.standardForm", this);
                    oPage.addContent(this._wizard);
                }
                if (this._Qualifier === null) {
                    var vin = this.getView().getBindingContext('vin').getObject().VIN;
                    oPage.setTitle(this.getText('wtyClaimCreateTitle') + ' ' + vin);
                } else {
                    oPage.setTitle(this.getText('wty' + this._Qualifier + 'ClaimCreateTitle'));
                }
                this._setupWtyQualSelect(qual);
                this.getView().byId('onSaveButton').setVisible(true);
            },
            /**
             * Sets up the Qualifier selection box with the relevant qualifiers and their descriptions. 
             * @name   encollab.dp.wty.Create#_onEXClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _setupWtyQualSelect: function(qual) {
                if (this._Qualifier === null) {
                    var oSelect = this._findElementIn('wtyQual', this._wizard.findElements(true));
                    var filters;
                    if (qual && qual.length > 0) {
                        filters = new Filter([
                            new Filter("Id", FilterOperator.EQ, qual)
                        ], true);
                    } else {
                        filters = new Filter([
                            new Filter("Id", FilterOperator.NE, 'F1'), // Free Service 1000
                            new Filter("Id", FilterOperator.NE, 'F2'), // Free Service 10000
                            new Filter("Id", FilterOperator.NE, 'PS'), // PDI
                            new Filter("Id", FilterOperator.NE, 'RC'), // Recall
                            new Filter("Id", FilterOperator.NE, 'SC'), // Shipping Costs
                            new Filter("Id", FilterOperator.NE, 'EX'),// External Services
                            //BOC - C001
                            new Filter("Id", FilterOperator.NE, 'F3'), // Free Service 5000
                            new Filter("Id", FilterOperator.NE, 'F4'), // Free Service 15000
                            new Filter("Id", FilterOperator.NE, 'F5'), // Free Service 20000
                            new Filter("Id", FilterOperator.NE, 'F6'), // Free Service 30000
                            new Filter("Id", FilterOperator.NE, 'F7'), // Free Service 40000
                            new Filter("Id", FilterOperator.NE, 'F8') //  Free Service 50000
                            //EOC - C001
                             ], true);
                    }
                    oSelect.bindItems({
                        model: 'wty',
                        path: "/WarrantyQualifiers",
                        template: new Item({
                            key: "{wty>Id}",
                            text: "{wty>Description}"
                        }),
                        filters: filters
                    });
                }
            },
            /**
             * Initialize a new claim based on the current Qualifier
             * @name   encollab.dp.wty.Create#initializeNewClaimData
             * @method
             */
            initializeNewClaimData: function() {
                var oComponent = this.myComponent;
                switch (this._Qualifier) {
                    case 'SC':
                    case 'EX':
                        this.getView().getModel("newClaim").setData({
                            Header: {
                                ClaimType: 'ZCLM',
                                Dealer: oComponent.getMySettingValue('DP_KUNNR'),
                                ReferenceDate: new Date(),
                                ReferenceNo: oComponent.getMyId(),
                                ClaimDescr: ''
                            },
                            Qualifier: {
                                Id: 'ZACSWY_WARQUAL',
                                Value: this._Qualifier
                            }
                        });
                        break;
                    default:
                        var oVehicle = this.getView().getBindingContext('vin').getObject();
                        this.getView().getModel("newClaim").setData({
                            Header: {
                                ClaimType: 'ZCLM',
                                Dealer: oComponent.getMySettingValue('DP_KUNNR'),
                                ReferenceDate: new Date(),
                                VIN: oVehicle.VIN,
                                ReferenceNo: oComponent.getMyId(),
                                ClaimDescr: ''
                            },
                            CausalPart: {
                                ItemType: 'MAT',
                                Quantity: '1',
                                UoM: 'PC',
                                CausalPart: true,
                                MaterialId: ''
                            },
                            Qualifier: {
                                Id: 'ZACSWY_WARQUAL',
                                Value: oComponent.getMySettingValue('DP_WTYQUAL') || '0K',
                            },
                            Mileage: {
                                Id: 'ZACS_V_DISTANCE',
                                Value: '0',
                            },
                            RepairFrom: {
                                Id: 'ZACS_REPDATE',
                                Value: new Date()
                            },
                            RepairTo: {
                                Id: 'ZACS_REPENDDATE',
                                Value: new Date()
                            },
                            PartInvoiceNo: {
                                Id: 'ZZSINVOICE_NO',
                                Value: ''
                            },
                            PartInvoiceDate: {
                                Id: 'ZZSINVOICE_DT',
                                Value: null
                            },
                            PartInvoiceMileage: {
                                Id: 'ZZSINVOICE_ML',
                                Value: '0'
                            },
                            RecallMaster: {
                                Id: 'ZACSWYRC_CLMNO',
                                Value: ""
                            }
                        });
                }
            },
            /**
             * Search help for Causal Parts
             * @name   encollab.dp.wty.Create#onCausalPartSearch
             * @method
             */
            onCausalPartSearch: function(oEvent) {
                var oView = this.getView();
                var filters = [];
                var searchString = oEvent.getParameter('query');
                var oCausalPartList = this._findElementIn('causalPartList', this.getView().findElements(true));
                oView.getModel('newClaim').setProperty('/CausalPart/MaterialId', '');
                if (searchString && searchString.length > 0) {
                    var oTemplate = new StandardListItem({
                        title: "{part>PartID}",
                        description: "{part>PartDesc}"
                    });
                    var status = this._findElementIn('causalPartListLabel', this.getView().findElements(true));
                    filters = [
                        new Filter("PartDesc", FilterOperator.Contains, searchString.toUpperCase()),
                        new Filter("PartID", FilterOperator.Contains, searchString.toUpperCase())
                    ];
                    oCausalPartList.bindItems({
                        model: 'part',
                        path: "/Parts",
                        parameters: {
                            select: "PartID,PartDesc,Uom"
                        },
                        template: oTemplate,
                        filters: [
                            new Filter(filters, false)
                        ],
                        events: {
                            dataRequested: function() {
                                status.setText('Searching....');
                                oView.setBusy(true);
                            },
                            dataReceived: function(mResponse) {
                                var matches = mResponse.getParameter('data').results.length;
                                if (matches < 20) {
                                    status.setText(mResponse.getParameter('data').results.length + ' matches found');
                                } else {
                                    status.setText('');
                                }
                                oView.setBusy(false);
                            }
                        }
                    });
                } else {
                    oCausalPartList.unbindItems();
                }
            },
            /**
             * Saves the Causal part after selection
             * @name   encollab.dp.wty.Create#onSelectCausalPart
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onSelectCausalPart: function(oEvent) {
                this.getView().getModel('newClaim').setProperty('/CausalPart/MaterialId', oEvent.getParameter('listItem').getTitle());
                var oCausalPartSearch = this._findElementIn('causalSearch', this.getView().findElements(true));
                oCausalPartSearch.setValue(oEvent.getParameter('listItem').getTitle() + ' - ' + oEvent.getParameter('listItem').getDescription());
                var oCausalPartList = this._findElementIn('causalPartList', this.getView().findElements(true));
                oCausalPartList.unbindItems();
                var status = this._findElementIn('causalPartListLabel', this.getView().findElements(true));
                status.setText('');
                this.onFieldChange(oEvent);
            },
            /**
             * Checks if the date supplied is valid
             * @name   encollab.dp.wty.Create#isValidDate
             * @param {date} value 
             * @method
             */
            isValidDate: function(value) {
                return value > new Date() ? 'Error' : 'None';
            },
            /**
             * @name   encollab.dp.wty.Create#onClaimTypeChange
             * @method
             */
            onClaimTypeChange: function(oEvent) {
                var mNewClaim = this.getView().getModel("newClaim").getData().Header;
                var vPath = "/UserSettings(UserId='" + this.myComponent.getMyId() + "',Name='DP_CLAIMTYPE')";
                this.getModel('core').update(vPath, {
                    Value: mNewClaim.ClaimType
                }, {
                    merge: true
                });
                this.onFieldChange(oEvent);
            },
            /**
             * @name   encollab.dp.wty.Create#onCausalPartSearch
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onQualifierChange: function(oEvent) {
                var mNewClaim = this.getView().getModel("newClaim").getData().Qualifier;
                var vPath = "/UserSettings(UserId='" + this.myComponent.getMyId() + "',Name='DP_WTYQUAL')";
                this.getModel('core').update(vPath, {
                    Description: 'Default Wty Qualifier',
                    Value: mNewClaim.Value
                }, {
                    merge: true
                });
                this.onFieldChange(oEvent);
            },
            /**
             * @param {sap.ui.base.Event} oEvent 
             * @name   encollab.dp.wty.Create#onDealerChange
             * @method
             */
            onDealerChange: function(oEvent) {
                var mNewClaim = this.getView().getModel("newClaim").getData().Header;
                var vPath = "/UserSettings(UserId='" + this.myComponent.getMyId() + "',Name='DP_KUNNR')";
                this.getModel('core').update(vPath, {
                    Value: mNewClaim.Dealer
                }, {
                    merge: true
                });
                this.onFieldChange(oEvent);
            },
            /**
             * @param {sap.ui.base.Event} oEvent 
             * @name   encollab.dp.wty.Create#onRefDateChange
             * @method
             */
            onRefDateChange: function(oEvent) {
                this.onFieldChange(oEvent);
            },
            /**
             * @param {sap.ui.base.Event} oEvent 
             * @name   encollab.dp.wty.Create#onRepDateChange
             * @method
             */
            onRepDateChange: function(oEvent) {
                this.onFieldChange(oEvent);
            },
            /**
             * Use this method checks the validity of all fields
             * @name   encollab.dp.wty.Create#onFieldChange
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onFieldChange: function(oEvent) {
                var allOk = true;
                var newClaim = this.getView().getModel('newClaim').getProperty('/');
                if (newClaim.Header.ReferenceDate > new Date()) {
                    allOk = false;
                }
                if (!newClaim.Header.ReferenceNo || !newClaim.Header.ReferenceNo.length) {
                    allOk = false;
                }
                if (!newClaim.Header.ClaimDescr || !newClaim.Header.ClaimDescr.length) {
                    allOk = false;
                }
                // if (!newClaim.CausalPart.MaterialId || !newClaim.CausalPart.MaterialId.length) {
                //     allOk = false;
                // }
                if (newClaim.Mileage && Number(newClaim.Mileage.Value) <= 0) {
                    allOk = false;
                }
                // Special handling for Parts Claims
                if (newClaim.Qualifier.Value === 'SP') {
                    if (
                        newClaim.PartInvoiceDate &&
                        (newClaim.PartInvoiceDate.Value === null || newClaim.PartInvoiceDate.Value > new Date())
                    ) {
                        allOk = false;
                    }
                    if (newClaim.PartInvoiceNo && newClaim.PartInvoiceNo.Value.length < 1) {
                        allOk = false;
                    }
                    if (newClaim.PartInvoiceMileage && Number(newClaim.PartInvoiceMileage.Value) <= 0) {
                        allOk = false;
                    }
                }
                this.getView().byId('onSaveButton').setEnabled(allOk && this._readyToCreate());
            },
            _readyToCreate: function() {
                var oNewClaim = this.getView().getModel("newClaim").getData();
                if (
                    oNewClaim &&
                    oNewClaim.Header.ClaimType !== '' &&
                    oNewClaim.Header.Dealer !== '' &&
                    oNewClaim.Header.Plant !== '' &&
                    oNewClaim.Header.ReferenceDate <= new Date() &&
                    oNewClaim.Header.ReferenceNo !== '' &&
                    oNewClaim.Header.ClaimDescr !== '' //&&
                    //oNewClaim.CausalPart.MaterialId !== ''
                ) {
                    return true;
                } else {
                    return false;
                }
            },
            /**
             * This takes the new claim data and creates the claim in SAP. It also performs a followup action on the claim if necessary. 
             * On success the Wizard is reset, otherwise errors are displayed.
             * @name   encollab.dp.wty.Create#createClaim
             * @param  {object} oPayload 
             * @method
             */
            createClaim: function(oPayload) { // I really should use promises here
                this.resetMessagePopover();
                var newClaimId;
                var fSuccess = function(mResponse) {
                    this.initializeNewClaimData();
                    this._wizard.destroy();
                    this._wizard = null;
                    this.myRouter.navTo("wtydetail", {
                        wtyPath: "WarrantyClaims('" + mResponse.ClaimNo + "')"
                    });
                    this.MessageToast.show(this.getText('wtyClaimCreated', [mResponse.ClaimNo]));
                    this.busyDialog.close();
                };
                var fError = function(oError) {
                    this.busyDialog.close();
                    this.gatewayError(oError);
                    if (newClaimId) {
                        this.initializeNewClaimData();
                        this._wizard.destroy();
                        this._wizard = null;
                        this.myRouter.navTo("wtydetail", {
                            wtyPath: "WarrantyClaims('" + newClaimId + "')"
                        });
                        this.MessageToast.show(this.getText('wtyClaimCreated', [newClaimId]));
                    }
                };
                var fPerformFollowupAction = function(mResponse) {
                    newClaimId = mResponse.ClaimNo;
                    var oParams = {
                        ClaimNo: mResponse.ClaimNo,
                        Action: followupAction
                    };
                    this.getModel('wty').callFunction("/WarrantyClaimAction", {
                        method: 'POST',
                        urlParameters: oParams,
                        success: fSuccess.bind(this),
                        error: fError.bind(this)
                    });
                };
                var fNext, followupAction;
                var sWtyQual = this.getView().getModel("newClaim").getProperty('/Qualifier/Value');
                switch (sWtyQual) {
                    case 'F1':
                    case 'F2':
                    //BOC - C002
                    case 'F3':
                    case 'F4':
                    case 'F5':
                    case 'F6':
                    case 'F7':
                    case 'F8':
                    //EOC - C002
                    case 'PS':
                    case 'RC':
                        fNext = fPerformFollowupAction;
                        followupAction = 'Z050';
                        break;
                    default:
                        fNext = fSuccess;
                }
                // Send OData Create request
                this.getView().getModel('wty').create("/WarrantyClaims", oPayload, {
                    success: fNext.bind(this),
                    error: fError.bind(this)
                });
            },
            /**
             * Takes the wizard data and prepares the claim's payload before saving
             * @name   encollab.dp.wty.Create#onSave
             * @param  {object} oPayload 
             * @method
             */
             //BOC-C004
             	onSave:function(oEvent){
            var sWtyQual = this.getView().getModel("newClaim").getProperty('/Qualifier/Value');
            //BOC-C006
         if (sWtyQual === "SC" || sWtyQual === "EX") {
          //BOC-COO6
              this.oClaimpayload();
          }else{
                var millage = this.getView().getModel("newClaim").getData().Mileage.Value;
          var isValidMileage = this.ValidatemileageInput(millage);
          //BOC-C005
            var partsMileage = this.getView().getModel("newClaim").getData().PartInvoiceMileage.Value;
             var isValidPartsMileage = this.ValidatemileageInput(partsMileage);

       	if (isValidMileage && isValidPartsMileage) {
        //EOC-C005
              this.oClaimpayload();
          }
}
      },
       oClaimpayload: function(oEvent) {
                this.busyDialog.open();
                var newClaim = this.getView().getModel("newClaim").getData();
                var mPayload = newClaim.Header;
                mPayload.ApprovalDate = new Date();
                mPayload.ReferenceDate = this.accountForUTCDate(mPayload.ReferenceDate);
                mPayload.Extensions = [];
                mPayload.Extensions.push(newClaim.Qualifier);
                if (this._Qualifier === null) {
                    mPayload.Extensions.push(newClaim.Mileage);
                    mPayload.Extensions.push({
                        Id: newClaim.RepairFrom.Id,
                        Value: this.accountForUTCDate(newClaim.RepairFrom.Value).toISOString().replaceAll('-', '').substr(0, 8)
                    });
                    mPayload.Extensions.push({
                        Id: newClaim.RepairTo.Id,
                        Value: this.accountForUTCDate(newClaim.RepairTo.Value).toISOString().replaceAll('-', '').substr(0, 8)
                    });
                }
                // Parts Claim
                if (newClaim.Qualifier.Value === 'SP') {
                    mPayload.Extensions.push(newClaim.PartInvoiceNo);
                    mPayload.Extensions.push({
                        Id: newClaim.PartInvoiceDate.Id,
                        Value: this.accountForUTCDate(newClaim.PartInvoiceDate.Value).toISOString().replaceAll('-', '').substr(0, 8)
                    });
                    mPayload.Extensions.push(newClaim.PartInvoiceMileage);
                }
                // Recall Claim
                if (newClaim.Qualifier.Value === 'RC') {
                    mPayload.Extensions.push(newClaim.RecallMaster);
                }
                this.createClaim(mPayload);
            },
            /**
            * This method validate mileageinput,this method not allow  special char & decimal in mileage input
            */
            ValidatemileageInput: function(mileageCurr) {
          var numbers = /^[0-9]+$/;
         if (mileageCurr.match(numbers)) {
          return true;
        } else {
        //BOC-C003
          this.MessageToast.show("Please Enter Mileage Without Separators");
        //EOC-C003
          return false;
        }
      },
      //EOC-C004

            onCancel: function() {
                this.onNavBack();
            },
            onNavBack: function() {
                this._wizard.destroy();
                this._wizard = null;
                this.myRouter.navTo("vindetail", {
                    vehiclePath: this.getView().getBindingContext('vin').getProperty("VIN")
                });
            }
        });
    });