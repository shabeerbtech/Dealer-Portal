sap.ui.define([
        "encollab/dp/wty/BaseController",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/Sorter",
        "sap/ui/model/json/JSONModel",
    ],
    /**
     * <p>This is the controller for the page that handles Warranty Enquiry. It serves as the base for all three Claim Enquiry Tiles 
     * as defined on the Dashboard</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Wty</li>
     * <li>Core</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.order.Create.view.xml</li>
     * <li>encollab.dp.partsOrder.MaterialPopover</li>
     * </ul>
     * @class Enquiry
     * @memberOf encollab.dp.wty
     * @extends {encollab.dp.BaseController}
     * @param  {encollab.dp.wty.BaseController} Controller     
     * @param  {sap.ui.model.Filter} Filter         
     * @param  {sap.ui.model.FilterOperator} FilterOperator 
     * @param  {sap.ui.model.Sorter} Sorter         
     * @param  {sap.ui.model.json.JSONModel} JSONModel      
     * @return {encollab.dp.wty.Enquiry}                  
     */
    function(Controller, Filter, FilterOperator, Sorter, JSONModel) {
        "use strict";
        return Controller.extend("encollab.dp.wty.Enquiry", {
            _userAuthorisations: ['WarrantyClaims'],
            _userParameters: [],
            /**
             * Holds all current active oData calls
             * @type {string}
             * @member
             * @name encollab.dp.wty.Enquiry#_activeCalls
             */
            _activeCalls: [],
            /**
             * Holds the current qualifier
             * @type {string}
             * @member
             * @name encollab.dp.wty.Enquiry#_Qualifier
             */
            _Qualifier: null,
            /**
             * Initialization of the controller. Sets up a new claim JSON model. 
             * @name   encollab.dp.wty.Enquiry#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);

                this.model = new JSONModel({
                    count: 0,
                    claims: [],
                    pageTitle: this.getText('wtyEnquiryTitle'),
                    createButtonVisible: false,
                    createButtonText: null,
                });

                this.setModel(this.model, 'data');

                this.getModel('wty').setSizeLimit(100);

                this.myRouter.getRoute("wty").attachPatternMatched(this._onWtyAllMatched, this);
                this.myRouter.getRoute("wtysc").attachPatternMatched(this._onWtySCMatched, this);
                this.myRouter.getRoute("wtyex").attachPatternMatched(this._onWtyEXMatched, this);
            },
            /**
             * This is executed when the Enquiry is meant to find ALL claim types. It leaves the _Qualifier member variable blank
             * @name  encollab.dp.wty.Enquiry#_onWtyAllMatched
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _onWtyAllMatched: function(oEvent) {
                this._Qualifier = null;

                this._onWtyMatched(oEvent);
            },
            /**
             * This is executed when we're only interested in Shipping claims. It sets the _Qualifier member to SC
             * @name  encollab.dp.wty.Enquiry#_onWtySCMatched
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _onWtySCMatched: function(oEvent) {
                this._Qualifier = 'SC';

                this._onWtyMatched(oEvent);
                this.getModel('data').setProperty('/createButtonText', this.getText('wtyCreateSCClaimButtonText'));
            },
            /**
             * This is executed when we're only interested in EX claims. It sets the _Qualifier member to EX
             * @name  encollab.dp.wty.Enquiry#_onWtyEXMatched
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _onWtyEXMatched: function(oEvent) {
                this._Qualifier = 'EX';

                this._onWtyMatched(oEvent);
                this.getModel('data').setProperty('/createButtonText', this.getText('wtyCreateEXClaimButtonText'));
            },
            /**
             * In all scenario's, the title is set as per the _Qualifier field's value. For SC and EX claims, the "Create Claim"
             * button is enabled, and it initializes the first search based on the dates of the date box. 
             * @name  encollab.dp.wty.Enquiry#_onWtyMatched
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            _onWtyMatched: function(oEvent) {
                if (this._Qualifier !== null) {
                    this.getModel('data').setProperty('/pageTitle', this.getText('wtyEnquiry' + this._Qualifier + 'Title'));
                    this.getModel('data').setProperty('/createButtonVisible', true);
                } else {
                    this.getModel('data').setProperty('/pageTitle', this.getText('wtyEnquiryTitle'));
                    this.getModel('data').setProperty('/createButtonVisible', false);
                }
                var dates = this.byId('wtySearchBar').getDateRange();
                var aCust = this.getModel('core').getProperty("/Users('" + this.myComponent.getMyId() + "')/Dealers");
                if (!aCust || !aCust.length || aCust.length === 0) {
                    console.log('what gives');
                    console.log(aCust);
                } else {
                    this._search(dates.first, dates.last);
                }
            },
            /**
             * Filters the current list from the search string. This filter is local
             * @name  encollab.dp.wty.Enquiry#onSearchFilter
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onSearchFilter: function(oEvent) {
                var searchString = oEvent.getParameter('filter');
                this._filter(searchString);
            },
            /**
             * Searches the ODATA channel and returns all claims between the dates selected.
             * @name  encollab.dp.wty.Enquiry#onSearchSearch
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onSearchSearch: function(oEvent) {
                var firstDate = oEvent.getParameter('first');
                var lastDate = oEvent.getParameter('last');

                this._search(firstDate, lastDate);
            },
            /**
             * Filters the list based on the selection of the Icon tab bar, which is holding all statusses currently in the list
             * @name  encollab.dp.wty.Enquiry#onIconTabBarSelect
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onIconTabBarSelect: function(oEvent) {
                var key = oEvent.getParameter("key");
                key = (key === 'All') ? '' : key;
                this._filter(key);
            },
            /**
             * This is the oData search. First, all activate calls are cancelled. Then, filters are used for Creation Date based on the dates
             * in the search. It also limits claims to the dealers relevant to the current user. 
             * @name  encollab.dp.wty.Enquiry#_search
             * @param {string} firstDate
             * @param {string} lastDate
             * @method
             */
            _search: function(firstDate, lastDate) {

                this.byId('wtyTable').setBusy(true);
                //cancel all active calls
                $.each(this._activeCalls, function(i, a) {
                    a.call();
                });

                var filters = [
                    new Filter('Created_Date', FilterOperator.BT, this.accountForUTCDate(firstDate), this.accountForUTCDate(lastDate))
                ];

                if (this._Qualifier !== null) {
                    filters.push(new Filter('Qualifier', FilterOperator.EQ, this._Qualifier));
                }

                var dealerFilter = [];
                var dealers = this.getModel('core').getProperty("/Users('" + this.myComponent.getMyId() + "')/Dealers");

                for (var d = 0; d < dealers.length; d++) {
                    dealerFilter.push(new Filter('Dealer', FilterOperator.EQ, dealers[d].match(/'(.*)'/i)[1]));
                }

                filters.push(new Filter(dealerFilter, false));

                //push the current call's ABORT function into the active calls. 
                this._activeCalls.push(this.getModel('wty').read('/WarrantyClaims', {
                    filters: filters,
                    urlParameters: {
                        '$top': 999999
                    },
                    success: function(data) {
                        //set active calls to nothing. 
                        this._activeCalls = [];
                        this.byId('wtyTable').setBusy(false);
                        //this.byId('wtyTable').setVisibleRowCount(((data.results.length || 10) > 10) ? 10 : data.results.length);
                        this._prepareResults(data.results);
                    }.bind(this)
                }).abort);

            },
            /**
             * Filters the list based on the search string
             * @name  encollab.dp.wty.Enquiry#_filter
             * @param {string} searchString
             * @method
             */
            _filter: function(searchString) {
                var binding = this.byId('wtyTable').getBinding('rows');
                var filters = new Filter([
                    new Filter("Searcher", FilterOperator.Contains, searchString.toUpperCase()),
                ], false);

                binding.filter(filters, sap.ui.model.FilterType.Control)
            },
            /**
             * All results from the ODATA service are parsed beforehand, so we can get counts of all currently returned 
             * statusses, and to format certain fields so they come out right in the downloads, filters and searches. 
             * @name  encollab.dp.wty.Enquiry#_prepareResults
             * @param {array<objects>} data
             * @method
             */
            _prepareResults: function(data) {
                var counts = {
                    total: {
                        count: 0,
                        description: 'All',
                        show: true,
                        status: "0000"
                    }
                };

                for (var i = 0; i < data.length; i++) {
                    data[i].ClaimNo = parseInt(data[i].ClaimNo);
                    data[i].AmountClaimed = parseInt(data[i].AmountClaimed);
                    data[i].Searcher = [
                        data[i].ClaimNo.toString(),
                        this.formatter.ShortDate(data[i].Created_Date),
                        data[i].ClaimDescr,
                        data[i].VIN,
                        data[i].StatusDescr,
                        data[i].DealerName,
                        data[i].Qualifier,
                        data[i].QualifierText,
                        data[i].AmountClaimed.toString()
                    ].join().toUpperCase();

                    counts.total.count++;
                    if (counts[data[i].StatusId]) {
                        counts[data[i].StatusId].count++
                    } else {
                        counts[data[i].StatusId] = {
                            count: 1,
                            description: data[i].StatusDescr,
                            show: false,
                            status: data[i].StatusId
                        }
                    }
                }

                this.model.setProperty('/claims', data);
                this.model.setProperty('/count', counts);
                this._prepareIconTabBar(counts);
            },
            _prepareIconTabBar: function(statusses) {
                var icons = this.byId('idIconTabBar');
            },
            /**
             * When a material number of pressed, a Popover is displayed with details
             * @name  encollab.dp.wty.Enquiry#onItemPress
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onItemPress: function(oEvent) {
                var oItem = oEvent.getSource().getBindingContext().getObject();
                if (oItem) {
                    if (!this._oMaterialPopover) {
                        this._oMaterialPopover = sap.ui.xmlfragment("encollab.dp.partsOrder.MaterialPopover", this);
                        this.getView().addDependent(this._oMaterialPopover);
                    }
                    this._oMaterialPopover.bindElement("/Materials('" + oItem.Material + "')");
                    this._oMaterialPopover.openBy(oEvent.getSource());
                }
            },
            /**
             * When a Claim number is selected, this navigates to the claim details
             * @name  encollab.dp.wty.Enquiry#onPress
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onPress: function(oEvent) {
                var oItem = oEvent.getSource();
                this.myRouter.navTo("wtydetail", {
                    wtyPath: "WarrantyClaims('" + oItem.getBindingContext('data').getProperty('ClaimNo') + "')" //oEvent.getParameter('listItem').getBindingContext('wty').getPath().substr(1)
                });
                //oItem.removeSelections();
            },
            /**
             * When a VIN is pressed, this navigates to the VIN details
             * @name  encollab.dp.wty.Enquiry#onVINPress
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onVINPress: function(oEvent) {
                var oItem = oEvent.getSource();
                this.myRouter.navTo("vindetail", {
                    vehiclePath: oItem.getBindingContext('data').getProperty('VIN') //oEvent.getParameter('listItem').getBindingContext('wty').getPath().substr(1)
                });
                //oItem.removeSelections();
            },
            /**
             * When the Create Claim button is clicked, navigate to the proper creation screen for this qualifier
             * @name  encollab.dp.wty.Enquiry#onCreateClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onCreateClaim: function(oEvent) {
                if (this._Qualifier !== null && this.isUserAuthorised('WarrantyCreate')) {
                    this.myRouter.navTo('create' + this._Qualifier + 'wty');
                }
            },
        });
    });