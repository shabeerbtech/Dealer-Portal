/**
****************************************************************************************
*  Changed on:  Changed by:   Change ID:  TR Number:        Description:
*  2017.05.10   Subha          C001      GKAK907167        SUBMIT and ADD button
*               z019767                                 enable & disable based on condition.
*                                                       Mileage checks
* 2017.05.18   Subha-z019767   C002      GKAK907208     MessageToast Text
*****************************************************************************************
*/

sap.ui.define([
        "encollab/dp/wty/BaseController",
        "sap/m/MessageBox",
        "sap/m/MessageToast",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/unified/FileUploaderParameter",
        "sap/ui/core/Item",
        "sap/ui/model/json/JSONModel",
        "sap/m/UploadCollectionParameter"
    ],
    /**
     * <p>This acts as the controller for the creation of every qualifier claim, some of which have their own tile, while others go through 
     * the VIN detail screen.</p>
     * <p>
     * Because this is a very large class that consist mostly of event handlers to open en close dialog windows, some of those are skipped for 
     * the sake of brevity. 
     * </p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Wty</li>
     * <li>Core</li>
     * <li>Parts</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.wty.Create.view.xml <small>main view</small></li>
     * <li>encollab.dp.wty.Attachments.fragment.xml</li>
     * <li>encollab.dp.wty.Contribution.fragment.xml</li>
     * <li>encollab.dp.wty.Items.fragment.xml</li>
     * <li>encollab.dp.wty.ItemsTemplate.fragment.xml</li>
     * <li>encollab.dp.wty.addCausalLabourDialog.fragment.xml</li>
     * <li>encollab.dp.wty.addCausalPartDialog.fragment.xml</li>
     * <li>encollab.dp.wty.addCausalTemplate.fragment.xml</li>
     * <li>encollab.dp.wty.addFlatrateDialog.fragment.xml</li>
     * <li>encollab.dp.wty.addFlatrateTemplate.fragment.xml</li>
     * <li>encollab.dp.wty.addItemActionSheet.fragment.xml</li>
     * <li>encollab.dp.wty.addMaterialDialog.fragment.xml</li>
     * <li>encollab.dp.wty.addMaterialTemplate.fragment.xml</li>
     * <li>encollab.dp.wty.addSubletDialog.fragment.xml</li>
     * <li>encollab.dp.wty.addSundryDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeDirectSwapDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeHoursDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeInvoiceDateDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeInvoiceNumberDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeMOPEDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeMileageDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changePFPDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changePartMileageDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeQtyDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeReferenceDateDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeReferenceDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeSymptomDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeSymptomTemplate.fragment.xml</li>
     * <li>encollab.dp.wty.changeTroubleDialog.fragment.xml</li>
     * <li>encollab.dp.wty.changeValueDialog.fragment.xml</li>
     * <li>encollab.dp.wty.claimAmendDialog.fragment.xml</li>
     * <li>encollab.dp.wty.claimDeleteDialog.fragment.xml</li>
     * <li>encollab.dp.wty.claimSubmitDialog.fragment.xml</li>
     * <li>encollab.dp.wty.claimTemplate.fragment.xml</li>
     * <li>encollab.dp.wty.createFromPWADialog.fragment.xml</li>
     * <li>encollab.dp.wty.deleteMOPEDialog.fragment.xml</li>
     * <li>encollab.dp.wty.deletePFPDialog.fragment.xml</li>
     * <li>encollab.dp.wty.headerChangePopover.fragment.xml</li>
     * <li>encollab.dp.wty.itemDeleteDialog.fragment.xml</li>
     * <li>encollab.dp.wty.partReturnDialog.fragment.xml</li>
     * <li>encollab.dp.wty.qualDialog.fragment.xml</li>
     * <li>encollab.dp.wty.repDateDialog.fragment.xml</li>
     * <li>encollab.dp.wty.texts.fragment.xml</li>
     * <li>encollab.dp.wty.wtyTexts.fragment.xml</li>
     * </ul>
     * @class Detail
     * @memberOf encollab.dp.wty
     * @extends {encollab.dp.wty.BaseController}
     * @return {encollab.dp.wty.Detail}
     * 
     * @param {encollab.dp.wty.BaseController} Controller   
     * @param {sap.ui.core.routing.History} History
     * @param {sap.ui.model.json.JSONModel} JSONModel 
     * @param {sap.m.StandardListItem} StandardListItem
     * @param {sap.m.Item} Item  
     * @param {sap.ui.model.Filter} Filter         
     * @param {sap.ui.model.FilterOperator} FilterOperator       
     */
    function(Controller, MessageBox, MessageToast, Filter, FilterOperator, FileUploaderParameter, Item, JSONModel, UploadCollectionParameter) {
        "use strict";
        return Controller.extend("encollab.dp.wty.Detail", {
            _userAuthorisations: ['WarrantyClaims'],
            /**
             * This array holds the user parameters required to run this controller. In this case, the user has to be set up
             * with SPA, VKO, VTW (the entire sales area), and WRK (plant)
             *
             * @private
             * @member
             * @name   encollab.dp.wty.Detail#_userParameters
             */
            _userParameters: ['SPA', 'VKO', 'VTW', 'WRK'],
            /**
             * Variable that tracks wether the current claim is related to a vehicle or not
             * @type {boolean}
             * @name   encollab.dp.wty.Detail#_vehicleClaim
             */
            _vehicleClaim: false,
            /**
             * Initialization of the controller
             * @name   encollab.dp.wty.Detail#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);

                if (this._userAccountIsValid) {
                    this.setModel(new JSONModel(), "viewModel");
                    this.myRouter.getRoute("wtydetail").attachPatternMatched(this._onObjectMatched, this);
                }
            },
            /**
             * When the route matches, the current claim is fetched from SAP and bound to the view. 
             * @name   encollab.dp.wty.Detail#_onObjectMatched
             * @method
             */
            _onObjectMatched: function(oEvent) {
                var oView = this.myView;
                oView.setBusy(true);
                var sWtyPath = "/" + oEvent.getParameter("arguments").wtyPath;
                this.resetMessagePopover();
                oView.bindElement({
                    model: 'wty',
                    path: sWtyPath,
                    parameters: {
                        expand: 'Items,Texts,Extensions,Creator,Attachments' //,Changer' //,WtyHeaderAttachments'
                    },
                    events: {
                        dataRequested: this._dataRequested.bind(this),
                        dataReceived: this._dataReceived.bind(this),
                        change: this._dataChanged.bind(this)
                    }
                });
                //Check if the data is already on the client
                if (!this.getModel('wty').getData(sWtyPath + '/WtyItems')) {
                    // Check that the part specified actually was found.
                    oView.getElementBinding('wty').attachEventOnce("dataReceived", jQuery.proxy(function() {
                        var oData = this.getModel('wty').getData(sWtyPath);
                        if (!oData) {
                            this.fireDetailNotFound();
                        } else {
                            this.fireDetailChanged(sWtyPath);
                        }
                    }, this));
                    oView.setBusy(false);
                } else {
                    this.fireDetailChanged(sWtyPath);
                }
            },
            _dataRequested: function() {
                this.getView().setBusy(true);
            },
            _dataReceived: function(oEvent) {
                this._setup(oEvent.getParameter('data'));
            },
            _dataChanged: function(oEvent) {
                if (this.getView().getBindingContext('wty')) {
                    var data = this.getModel('wty').getProperty(this.getView().getBindingContext('wty').getPath());
                    this._setup(data)
                }

            },
            /**
             * Method to set up a local JSON model. It sets various flags about the type of claim so that it can 
             * be tracked, and used to set things to enabled or disabled on the view
             * @name   encollab.dp.wty.Detail#_setup
             * @method
             */
            _setup: function(oData) {
                this.getView().setBusy(true);
                var path = this.getView().getBindingContext('wty').getPath();
                var data = this._expandElementBindingToData(path, this.getModel('wty'));
                var out = this._formatForDownload(data);
                this.byId('idWtyButtonDownload').setData(out);

                // Set all flags to false
                var viewModel = this.getModel('viewModel');
                viewModel.setProperty('/isMyDealer', false);
                viewModel.setProperty('/isChangeable', false);
                viewModel.setProperty('/isTextsChangeable', false);
                viewModel.setProperty('/isAttachmentsChangeable', false);
                viewModel.setProperty('/isSubmitable', false);
                viewModel.setProperty('/isReadyToSubmit', false);
                viewModel.setProperty('/isDeleteable', true);
                viewModel.setProperty('/isVehicleClaim', false);
                this._vehicleClaim = false;

                if (oData.VIN.length > 0) {
                    viewModel.setProperty('/isVehicleClaim', true);
                    this._vehicleClaim = true;
                }

                // Can't do anything unless for my dealer
                if (this.getOwnerComponent().getMyDealers().filter(
                        function(a) {
                            return a.Id === oData.Dealer;
                        }).length !== 0) {
                    viewModel.setProperty('/isMyDealer', true);
                    if (
                        oData.StatusId === '0005' //Initial Status
                        || oData.StatusId === '0135' //Claim Returned
                    ) {
                        viewModel.setProperty('/isSubmitable', true);
                        viewModel.setProperty('/isReadyToSubmit', true);
                        viewModel.setProperty('/isTextsChangeable', true);
                        viewModel.setProperty('/isAttachmentsChangeable', true);
                        switch (oData.Qualifier) {
                            case 'F1': //Templated claims cannot be modified
                            case 'F2':
                            //BOC-C001
                            case 'F3':
                            case 'F4':
                            case 'F5':
                            case 'F6':
                            case 'F7':
                            case 'F8':
                            //EOC-C001
                             //case 'PD':
                            case 'PS':
                            case 'RC':
                                break;
                            default:
                                viewModel.setProperty('/isChangeable', true);
                        }
                    }
                }

                this._bindExtensions();

                this.getView().setBusy(false);
            },
            /**
             * Not all claim related fields are in a single structure, some come through as Extensions, which are separate lines. 
             * This methods binds all the relevant extensions to the header. 
             * @name   encollab.dp.wty.Detail#_bindExtensions
             * @method
             */
            _bindExtensions: function() {
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                // this.getView().byId('idQual').bindElement({
                //     model: 'wty',
                //     path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACSWY_WARQUAL')"
                // });
                this.getView().byId('idMOPE').bindElement({
                    model: 'wty',
                    path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZMOPE')"
                });

                if (this._vehicleClaim) {
                    this.getView().byId('idPFP').bindElement({
                        model: 'wty',
                        path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACSWYAD_DEFPART')"
                    });
                    this.getView().byId('idMileage').bindElement({
                        model: 'wty',
                        path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACS_V_DISTANCE')"
                    });
                    this.getView().byId('idSymptom').bindElement({
                        model: 'wty',
                        path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACSWYAD_DEFCT')"
                    });
                    this.getView().byId('idTrouble').bindElement({
                        model: 'wty',
                        path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZTROUBLE_CODE')"
                    });

                    var repDate = this.getModel('wty').getProperty("/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACS_REPDATE')").Value;
                    var repEndDate = this.getModel('wty').getProperty("/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACS_REPENDDATE')").Value;
                    var oRepDate = new Date(repDate.substr(0, 4), repDate.substr(4, 2) - 1, repDate.substr(6, 2));
                    var oRepEndDate = new Date(repEndDate.substr(0, 4), repEndDate.substr(4, 2) - 1, repEndDate.substr(6, 2));
                    var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
                        pattern: "dd/MM/yyyy"
                    });
                    this.getView().byId('idRepairRange').bindElement({
                            model: 'wty',
                            path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACS_REPDATE')"
                        })
                        .setText(
                            oDateFormat.format(oRepDate) + '-' + oDateFormat.format(oRepEndDate)
                        );
                }
                if (this.getView().getBindingContext('wty').getObject().Qualifier === 'SP') {
                    this.getView().byId('idPartInvoiceDate').bindElement({
                        model: 'wty',
                        path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZSINVOICE_DT')"
                    });
                    this.getView().byId('idPartInvoiceNo').bindElement({
                        model: 'wty',
                        path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZSINVOICE_NO')"
                    });
                    this.getView().byId('idPartMileage').bindElement({
                        model: 'wty',
                        path: "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZSINVOICE_ML')"
                    });

                }
            },
            /**
             * Formatter for Role
             * @param {string} itemType 
             * @param {string} causalPart 
             * @name   encollab.dp.wty.Detail#_bindExtensions
             * @method
             */
            itemRoleFormatter: function(itemtype, causalPart) {
                if (causalPart) {
                    switch (itemtype) {
                        case 'MAT':
                            return 'CausalPart';
                        case 'FR':
                            return 'CausalLabour';
                        default:
                            return 'CausalOther';
                    }
                }
            },
            /**
             * Can the current claim be changed? 
             * @name   encollab.dp.wty.Detail#isChangeable
             * @method
             */
            isChangeable: function() {
                return this.getModel('viewModel').getProperty('/isChangeable');
            },
            /**
             * Can the current claim be amended? 
             * @name   encollab.dp.wty.Detail#isAmendable
             * @method
             */
            isAmendable: function(obj) {
                if (!obj) return false;

                if (this.getView().getBindingContext('wty')) {
                    var oWtyHeader = this.getView().getBindingContext('wty').getObject();
                    return oWtyHeader ? (oWtyHeader.ProcessingStatus === "B006") : false;
                }
            },
            onIconTabBarSelect: function(oEvent) {
                var oTabItem = oEvent.getParameter('item');
                if (oTabItem.getId().indexOf('iconTabTexts') != -1) {
                    //this._checkInchcapeTexts();
                }
            },
            /**
             * Should the attachments be displayed?
             * @name   encollab.dp.wty.Detail#attachmentsVisible
             * @method
             */
            attachmentsVisible: function(obj) {
                return this.isChangeable() || this.formatter.arrayCountVisible(obj);
            },
            /**
             * Creates the URL for an attachment
             * @name   encollab.dp.wty.Detail#attachmentURL
             * @param {string} docid
             * @method
             */
            attachmentURL: function(docid) {
                return this.getModel('wty').sServiceUrl + "/Attachments('" + docid + "')/$value";
            },
            /**
             * Creates the URL for an attachment
             * @name   encollab.dp.wty.Detail#thumbnailURL
             * @param {string} mimetype 
             * @param {string} docid
             * @method
             */
            thumbnailURL: function(mimetype, docid) {
                return mimetype.substr(0, 5) === 'image' ? this.attachmentURL(docid) : null;
            },
            /**
             * Can the current claim be submitted
             * @name   encollab.dp.wty.Detail#isReadyToSubmit
             * @method
             */
            isReadyToSubmit: function(obj) {
                if (this.isChangeable()) {
                    if (this.getView().getBindingContext('wty')) {
                        return this._checkDataComplete();
                    }
                }
            },
            /**
             * Can the current claim be created
             * @name   encollab.dp.wty.Detail#isCreateable
             * @method
             */
            isCreateable: function(obj) {
                if (!obj) return false;

                if (this.getView().getBindingContext('wty')) {
                    var oWtyHeader = this.getView().getBindingContext('wty').getObject();
                    return oWtyHeader ? oWtyHeader.ClaimType === "ZAUT" && oWtyHeader.ProcessingStatus === "B006" : false;
                }
            },
            /**
             * @name   encollab.dp.wty.Detail#isReadyToCreate
             * @method
             */
            isReadyToCreate: function(obj) {
                if (!obj) return false;

                if (this.getView().getBindingContext('wty')) {
                    var oWtyHeader = this.getView().getBindingContext('wty').getObject();
                    return oWtyHeader ? (oWtyHeader.ClaimType === "ZAUT" && oWtyHeader.ProcessingStatus === "B006") : false;
                }
            },
            returnPartVisible: function(status) {
                var oClaim = this.getModel('wty').getObject();

            },
            /**
             * On qualifier press, open a change dialog and bind a model
             * @name   encollab.dp.wty.Detail#onQualPress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onQualPress: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.qualDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            /**
             * On invoice date press, open a change dialog and bind a model
             * @name   encollab.dp.wty.Detail#onInvoiceDatePress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onInvoiceDatePress: function(oEvent) {
                this._onExtensionPress('changeInvoiceDateDialog', 'idPartInvoiceDate')
            },
            /**
             * On invoice date change, fetch the new extension value
             * @name   encollab.dp.wty.Detail#onInvoiceDateChange
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onInvoiceDateChange: function(oEvent) {
                this._onExtensionChange('idPartInvoiceDate', sap.ui.getCore().byId('newInvoiceDate').getValue())
            },
            /**
             * On invoice number press, open a change dialog and bind a model
             * @name   encollab.dp.wty.Detail#onInvoiceNumberPress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onInvoiceNumberPress: function(oEvent) {
                this._onExtensionPress('changeInvoiceNumberDialog', 'idPartInvoiceNo')
            },
            /**
             * On invoice number change, fetch the new extension value
             * @name   encollab.dp.wty.Detail#onInvoiceNumberChange
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onInvoiceNumberChange: function(oEvent) {
                this._onExtensionChange('idPartInvoiceNo', sap.ui.getCore().byId('newInvoiceNumber').getValue())
            },
            /**
             * On part mileage press, open a change dialog and bind a model
             * @name   encollab.dp.wty.Detail#onPartMileagePress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onPartMileagePress: function(oEvent) {
                this._onExtensionPress('changePartMileageDialog', 'idPartMileage')
            },
            /**
             * On part mileage change, fetch the new extension value
             * @name   encollab.dp.wty.Detail#onPartMileageChange
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onPartMileageChange: function(oEvent) {
                this._onExtensionChange('idPartMileage', sap.ui.getCore().byId('newPartMileage').getValue())
            },
            /**
             * On mileage press, open a change dialog and bind a model
             * @name   encollab.dp.wty.Detail#onMileagePress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onMileagePress: function(oEvent) {
                this._onExtensionPress('changeMileageDialog', 'idMileage')
            },
            /**
             * On mileage change, fetch the new extension value
             * @name   encollab.dp.wty.Detail#onMileageChange
             * @param {sap.ui.core.Event} oEvent
             * @method
             */

            onMileageChange: function(oEvent) {
            //BOC-C001
                var mileageCurr = sap.ui.getCore().byId('newMileage').getValue();
                var isValidMileage = this.ValidatemileageInput(mileageCurr);
                if (isValidMileage)
            //EOC-C001
                this._onExtensionChange('idMileage', sap.ui.getCore().byId('newMileage').getValue())
            },


            //BOC-C001
            /**
             * This method validate mileageinput,this method not allow  special char & decimal in mileage input
              */

            ValidatemileageInput: function(mileageCurr) {
          var numbers = /^[0-9]+$/;
         if (mileageCurr.match(numbers)) {
          return true;
        } else {
        //BOC-C002
          MessageToast.show("Please Enter Mileage Without Separators");
       //EOC-C002
          return false;
        }
      },
          //EOC-C001

            /**
             * This method opens a dialog of the type provided, and binds the current WTY model to it. Finally, it opens the dialog. 
             * @name   encollab.dp.wty.Detail#_onExtensionPress
             * @param {string} dialog
             * @param {string} id 
             * @method
             */
            _onExtensionPress: function(dialog, id) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty." + dialog, this);

                this._oDialog.bindElement({
                    model: 'wty',
                    path: this.getView().byId(id).getBindingContext('wty').getPath()
                });
                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            /**
             * Fetches the path of the extension provided, calls SAP to change it, and then closes the corresponding dialog
             * @name   encollab.dp.wty.Detail#_onExtensionChange
             * @param {string} id
             * @param {string} value 
             * @method
             */
            _onExtensionChange: function(id, value) {
                var path = this.getView().byId(id).getBindingContext('wty').getPath();
                var current = $.extend({}, this.getModel('wty').getProperty(path));
                delete current.__metadata;
                current.Value = value;
                this._updateEntity(path, current);

                this._oDialog.close();
            },
            /**
             * Update entity on qualifier dialog confirmation
             * @name   encollab.dp.wty.Detail#onQualDialogConfirm
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onQualDialogConfirm: function(oEvent) {
                var oModel = this.getModel('wty');
                var oSelect = this._findElementIn('idQualSelect', this._oDialog.findElements(true));
                var oPath = oEvent.getSource().getBindingContext('wty').getPath();

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._updateEntity(oPath, {
                    'Value': oEvent.getParameter('selectedItem').getKey()
                });

            },
            /**
             * This method is triggered when opening the repair date dialog. It fetches and parses the current repair dates to display to the user.
             * @name   encollab.dp.wty.Detail#onRepairPress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onRepairPress: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.repDateDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.myView.addDependent(this._oDialog);
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                var oDateRange = this._findElementIn('repDateRanger', this._oDialog.findElements(true));

                var repDate = this.getModel('wty').getProperty("/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACS_REPDATE')").Value;
                var repEndDate = this.getModel('wty').getProperty("/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACS_REPENDDATE')").Value;
                var oRepDate = new Date(repDate.substr(0, 4), repDate.substr(4, 2) - 1, repDate.substr(6, 2));
                var oRepEndDate = new Date(repEndDate.substr(0, 4), repEndDate.substr(4, 2) - 1, repEndDate.substr(6, 2));

                oDateRange.setDateValue(oRepDate).setSecondDateValue(oRepEndDate);
                // dateValue="{path:'newClaim>/RepairFrom/Value'}"
                // secondDateValue="{path:'newClaim>/RepairTo/Value'}"


                this._oDialog.open();

            },
            /**
             * Update entity on repair date dialog confirmation
             * @name   encollab.dp.wty.Detail#onRepDateDialogConfirm
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onRepDateDialogConfirm: function(oEvent) {
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                var oDateRange = this._findElementIn('repDateRanger', this._oDialog.findElements(true));

                var oPath1 = "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACS_REPDATE')";
                var oPayload1 = {
                    'Value': this.accountForUTCDate(oDateRange.getDateValue()).toISOString().replaceAll('-', '').substr(0, 8)
                };
                var oPath2 = "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACS_REPENDDATE')";
                var oPayload2 = {
                    'Value': this.accountForUTCDate(oDateRange.getSecondDateValue()).toISOString().replaceAll('-', '').substr(0, 8)
                };

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._updateEntity(oPath1, oPayload1,
                    function() {
                        this._updateEntity(oPath2, oPayload2);
                    }
                );

            },
            /**
             * Opens the PFP deletion dialog
             * @name   encollab.dp.wty.Detail#onPFPPress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onPFPPress: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.deletePFPDialog", this);
                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            /**
             * Updates the claim when the PFP changes
             * @name   encollab.dp.wty.Detail#onChangePFPSelect
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onChangePFPSelect: function(oEvent) {
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                var oPath = "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACSWYAD_DEFPART')";

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._updateEntity(oPath, {
                    'Value': ''
                });
            },
            /**
             * Updates the claim to delete the PFP
             * @name   encollab.dp.wty.Detail#onDeletePFPConfirm
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onDeletePFPConfirm: function(oEvent) {
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                var oPath = "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACSWYAD_DEFPART')";

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._updateEntity(oPath, {
                    'Value': oEvent.getParameter('listItem') ? oEvent.getParameter('listItem').getTitle() : ''
                });
            },
            /**
             * Opens the MOPE dialog
             * @name   encollab.dp.wty.Detail#onMOPEPress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onMOPEPress: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.deleteMOPEDialog", this);
                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            /**
             * On MOPE delete, Updates the entity to delete the MOPE, Trouble Code and Defect Code
             * @name   encollab.dp.wty.Detail#onDeleteMOPEConfirm
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onDeleteMOPEConfirm: function(oEvent) {
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._updateEntity("/WarrantyClaims('" + claimNo + "')", {
                    ZZMOPE: '',
                    ZZTROUBLE_CODE: '',
                    ZACSWYAD_DEFCT: ''
                });
            },
            /**
             * This updates the claim by updating the MOPE
             * @name   encollab.dp.wty.Detail#onChangeMOPESelect
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onChangeMOPESelect: function(oEvent) {
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                var oPath = "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZMOPE')";

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._updateEntity(oPath, {
                    'Value': oEvent.getParameter('listItem') ? oEvent.getParameter('listItem').getTitle() : ''
                });

            },
            /**
             * Opens the Change Symptom dialog
             * @name   encollab.dp.wty.Detail#onSymptomPress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onSymptomPress: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.changeSymptomDialog", this);
                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            /**
             * Fetches Symptom codes from SAP based on the user filter
             * @name   encollab.dp.wty.Detail#onSymptomPress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onSymptomSearch: function(oEvent) {
                var oList = this._findElementIn('changeSymptomList', this._oDialog.findElements(true));
                var filters = [];
                var searchString = oEvent.getSource().getValue();

                if (searchString && searchString.length > 0) {
                    filters = [
                        new Filter("Name", FilterOperator.Contains, searchString.toUpperCase()),
                        new Filter("Value", FilterOperator.Contains, searchString.toUpperCase())
                    ];
                    oList.bindItems({
                        model: 'wty',
                        path: this.getView().getBindingContext('wty').getPath() + "/Symptoms",
                        template: sap.ui.xmlfragment("encollab.dp.wty.changeSymptomTemplate"),
                        filters: [
                            new Filter(filters, false)
                        ]
                    });
                }
            },
            /**
             * @name   encollab.dp.wty.Detail#onSymptomSelect
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onSymptomSelect: function(oEvent) {
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                var oPath = "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACSWYAD_DEFCT')";

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._updateEntity(oPath, {
                    'Value': oEvent.getParameter('listItem').getTitle()
                });
            },
            /**
             * @name   encollab.dp.wty.Detail#onTroublePress
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onTroublePress: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.changeTroubleDialog", this);
                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            /**
             * @name   encollab.dp.wty.Detail#onTroubleSearch
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onTroubleSearch: function(oEvent) {
                var oList = this._findElementIn('changeTroubleList', this._oDialog.findElements(true));
                var filters = [];
                var searchString = oEvent.getSource().getValue();

                if (searchString && searchString.length > 0) {
                    filters = [
                        new Filter("Name", FilterOperator.Contains, searchString.toUpperCase()),
                        new Filter("Value", FilterOperator.Contains, searchString.toUpperCase())
                    ];
                    oList.bindItems({
                        model: 'wty',
                        path: this.getView().getBindingContext('wty').getPath() + "/Troubles",
                        template: sap.ui.xmlfragment("encollab.dp.wty.changeSymptomTemplate"),
                        filters: [
                            new Filter(filters, false)
                        ]
                    });
                }

            },
            /**
             * @name   encollab.dp.wty.Detail#onTroubleSelect
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onTroubleSelect: function(oEvent) {
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                var oPath = "/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZTROUBLE_CODE')";

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._updateEntity(oPath, {
                    'Value': oEvent.getParameter('listItem').getTitle()
                });
            },
            /**
             * @name   encollab.dp.wty.Detail#onItemReturn
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onItemReturn: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.partReturnDialog", this);

                this._oDialog.bindElement({
                    model: 'wty',
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });

                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            /**
             * @name   encollab.dp.wty.Detail#onPartReturnDialogConfirm
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onPartReturnDialogConfirm: function(oEvent) {
                var sPath = oEvent.getSource().getBindingContext('wty').getPath();

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._performUpdate(sPath, {
                    'ReturnPartStatus': 'B'
                });
            },
            /**
             * Updates the whatever on the Warranty service with the payload provided. Success and Error callbacks are optional
             * @name   encollab.dp.wty.Detail#_updateEntity
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            _updateEntity: function(path, payload, success, error) {
                if (!success) {
                    success = function(odata, response) {
                        this.getModel('wty').refresh();
                        this.busyDialog.close();
                    };
                }
                if (!error) {
                    error = function(oError) {
                        this.busyDialog.close();
                        this.gatewayError(oError);
                    };
                }
                this.resetMessagePopover();
                this.getModel('wty').update(path, payload, {
                    merge: true,
                    success: success.bind(this),
                    error: error.bind(this)
                });
            },
            _checkDataComplete: function() {
                var allOk = true;
                allOk = this._checkItems() && this._checkTexts();
                this.getModel('viewModel').setProperty('/isReadyToSubmit', allOk);
                return allOk;
            },
            _checkItems: function() {
                // if (this._vehicleClaim) {
                //     var causalPart = false;
                //     var causalLabour = false;
                //     for (var i = 0, oWtyItem, aItems = this.getView().byId('wtyItems').getItems(); i < aItems.length; i++) {
                //         oWtyItem = aItems[i].getBindingContext('wty').getObject();
                //         if (oWtyItem) {
                //             if (oWtyItem.CausalPart) {
                //                 if (this._checkCausalPart(oWtyItem)) {
                //                     causalPart = true;
                //                 }
                //                 if (this._checkCausalLabour(oWtyItem)) {
                //                     causalLabour = true;
                //                 }
                //             }
                //         }
                //     }
                //     if (this.getView().getBindingContext('wty').getObject().DirectSwap) causalPart = true;
                //     return causalPart && causalLabour;
                // } else {
                return this.getView().byId('wtyItems').getItems().length > 0;
                //}
            },
            _checkCausalPart: function(wtyItem) {
                if (wtyItem.ItemType === 'MAT') {
                    if (wtyItem.CausalPart) {
                        return true;
                    }
                }
                // Direct Swap Parts
                // Same interesting thinking at NMI means there can be causal parts not in the items
                // These parts have ' DP' appended to their description
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;
                var oCausalPart = this.getModel('wty').getProperty("/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACSWYAD_DEFPART')");
                return oCausalPart.ValueDescription.substr(oCausalPart.ValueDescription.length - 3) === ' DP';
            },
            _checkCausalLabour: function(wtyItem) {
                return wtyItem.ItemType === 'FR' ? wtyItem.CausalPart : false;
            },
            _checkTexts: function() {
                var allOk = true;

                if (this._vehicleClaim) {
                    var oListItems = this.getView().byId('idWtyTextsList').getItems();
                    for (var i = 0; i < oListItems.length; i++) {
                        if (oListItems[i].getContent()[1].getValue().length < 1) {
                            allOk = false;
                        }
                    }
                }
                var oTabFilter = this.getView().byId('iconTabTexts');
                if (allOk) {
                    oTabFilter.setIconColor(sap.ui.core.IconColor.Default);
                } else {
                    oTabFilter.setIconColor(sap.ui.core.IconColor.Critical);
                }

                return allOk;
            },
            /**
             * @name   encollab.dp.wty.Detail#itemTypeFormatter
             * @param {string} itemType
             * @param {causal} causal
             * @return {string}
             * @method
             */
            itemTypeFormatter: function(itemType, causal) {
                return causal ? this.getText('causal' + itemType) : this.getText('itemText' + itemType);
            },
            /**
             * @name   encollab.dp.wty.Detail#onItemReturn
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            fireDetailChanged: function(sWtyPath) {
                this.getView().setBusy(false);
            },
            fireDetailNotFound: function() {},
            /**
             * @name   encollab.dp.wty.Detail#onItemReturn
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onUpdateFinished: function(oEvent) {
                this.getView().setBusy(false);

                var causalPart = false;
                var causalLabour = false;

                for (var i = 0, oWtyItem, aItems = oEvent.getSource().getItems(); i < aItems.length; i++) {
                    oWtyItem = aItems[i].getBindingContext('wty').getObject();
                    if (this._checkCausalPart(oWtyItem)) {
                        causalPart = true;
                    }
                    if (this._checkCausalLabour(oWtyItem)) {
                        causalLabour = true;
                    }
                }

                if (!this.isChangeable()) return;
                // No Causal Part Found
                // if (!causalPart) {
                //     this.addCausalPart(oEvent);
                // } else {
                //     if (!causalLabour) {
                //         //this.onItemAddFlatRate(oEvent);
                //         this.addCausalLabour(oEvent);
                //     }
                // }
            },
            onExit: function() {
                if (this._oPopover) {
                    this._oPopover.destroy();
                }
            },
            _getHeaderPopover: function() {
                if (!this._oPopover) {
                    this._oPopover = sap.ui.xmlfragment("encollab.dp.wty.headerChangePopover", this);
                }
                return this._oPopover;
            },
            handlePopoverConfirmButton: function(oEvent) {
                var aElements = this._oPopover.findElements(true);
                var oElement;
                var oPayload = {};
                this._addPayloadElement(oPayload, 'ReferenceDate');
                this._addPayloadElement(oPayload, 'ReferenceNo');
                // this._addPayloadElement(oPayload, 'Mileage');
                // this._addPayloadElement(oPayload, 'MileageUOM');
                // this._addPayloadElement(oPayload, 'SymptomCode');
                // this._addPayloadElement(oPayload, 'TroubleCode');
                // if (this.partsInvoiceDateVisible(this.getView().getBindingContext('wty').getObject().ClaimType)) {
                //     this._addPayloadElement(oPayload, 'PartsInvoiceDate');
                // }
                // this._addPayloadElement(oPayload, 'ClaimSubmissonDate');
                // this._addPayloadElement(oPayload, 'ClaimCategoryCode');
                // this._addPayloadElement(oPayload, 'LocationGridCode');
                // this._addPayloadElement(oPayload, 'DiagnosisTroubleCode');

                this._oPopover.close();
                this._performUpdate(oEvent.getSource().getBindingContext('wty').getPath(), oPayload);
            },
            hasCausalPartFormatter: function(PFP) {
                var causalPart = false;
                for (var i = 0, oWtyItem, aItems = this.getView().byId('wtyItems').getItems(); i < aItems.length; i++) {
                    oWtyItem = aItems[i].getBindingContext('wty').getObject();
                    if (oWtyItem) {
                        if (oWtyItem.CausalPart) {
                            if (this._checkCausalPart(oWtyItem)) {
                                causalPart = true;
                            }
                        }
                    }
                }
                return causalPart;
            },
            _addPayloadElement: function(oPayload, sElement) {
                var sId = 'id' + sElement; //sElement.charAt(0).toLowerCase() + sElement.slice(1);
                var oId = this._findElementIn(sId, this._oPopover.findElements(true));

                if (oId) {
                    try {
                        oPayload[sElement] = this.formatter.TZOffsetDate(oId.getDateValue());
                    } catch (err1) {
                        try {
                            oPayload[sElement] = oId.getSelectedKey();
                        } catch (err2) {
                            oPayload[sElement] = oId.getValue();
                        }
                    }
                }
            },
            handlePopoverCancelButton: function(oEvent) {
                this._oPopover.close();
            },
            onVINPressed: function(oEvent) {
                this.getRouter().navTo("vindetail", {
                    vehiclePath: this.getView().getBindingContext('wty').getProperty("VIN") //getPath().substr(1)
                });

            },
            onTitleSelectorPress: function(oEvent) {
                var _oPopover = this._getHeaderPopover();
                this.getView().addDependent(_oPopover);
                _oPopover.openBy(oEvent.getParameter("domRef"));
                _oPopover.setModel(oEvent.getSource().getModel());
            },
            checkKms: function(oEvent) {
                var oSource = oEvent.getSource();
                var isInt = this.formatter.isInteger(oSource.getValue());
                oSource.setValueState(isInt ? 'None' : 'Error');
            },
            /**
             * This method is called to update the text fields on the claim
             * @name   encollab.dp.wty.Detail#onTextFieldChange
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onTextFieldChange: function(oEvent) {
                var oTextField = oEvent.getSource();
                oTextField.setValueState('Warning');
                var oData = oTextField.getBindingContext('wty').getObject();
                //oTextField.setEnabled(false);
                this._performUpdate(
                    oTextField.getBindingContext('wty').getPath(), {
                        Text: oTextField.getValue()
                    },
                    function() {
                        this.isReadyToSubmit('X');
                        oTextField.setValueState('None');
                    }.bind(this),
                    null,
                    true
                );
            },
            onTextsUpdated: function(oEvent) {
                this.isReadyToSubmit();
            },
            onTextFieldChange_new: function(oEvent) {
                var oTextField = oEvent.getSource();
                var sElement = oTextField.getId().split('--')[1];

                this.mainModel.setProperty(this.getView().getBindingContext().getPath() + '/' + sElement.charAt(0).toUpperCase() + sElement.slice(1), oEvent.getSource().getValue());
                this.getView().byId('saveTextsButton').setEnabled(true).setType('Reject');
            },
            onSaveTexts: function(oEvent) {
                this.getView().setBusy(true);

                this.mainModel.submitChanges({
                    success: jQuery.proxy(this._submitChangesSuccess, this),
                    error: function(oError) {
                        this.busyDialog.close();
                        this.gatewayError(oError);
                    }.bind(this)
                });
            },
            onItemPress: function(oEvent) {
                var partId = oEvent.getSource().getBindingContext('wty').getObject().MaterialId;
                if (partId) {
                    this.myRouter.navTo("partsdetail", {
                        partPath: partId
                    });
                }
            },
            materialPopoverGo: function(oEvent) {
                this.materialPopoverClose();
                var oItem = oEvent.getSource();
                if (oItem) {
                    this.myRouter.navTo("partsdetail", {
                        materialPath: oItem.getBindingContext('wty').getPath().substr(1)
                    });
                }
            },
            materialPopoverClose: function(oEvent) {
                this._oMaterialPopover.close();
            },
            onItemAdd: function(oEvent) {
                var oButton = oEvent.getSource();
                // create action sheet only once
                if (!this._actionSheet) {
                    this._actionSheet = sap.ui.xmlfragment(
                        "encollab.dp.wty.addItemActionSheet",
                        this
                    );
                    this.getView().addDependent(this._actionSheet);
                }
                this._actionSheet.openBy(oButton);
            },
            onDialogCancel: function(oEvent) {
                try {
                    this._oDialog.close().destroy();
                } catch (err) {}
            },
            addCausalPart: function(oEvent) {
                this.onDialogCancel(oEvent);
                var oContext = this.getView().getBindingContext('wty');
                var oData = oContext.getObject();
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.addCausalPartDialog", this);
                this._oDialog.bindElement({
                    path: oContext.getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            addCausalLabour: function(oEvent) {
                this.onDialogCancel(oEvent);
                if (!this._vehicleClaim) return;

                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.addCausalLabourDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            onItemAddMaterial: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.addMaterialDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            onAddCausalSearch: function(oEvent) {
                var oList = this._findElementIn('addCausalList', this._oDialog.findElements(true));
                var filters = [];
                var searchString = oEvent.getSource().getValue();

                if (searchString && searchString.length > 0) {
                    filters = [
                        new Filter("Id", FilterOperator.Contains, searchString.toUpperCase()),
                        new Filter("Description", FilterOperator.Contains, searchString.toUpperCase())
                    ];
                    oList.bindItems({
                        model: 'wty',
                        path: this.getView().getBindingContext('wty').getPath() + "/CausalParts",
                        template: sap.ui.xmlfragment("encollab.dp.wty.addCausalTemplate"),
                        filters: [
                            //new Filter("Salesorg", FilterOperator.EQ, this.myComponent.getMySettingValue('VKO')),
                            new Filter(filters, false)
                        ]
                    });
                }
            },
            onAddCausalLabourSearch: function(oEvent) {
                var oList = this._findElementIn('addCausalLabourList', this._oDialog.findElements(true));
                var filters = [];
                var searchString = oEvent.getSource().getValue();

                if (searchString && searchString.length > 0) {
                    filters = [
                        new Filter("Id", FilterOperator.Contains, searchString.toUpperCase()),
                        new Filter("Description", FilterOperator.Contains, searchString.toUpperCase())
                    ];
                    oList.bindItems({
                        model: 'wty',
                        path: this.getView().getBindingContext('wty').getPath() + "/Flatrates",
                        template: sap.ui.xmlfragment("encollab.dp.wty.addCausalTemplate"),
                        filters: [
                            //new Filter("Salesorg", FilterOperator.EQ, this.myComponent.getMySettingValue('VKO')),
                            new Filter(filters, false)
                        ]
                    });
                }
            },
            // onAddMaterialSearch: function(oEvent) {
            //     var oList = this._findElementIn('addMaterialList', this._oDialog.findElements(true));
            //     var filters = [];
            //     var searchString = oEvent.getSource().getValue();

            //     if (searchString && searchString.length > 3) {
            //         filters = [
            //             new Filter("PartDesc", FilterOperator.Contains, searchString.toUpperCase()),
            //             new Filter("PartID", FilterOperator.Contains, searchString.toUpperCase())
            //         ];
            //         oList.bindItems({
            //             path: "part>/Parts",
            //             parameters: {
            //                 select: "PartID,PartDesc"
            //             },
            //             template: sap.ui.xmlfragment("encollab.dp.wty.addMaterialTemplate"),
            //             filters: [
            //                 //new Filter("Salesorg", FilterOperator.EQ, this.myComponent.getMySettingValue('VKO')),
            //                 new Filter(filters, false)
            //             ]
            //         });
            //     }
            // },

            /**
             * This is the method that calls SAP when the user searches for Causal Parts
             * @name   encollab.dp.wty.Detail#onAddMaterialSearch
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAddMaterialSearch: function(oEvent) {
                var oList = this._findElementIn('addMaterialList', this._oDialog.findElements(true));
                var filters = [];
                var searchString = oEvent.getSource().getValue();

                if (searchString && searchString.length > 0) {
                    filters = [
                        new Filter("Id", FilterOperator.Contains, searchString.toUpperCase()),
                        new Filter("Description", FilterOperator.Contains, searchString.toUpperCase())
                    ];
                    oList.bindItems({
                        model: 'wty',
                        path: this.getView().getBindingContext('wty').getPath() + "/CausalParts",
                        template: sap.ui.xmlfragment("encollab.dp.wty.addCausalTemplate"),
                        filters: [
                            //new Filter("Salesorg", FilterOperator.EQ, this.myComponent.getMySettingValue('VKO')),
                            new Filter(filters, false)
                        ]
                    });
                }
            },
            /**
             * This is the method that calls SAP when the user searches for Sundry items
             * @name   encollab.dp.wty.Detail#onAddSundrySearch
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAddSundrySearch: function(oEvent) {
                var oList = this._findElementIn('addMaterialList', this._oDialog.findElements(true));
                var filters = [];
                var searchString = oEvent.getSource().getValue();

                if (searchString && searchString.length > 0) {
                    filters = [
                        new Filter("MaterialDescUpper", FilterOperator.Contains, searchString.toUpperCase()),
                        new Filter("MaterialNr", FilterOperator.Contains, searchString.toUpperCase())
                    ];
                    oList.bindItems({
                        path: "/Materials",
                        parameters: {
                            select: "MaterialNr,MatlDesc"
                        },
                        template: sap.ui.xmlfragment("encollab.dp.common.addMaterialTemplate"),
                        filters: [
                            new Filter("SalesOrg", FilterOperator.EQ, this.myComponent.getMySettingValue('VKO')),
                            new Filter("MatlType", FilterOperator.EQ, 'NLAG'),
                            new Filter(filters, false)
                        ]
                    });
                }
            },
            /**
             * This is the method calls SAP and creates the causal part on the claim
             * @name   encollab.dp.wty.Detail#onAddCausalSelect
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAddCausalSelect: function(oEvent) {
                // get texts
                var successMsg = this.getText("addCausalDialogSuccessMsg");

                var OClaim = this.getView().getBindingContext('wty').getObject();
                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                var MaterialId = oEvent.getParameter('listItem').getBindingContext('wty').getObject().Id;

                var mPayload = {
                    ClaimNo: OClaim.ClaimNo,
                    MaterialId: MaterialId,
                    CausalPart: true,
                    ItemType: 'MAT',
                    Quantity: '1',
                    UoM: 'EA'
                };
                this._createItem(mPayload, successMsg);
            },
            /**
             * This is the method calls SAP and creates the MOPE on the claim
             * @name   encollab.dp.wty.Detail#onAddCausalSelect
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onMOPESelected: function(oEvent) {
                // get texts
                var successMsg = this.getText("addCausalLabourDialogSuccessMsg");

                var OClaim = this.getView().getBindingContext('wty').getObject();
                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                var mPayload = {
                    ClaimNo: OClaim.ClaimNo,
                    MaterialId: oEvent.getParameter('listItem').getBindingContext('wty').getObject().Id,
                    CausalPart: true,
                    ItemType: 'FR'
                        // Quantity: '0.25',
                        // UoM: 'H'
                };
                this._createItem(mPayload, successMsg);
            },
            onAddMaterialSelect: function(oEvent) {
                var oListItem;
                if (oEvent.sId === 'updateFinished') {
                    if (oEvent.getSource().getItems().length === 1) {
                        oListItem = oEvent.getSource().getItems()[0];
                    } else {
                        return;
                    }
                } else {
                    oListItem = oEvent.getSource().getSelectedItem();
                }
                // get texts
                var successMsg = this.getText("addMaterialDialogSuccessMsg");

                var oClaim = this.getView().getBindingContext('wty').getObject();
                var oPart = oListItem.getBindingContext('wty').getObject();

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                var mPayload = {
                    ClaimNo: oClaim.ClaimNo,
                    MaterialId: oPart.Id,
                    ItemType: 'MAT',
                    Quantity: '1',
                    UoM: 'EA'
                };
                this._createItem(mPayload, successMsg);
            },
            onItemAddSundry: function(oEvent) {
                MessageToast.show('Not implemented');
                return;
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.addSundryDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();

            },
            onAddSundrySelect: function(oEvent) {
                var oListItem;
                if (oEvent.sId === 'updateFinished') {
                    if (oEvent.getSource().getItems().length === 1) {
                        oListItem = oEvent.getSource().getItems()[0];
                    } else {
                        return;
                    }
                } else {
                    oListItem = oEvent.getParameter('listItem');
                }

                // get texts
                var successMsg = this.getText("addMaterialDialogSuccessMsg");

                var oOrder = this.getView().getBindingContext('wty').getObject();
                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                var mPayload = {
                    VersionGUID: oOrder.ICVersionGUID,
                    Material: oListItem.getDescription(),
                    ItemType: 'ZSUN',
                    Qty: '1',
                    UoM: 'EA'
                };

                var funcCallback = jQuery.proxy(function(odata, response) {
                    this.busyDialog.close();
                    var itemPath = "/WtyItems(guid'" + odata.ItemGUID + "')";
                    this._changeItemQtyDialog(itemPath);
                    //TODO waiting for details on how to code a sundry item
                    this.warningMessage('Sundry Incomplete', 'The code for adding sundry items is not yet complete');
                }, this);

                this._createItem(mPayload, successMsg, funcCallback);
            },
            _createItem: function(mPayload, successMsg, successCallback) {
                if (!successCallback) {
                    successCallback = jQuery.proxy(function(odata, response) {
                        this.busyDialog.close();
                        this.getModel('wty').refresh();
                        MessageToast.show(successMsg || 'Success');
                    }, this);
                }
                this.resetMessagePopover();

                this.getModel('wty').create("/WarrantyItems", mPayload, {
                    success: successCallback,
                    error: jQuery.proxy(function(oError) {
                        this.busyDialog.close();
                        this.gatewayError(oError);
                    }, this)
                });
            },
            onItemAddFlatRate: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.addFlatrateDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);

                this._oDialog.open();
            },
            onFlatRateSelect: function(oEvent) {
                // get texts
                var successMsg = this.getText("addCausalLabourDialogSuccessMsg");

                var OClaim = this.getView().getBindingContext('wty').getObject();
                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                var mPayload = {
                    ClaimNo: OClaim.ClaimNo,
                    MaterialId: oEvent.getParameter('selectedItem').getKey(),
                    CausalPart: false,
                    ItemType: 'FR'
                };
                this._createItem(mPayload, successMsg);

            },
            onAddFlatrateSearch: function(oEvent) {
                var oList = this._findElementIn('addFlatrateList', this._oDialog.findElements(true));
                var filters = [];
                var searchString = oEvent.getSource().getValue();

                if (searchString && searchString.length > 0) {
                    filters = [
                        new Filter("Description", FilterOperator.Contains, searchString.toUpperCase())
                    ];
                    oList.bindItems({
                        path: "wty>Flatrates",
                        template: sap.ui.xmlfragment("encollab.dp.wty.addFlatrateTemplate"),
                        filters: [
                            //new Filter("Salesorg", FilterOperator.EQ, this.myComponent.getMySettingValue('VKO')),
                            new Filter(filters, false)
                        ]
                    });
                }
            },
            onAddFlatrateSelect: function(oEvent) {
                var oListItem;
                if (oEvent.sId === 'updateFinished') {
                    if (oEvent.getSource().getItems().length === 1) {
                        oListItem = oEvent.getSource().getItems()[0];
                    } else {
                        return;
                    }
                } else {
                    oListItem = oEvent.getSource().getSelectedItem();
                }
                // get texts
                var successMsg = this.getText("addCausalLabourDialogSuccessMsg");

                var oClaim = this.getView().getBindingContext('wty').getObject();
                var oFlatrate = oListItem.getBindingContext('wty').getObject();

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                var mPayload = {
                    ClaimNo: oClaim.ClaimNo,
                    MaterialId: oFlatrate.Id,
                    ItemType: 'FR'
                };
                this._createItem(mPayload, successMsg);
            },
            onItemAddSublet: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.addSubletDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                //this.onSubletFieldChange();
                this._oDialog.open();
            },
            onAddSubletSelect: function(oEvent) {
                // get texts
                var successMsg = this.getText("addSubletDialogSuccessMsg");

                var OClaim = this.getView().getBindingContext('wty').getObject();
                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                var mPayload = {
                    ClaimNo: OClaim.ClaimNo,
                    MaterialId: oEvent.getParameter('selectedItem').getKey(),
                    CausalPart: false,
                    ItemType: 'SUBL',
                    Quantity: '1',
                    UoM: 'EA'
                };
                this._createItem(mPayload, successMsg);
            },
            /**
             * This method tests the sublet fields and checks if they are OK nor not
             * @name   encollab.dp.wty.Detail#onAddCausalSelect
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onSubletFieldChange: function(oEvent) {
                var allOk = true;
                var oElements = this._oDialog.findElements(true);
                var oSubletDesc = this._findElementIn('subletDesc', oElements);
                var oSubletQty = this._findElementIn('subletQty', oElements);
                var oSubletValue = this._findElementIn('subletValue', oElements);
                var oSubletUploader = this._findElementIn('subletUploader', oElements);

                if (oSubletDesc.getValue().length > 0) {
                    oSubletDesc.setValueState("Success");
                } else {
                    oSubletDesc.setValueState("Error");
                    allOk = false;
                }
                if (oSubletQty.getValue().length > 0 && !isNaN(oSubletQty.getValue())) {
                    oSubletQty.setValueState("Success");
                } else {
                    oSubletQty.setValueState("Error");
                    allOk = false;
                }
                if (oSubletValue.getValue().length > 0) {
                    oSubletValue.setValueState("Success");
                } else {
                    oSubletValue.setValueState("Error");
                    allOk = false;
                }
                if (oSubletUploader.getValue().length > 0) {
                    oSubletUploader.setValueState("Success");
                } else {
                    oSubletUploader.setValueState("Error");
                    allOk = false;
                }
                this._findElementIn('subletConfirmButton', this._oDialog.getButtons()).setEnabled(allOk);

            },
            /**
             * This is the method that calls SAP and creates the Sublet on the claim
             * @name   encollab.dp.wty.Detail#onSubletConfirm
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onSubletConfirm: function(oEvent) {
                // get texts
                var successMsg = this.getText("addSubletDialogSuccessMsg");

                var oElements = this._oDialog.findElements(true);
                var oSubletDesc = this._findElementIn('subletDesc', oElements);
                var oSubletQty = this._findElementIn('subletQty', oElements);
                var oSubletValue = this._findElementIn('subletValue', oElements);
                var oOrder = this.getView().getBindingContext('wty').getObject();

                //this._oDialog.close();
                this.busyDialog.open();

                var mPayload = {
                    VersionGUID: oOrder.ICVersionGUID,
                    ClaimItemShortText: oSubletDesc.getValue(),
                    ItemType: 'SUBL',
                    Qty: oSubletQty.getValue(),
                    UoM: 'EA',
                    ValueIC: oSubletValue.getValue()
                };
                this._createItem(mPayload, successMsg, jQuery.proxy(this.uploadSubletAttachment, this));

            },

            /**
             * This is the method that calls SAP and creates an attachment
             * @name   encollab.dp.wty.Detail#uploadSubletAttachment
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            uploadSubletAttachment: function(odata, response) {
                var oElements = this._oDialog.findElements(true);
                var oSubletDesc = this._findElementIn('subletDesc', oElements);
                var oSubletUploader = this._findElementIn('subletUploader', oElements);

                var sSlug = oSubletUploader.getValue() + '|' + oSubletDesc.getValue();

                oSubletUploader.setUploadUrl("/sap/opu/odata/sap/YDP_SRV/WtyItems(guid'" + odata.ItemGUID + "')/WtyItemAttachments");
                oSubletUploader.addHeaderParameter(new FileUploaderParameter({
                    name: 'Slug',
                    value: sSlug
                }));

                this.getModel('wty').refreshSecurityToken(
                    jQuery.proxy(function(oUploader) {
                        var csrf = this.getModel('wty').getSecurityToken();
                        oUploader.addHeaderParameter(new FileUploaderParameter({
                            name: 'x-csrf-token',
                            value: csrf
                        }));
                        oUploader.upload();
                    }, this, oSubletUploader));

            },
            handleSubletUploadComplete: function(oEvent) {
                this.onDialogCancel(oEvent);
                this.getModel('wty').refresh();
                this.busyDialog.close();
            },
            /**
             * @name   encollab.dp.wty.Detail#onItemDelete
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onItemDelete: function(oEvent) {
                var oData = oEvent.getSource().getBindingContext('wty').getObject();
                // if (oData.CausalPart) {
                //     MessageToast.show(this.getText('causalCantRemove'));
                // } else {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.itemDeleteDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
                // }
            },
            /**
             * @name   encollab.dp.wty.Detail#onDeleteDialogConfirm
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onDeleteDialogConfirm: function(oEvent) {
                // get texts
                var successMsg = this.getText("wtyDetailDeleteItemDialogSuccessMsg");

                var sPath = oEvent.getSource().getBindingContext('wty').getPath();
                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this.getModel('wty').remove(sPath, {
                    success: jQuery.proxy(function(odata, response) {
                        this.busyDialog.close();
                        MessageToast.show(successMsg);
                        this.getModel('wty').refresh();
                    }, this),
                    error: jQuery.proxy(function(oError) {
                        this.busyDialog.close();
                        this.gatewayError(oError);
                    }, this)
                });
            },
            canChangeQty: function(itemType) {
                console.log(itemType + ' ' + this.isChangeable());
                return this.isChangeable();
            },
            /**
             * Opens a dialog based on the unit of measure of the current item. If it's Hours, it opens the hour-change dialog. Otherwise, 
             * it will open a Quantity change dialog
             * @name   encollab.dp.wty.Detail#onChangeItemQty
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onChangeItemQty: function(oEvent) {
                var oContext = oEvent.getSource().getBindingContext('wty');
                // if (oContext.getObject().CausalPart) { // Causal part can only have qty 0 or 1
                //     this._performUpdate(oContext.getPath(), {
                //         'Quantity': oContext.getObject().Quantity === '0.000' ? '1' : '0'
                //     });
                // } else {
                if (oContext.getObject().UoM === 'H') {
                    this._changeItemHoursDialog(oContext.getPath());
                } else {
                    this._changeItemQtyDialog(oContext.getPath());
                }
                // }
            },
            _changeItemQtyDialog: function(path) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.changeQtyDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: path
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            _changeItemHoursDialog: function(path) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.changeHoursDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: path
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            Hours: function(hours) {
                var date = new Date(hours * 3600 * 1000);
                return ('0' + date.getUTCHours()).slice(-2) + ':' +
                    ('0' + date.getUTCMinutes()).slice(-2);
            },
            onQtyLiveChange: function(oEvent) {
                var oConfirm = this._findElementIn('confirmButton', this._oDialog.getButtons());
                if (oEvent.getParameter('newValue') > 0) {
                    oConfirm.setEnabled(true);
                    oEvent.getSource().removeStyleClass('qtyError');
                } else {
                    oConfirm.setEnabled(false);
                    oEvent.getSource().addStyleClass('qtyError');
                }
            },
            onQtyDialogConfirm: function(oEvent) {

                var oInput = this._findElementIn('newQty', this._oDialog.findElements(true));
                var sPath = oEvent.getSource().getBindingContext('wty').getPath();

                this.onDialogCancel(oEvent);
                this._performUpdate(sPath, {
                    'Quantity': oInput.getValue()
                });
            },
            onHoursDialogConfirm: function(oEvent) {
                var oInput = this._findElementIn('newHours', this._oDialog.findElements(true));
                var aHours = oInput.getValue().split(':');
                var hours = Number(parseFloat(parseInt(aHours[0], 10) + parseInt(aHours[1], 10) / 60).toFixed(3));

                this.onDialogCancel(oEvent);
                this._performUpdate(oEvent.getSource().getBindingContext('wty').getPath(), {
                    'Quantity': String(hours)
                });
            },
            onChangeItemValue: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.changeValueDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            onValueLiveChange: function(oEvent) {
                var oConfirm = this._findElementIn('confirmButton', this._oDialog.getButtons());
                if (oEvent.getParameter('newValue') > 0) {
                    oConfirm.setEnabled(true);
                    oEvent.getSource().removeStyleClass('qtyError');
                } else {
                    oConfirm.setEnabled(false);
                    oEvent.getSource().addStyleClass('qtyError');
                }
            },
            onValueDialogConfirm: function(oEvent) {
                var oInput = this._findElementIn('newValue', this._oDialog.findElements(true));
                var sPath = oEvent.getSource().getBindingContext('wty').getPath();

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this._performUpdate(sPath, {
                    'AmountClaimed': oInput.getValue()
                });
            },
            onClaimSubmit: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.claimSubmitDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            onSubmitClaimDialogConfirm: function(oEvent) {
                this._performAction('Z006'); //, this.getText("submitWtyDialogSuccessMsg"));
            },
            onClaimAmend: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.claimAmendDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            onAmendClaimDialogConfirm: function(oEvent) {
                this._performAction('ZRTN', this.getText("amendWtyDialogSuccessMsg"));
            },
            _performAction: function(action, successMsg) {

                this.busyDialog.open();
                this.onDialogCancel();
                this.resetMessagePopover();

                var oClaim = this.getView().getBindingContext('wty').getObject();
                var oParams = {
                    ClaimNo: oClaim.ClaimNo,
                    Action: action
                };

                this.getModel('wty').callFunction("/WarrantyClaimAction", {
                    method: 'POST',
                    urlParameters: oParams,
                    success: $.proxy(function(oData, response) {
                        if (successMsg) {
                            MessageToast.show(successMsg);
                        }
                        this._parseMessages(sap.ui.getCore().getMessageManager().getMessageModel().getData());
                        //  For some reason a model refresh didn't work for the buttons
                        this.getModel('wty').refresh();
                        //this.getModel('wty').updateBindings(true);
                        this.busyDialog.close();

                        //location.reload(); // Last resort
                    }, this),
                    error: $.proxy(function(oError) {
                        this.gatewayError(oError);
                    }, this)
                });
            },
            onClaimCreate: function(oEvent) { // This is creating claim from PWA claim
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.createFromPWADialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);

                var oSelect = this._findElementIn('claimTypeSelect', this._oDialog.findElements(true));

                var oTemplate = new Item({
                    key: "{ClaimType}",
                    text: "{ClaimType}-{ClaimTypeDesc}"
                });
                var oClaim = this.getView().getBindingContext('wty').getObject();
                var oFilters = [];
                oFilters.push(
                    new Filter([
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZCA'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZCC'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZCF'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZEC'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZEX'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZFS'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZGW'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZIC'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZNV'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZPC'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZPD'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZPW'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZSP'),
                        new Filter("ClaimType", FilterOperator.EQ, 'ZZWT')
                    ], false)
                );
                oSelect.bindAggregation('items', {
                    path: "/WtyClaimTypes",
                    template: oTemplate,
                    filters: oFilters
                });
                this._oDialog.open();
            },
            onClaimCreateSelect: function(oEvent) {
                // get texts
                var successMsg = this.getText("submitWtyDialogSuccessMsg");

                var oSelect = this._findElementIn('claimTypeSelect', this._oDialog.findElements(true));
                var oClaim = this.getView().getBindingContext('wty').getObject();
                this.onDialogCancel(oEvent);
                this.resetMessagePopover();

                var oParams = {
                    WtyClaimNumber: oClaim.ClaimNr,
                    WtyClaimType: oSelect.getSelectedKey()
                };

                this.getModel('wty').callFunction("/WtyClaimCopy", {
                    method: 'GET',
                    urlParameters: oParams,
                    success: $.proxy(function(oData, response) {
                        MessageToast.show(successMsg);
                        this.busyDialog.close();
                        this.myRouter.navTo("wtydetail", {
                            wtyPath: "WtyHeaders(guid'" + oData.results[0].GUID + "')"
                        });
                    }, this),
                    failure: $.proxy(function(oError) {
                        this.gatewayError(oError);
                    }, this)
                });
            },

            onClaimDelete: function(oEvent) {
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.claimDeleteDialog", this);
                this._oDialog.bindElement({
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });
                this.getView().addDependent(this._oDialog);
                this._oDialog.open();
            },
            onDeleteOrderDialogConfirm: function(oEvent) {
                // get texts
                var successMsg = this.getText("deleteWtyDialogSuccessMsg");

                this.busyDialog.open();
                this.onDialogCancel();
                this.resetMessagePopover();
                this._performAction('Z007', successMsg);
            },
            /**
             * Callback for upload change. 
             * @name   encollab.dp.wty.Detail#onAttachUploadChange
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAttachUploadChange: function(oEvent) {
                var csrf = this.getModel('wty').getSecurityToken();
                var oUploader = oEvent.getSource();
                var fileName = oEvent.getParameter('files')[0].name;
                oUploader.removeAllHeaderParameters();
                oUploader.insertHeaderParameter(new UploadCollectionParameter({
                    name: 'x-csrf-token',
                    value: csrf
                }));
                oUploader.insertHeaderParameter(new UploadCollectionParameter({
                    name: 'Slug',
                    value: fileName
                }));
            },
            /**
             * Callback for upload delete. 
             * @name   encollab.dp.wty.Detail#onAttachDelete
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAttachDelete: function(oEvent) {
                var sPath = oEvent.getParameter('item').getBindingContext('wty').getPath();
                var oModel = this.getModel('wty');
                this.busyDialog.open();
                this.resetMessagePopover();
                oModel.remove(sPath, {
                    success: jQuery.proxy(function(odata, response) {
                        this.busyDialog.close();
                        oModel.refresh();
                    }, this),
                    error: jQuery.proxy(function(oError) {
                        this.busyDialog.close();
                        this.gatewayError(oError);
                    }, this)
                });
            },
            /**
             * Callback for upload complete. 
             * @name   encollab.dp.wty.Detail#onAttachUploadComplete
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onAttachUploadComplete: function(oEvent) {
                this.resetMessagePopover();
                var mParams = oEvent.getParameter('mParameters');
                if (mParams.status > 299) {
                    this.errorMessage('Status ' + mParams.status, mParams.response);
                } else {
                    this.getModel('wty').refresh();
                }
            },
            headerUrl: function(guid) {
                return guid ?
                    this.getModel('wty').sServiceUrl + this.getView().getBindingContext('wty').getPath() :
                    guid;
            },
            partsInvoiceDateVisible: function(claimType) {
                if (this.myComponent.Customer === 'Inchcape') {
                    var partsClaimTypes = [];
                    partsClaimTypes['ZAUT'] = true;
                    partsClaimTypes['ZZPW'] = true;
                    partsClaimTypes['ZZPC'] = true;

                    return partsClaimTypes[claimType] === true;

                } else {
                    return false;
                }
            },
            onReturnStatus: function(oEvent) {
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.changeDirectSwapDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: this.getView().getBindingContext('wty').getPath()
                });

                this.getModel('wty').read('/ReturnReasons', {
                    success: function(status) {
                        status.results.unshift({
                            Status: '',
                            Description: 'N/A'
                        });

                        this._oDialog.setModel(new JSONModel({
                            ReturnReasons: status.results,
                            selected: this.getModel('wty').getProperty(this.getView().getBindingContext('wty').getPath() + '/DirectSwapStatus')
                        }), 'data');
                        this.myView.addDependent(this._oDialog);
                        this._oDialog.open();
                    }.bind(this)
                });

            },
            /**
             * Callback for upload complete. 
             * @name   encollab.dp.wty.Detail#onAttachUploadComplete
             * @param {sap.ui.core.Event} oEvent
             * @method
             */
            onReturnStatusConfirm: function(oEvent) {
                var val = sap.ui.getCore().byId('idDirectSwapSelect').getSelectedKey();
                var claimNo = this.getView().getBindingContext('wty').getObject().ClaimNo;

                this._performUpdate("/WarrantyClaims('" + claimNo + "')", {
                    ZZMOPE: this.getModel('wty').getProperty("/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZMOPE')/Value"),
                    ZZTROUBLE_CODE: this.getModel('wty').getProperty("/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZZTROUBLE_CODE')/Value"),
                    ZACSWYAD_DEFCT: this.getModel('wty').getProperty("/WarrantyClaimExtensions(ClaimNo='" + claimNo + "',Id='ZACSWYAD_DEFCT')/Value"),
                    DirectSwapFlag: (val === '') ? '' : 'X',
                    DirectSwapStatus: val
                });

                this.onDialogCancel(oEvent);
            },
            onReferencePress: function(oEvent) {
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.changeReferenceDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });

                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            onReferenceChange: function(oEvent) {
                this._performUpdate(oEvent.getSource().getBindingContext('wty').getPath(), {
                    ReferenceNo: sap.ui.getCore().byId('newReference').getValue()
                });

                this.onDialogCancel(oEvent);
            },
            onReferenceDatePress: function(oEvent) {
                this._oDialog = sap.ui.xmlfragment("encollab.dp.wty.changeReferenceDateDialog", this);
                this._oDialog.bindElement({
                    model: 'wty',
                    path: oEvent.getSource().getBindingContext('wty').getPath()
                });

                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },
            onReferenceDateChange: function(oEvent) {

                this._performUpdate(oEvent.getSource().getBindingContext('wty').getPath(), {
                    ReferenceDate: this.accountForUTCDate(sap.ui.getCore().byId('newReferenceDate').getDateValue())
                });

                this.onDialogCancel(oEvent);
            },
            
            /**
             * Performance an arbitrary update on the WTY model, taking a Path and a Payload
             * @method 
             * @private
             * @name   encollab.dp.wty.Detail#_performUpdate
             * @param  {string} sPath    
             * @param  {string} sPayload 
             * @param  {function} fSuccess 
             * @param  {function} fError   
             * @param  {boolean} noBusy   
             */
            _performUpdate: function(sPath, sPayload, fSuccess, fError, noBusy) {
                this.resetMessagePopover();
                if (!noBusy) this.busyDialog.open();
                if (!fSuccess) {
                    fSuccess = jQuery.proxy(function(odata, response) {
                        this.getModel('wty').refresh();
                        this.busyDialog.close();
                    }, this);
                }
                if (!fError) {
                    fError = jQuery.proxy(function(oError) {
                        this.busyDialog.close();
                        this.gatewayError(oError);
                    }, this);
                }

                this.getModel('wty').update(sPath, sPayload, {
                    merge: true,
                    success: fSuccess,
                    error: fError
                });
            },
            onNavBack: function() {
                Controller.prototype.onNavBack.apply(this, ["wty"]);
            }
        });
    });