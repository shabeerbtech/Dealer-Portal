/*global location */
sap.ui.define([
        "encollab/dp/vin/BaseController",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox"
    ],
    /**
     * <p>Controller for the ATP / Backorder report. It's based on calling the same ABAP classes as deliverable AS036. Please refer
     * to the spec of this development to learn more about the data displayed here.</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Vin</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.vin.Detail.view.xml <small>main view</small></li>
     * </ul>
     * @class Detail
     * @memberOf encollab.dp.vin
     * @extends {encollab.dp.vin.BaseController}
     * @return {encollab.dp.vin.Detail}
     * 
     * @param {encollab.dp.vin.BaseController} Controller   
     * @param {sap.ui.model.json.JSONModel} JSONModel 
     * @param {sap.m.MessageBox} MessageBox       
     */
    function(Controller, JSONModel, MessageBox) {
        "use strict";

        return Controller.extend("encollab.dp.vin.Detail", {
            _userAuthorisations: ['VehicleEnquiry'],
            /**
             * Initialization of the controller. Sets up a new JSON model. 
             * @name   encollab.dp.vin.Detail#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);

                // Model used to manipulate control states. The chosen values make sure,
                // detail page is busy indication immediately so there is no break in
                // between the busy indication for loading the view's meta data
                var oViewModel = new JSONModel({
                    busy: false,
                    delay: 0,
                    configItemListTitle: this.getResourceBundle().getText("vinDetailConfigHeading"),
                    extItemListTitle: this.getResourceBundle().getText("vinDetailExtHeading"),
                    qualItemListTitle: this.getResourceBundle().getText("vinDetailQualHeading"),
                    historyItemListTitle: this.getResourceBundle().getText("vinDetailHistoryHeading"),
                    ClaimItemListTitle: this.getResourceBundle().getText("vinDetailClaimHeading"),
                    SerPgmclaimItemListTitle: this.getResourceBundle().getText("vinDetailContractClaimHeading"),
                    SerPgmItemListTitle: this.getResourceBundle().getText("vinDetailServiceProgramHeading"),
                    RecallItemListTitle: this.getResourceBundle().getText("vinDetailRecallHeading")
                });

                this.getRouter().getRoute("vindetail").attachPatternMatched(this._onObjectMatched, this);

                this.setModel(oViewModel, "detailView");

                this.getModel('vin').metadataLoaded().then(this._onMetadataLoaded.bind(this));

                if (this.myComponent.Customer !== 'Inchcape')
                {
                    //this.getView().byId('serviceIconTabFilter').setVisible(true);
                }

            },

            /* =========================================================== */
            /* event handlers                                              */
            /* =========================================================== */

            /**
             * Updates the item count within the line item table's header
             * @name   encollab.dp.vin.Detail#onConfigUpdateFinished
             * @param {sap.ui.base.Event} oEvent an event containing the total number of items in the list
             * @private
             */
            onConfigUpdateFinished: function(oEvent) {
                var sTitle,
                    iTotalItems = oEvent.getParameter("total"),
                    oViewModel = this.getModel("detailView");

                // only update the counter if the length is final
                if (this.byId("configItemsList").getBinding("items").isLengthFinal()) {
                    if (iTotalItems) {
                        sTitle = this.getResourceBundle().getText("vinDetailConfigHeadingCount", [iTotalItems]);
                    } else {
                        //Display 'Line Items' instead of 'Line items (0)'
                        sTitle = this.getResourceBundle().getText("vinDetailConfigHeading");
                    }
                    oViewModel.setProperty("/configItemListTitle", sTitle);
                }
            },
            /**
             * Called at the end of the Extension update
             * @name   encollab.dp.vin.Detail#onExtUpdateFinished
             * @method
             */
            onExtUpdateFinished: function(oEvent) {
                var sTitle,
                    iTotalItems = oEvent.getParameter("total"),
                    oViewModel = this.getModel("detailView");

                // only update the counter if the length is final
                if (this.byId("extItemsList").getBinding("items").isLengthFinal()) {
                    if (iTotalItems) {
                        sTitle = this.getResourceBundle().getText("vinDetailExtHeadingCount", [iTotalItems]);
                    } else {
                        //Display 'Line Items' instead of 'Line items (0)'
                        sTitle = this.getResourceBundle().getText("vinDetailExtHeading");
                    }
                    oViewModel.setProperty("/extItemListTitle", sTitle);
                }
            },
            /**
             * Called at the end of the qualifier update
             * @name   encollab.dp.vin.Detail#onQualUpdateFinished
             * @method
             */
            onQualUpdateFinished: function(oEvent) {
                var sTitle,
                    iTotalItems = oEvent.getParameter("total"),
                    oViewModel = this.getModel("detailView");

                // only update the counter if the length is final
                if (this.byId("qualItemsList").getBinding("items").isLengthFinal()) {
                    if (iTotalItems) {
                        sTitle = this.getResourceBundle().getText("vinDetailQualHeadingCount", [iTotalItems]);
                    } else {
                        //Display 'Line Items' instead of 'Line items (0)'
                        sTitle = this.getResourceBundle().getText("vinDetailQualHeading");
                    }
                    oViewModel.setProperty("/qualItemListTitle", sTitle);
                }
            },
            /**
             * Called at the end of the history update
             * @name   encollab.dp.vin.Detail#onHistoryUpdateFinished
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onHistoryUpdateFinished: function(oEvent) {
                var sTitle,
                    iTotalItems = oEvent.getParameter("total"),
                    oViewModel = this.getModel("detailView");

                // only update the counter if the length is final
                if (this.byId("historyItemsList").getBinding("items").isLengthFinal()) {
                    if (iTotalItems) {
                        sTitle = this.getResourceBundle().getText("vinDetailHistoryHeadingCount", [iTotalItems]);
                    } else {
                        //Display 'Line Items' instead of 'Line items (0)'
                        sTitle = this.getResourceBundle().getText("vinDetailHistoryHeading");
                    }
                    oViewModel.setProperty("/historyItemListTitle", sTitle);
                }
            },
            /**
             * Called at the end of the history update
             * @name   encollab.dp.vin.Detail#onClaimUpdateFinished
             * @method
             * @param {sap.ui.base.Event} oEvent 
             */
            onClaimUpdateFinished: function(oEvent) {
                var sTitle,
                    iTotalItems = oEvent.getParameter("total"),
                    oViewModel = this.getModel("detailView");

                // only update the counter if the length is final
                if (this.byId("claimItemsList").getBinding("items").isLengthFinal()) {
                    if (iTotalItems) {
                        sTitle = this.getResourceBundle().getText("vinDetailClaimHeadingCount", [iTotalItems]);
                        //this.byId('claimIconTabFilter').setEnabled(true).setCount(iTotalItems);
                    } else {
                        //Display 'Line Items' instead of 'Line items (0)'
                        sTitle = this.getResourceBundle().getText("vinDetailClaimHeading");
                    }
                    this.byId('claimIconTabFilter').setEnabled(iTotalItems !== 0).setCount(iTotalItems);
                    oViewModel.setProperty("/claimItemListTitle", sTitle);
                }
            },
            
            
                 onServicePgmClaimUpdateFinished: function(oEvent) {
                var sTitle,
                    iTotalItems = oEvent.getParameter("total"),
                    oViewModel = this.getModel("detailView");

                // only update the counter if the length is final
                if (this.byId("CtclaimItemsList").getBinding("items").isLengthFinal()) {
                    if (iTotalItems) {
                        sTitle = this.getResourceBundle().getText("vinDetailContractClaimHeadingCount", [iTotalItems]);
                        //this.byId('claimIconTabFilter').setEnabled(true).setCount(iTotalItems);
                    } else {
                        //Display 'Line Items' instead of 'Line items (0)'
                        sTitle = this.getResourceBundle().getText("vinDetailContractClaimHeading");
                    }
                    this.byId('claimctIconTabFilter').setEnabled(iTotalItems !== 0).setCount(iTotalItems);
                    oViewModel.setProperty("/SerPgmclaimItemListTitle", sTitle);
                }
            },
            handleIconTabBarSelect:function() {
            var keytext =  this.getView().byId('iconTabBar').getSelectedKey();
           // var keytext = key.getText();
           var claimbut =  this.getView().byId('creatclaim');
           var serlist = keytext.includes("servicelist");
           var serclaims = keytext.includes("claimctIconTabFilter");
            if(( serlist === true) || (serclaims === true))
            {


                claimbut.setVisible (false);
            }
            else{
            claimbut.setVisible (true);
            }
            },
            
              onServicePgmUpdateFinished: function(oEvent) {
                var sTitle,
                    iTotalItems = oEvent.getParameter("total"),
                    oViewModel = this.getModel("detailView");

                // only update the counter if the length is final
                if (this.byId("servicectlist").getBinding("items").isLengthFinal()) {
                    if (iTotalItems) {
                        sTitle = this.getResourceBundle().getText("vinDetailServiceProgramHeadingCount", [iTotalItems]);
                        //this.byId('claimIconTabFilter').setEnabled(true).setCount(iTotalItems);
                    } else {
                        //Display 'Line Items' instead of 'Line items (0)'
                        sTitle = this.getResourceBundle().getText("vinDetailServiceProgramHeading");
                    }
                    this.byId('servicelist').setEnabled(iTotalItems !== 0).setCount(iTotalItems);
                    oViewModel.setProperty("/SerPgmItemListTitle", sTitle);
                }
            },
            
            
            /**
            /**
             * Called at the end of the history update
             * @name   encollab.dp.vin.Detail#onServiceUpdateFinished
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onServiceUpdateFinished: function(oEvent) {
                var iTotalItems = oEvent.getParameter("total");

                this.byId('serviceIconTabFilter').setEnabled(iTotalItems !== 0).setCount(iTotalItems);
            },
            /**
             * Called at the end of the recall update
             * @name   encollab.dp.vin.Detail#onRecallUpdateFinished
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onRecallUpdateFinished: function(oEvent) {
                var sTitle,
                    iTotalItems = oEvent.getParameter("total"),
                    oViewModel = this.getModel("detailView");

                // only update the counter if the length is final
                if (this.byId("recallItemsList").getBinding("items").isLengthFinal()) {
                    if (iTotalItems) {
                        sTitle = this.getResourceBundle().getText("vinDetailRecallHeadingCount", [iTotalItems]);
                        //this.byId('claimIconTabFilter').setEnabled(true).setCount(iTotalItems);
                    } else {
                        //Display 'Line Items' instead of 'Line items (0)'
                        sTitle = this.getResourceBundle().getText("vinDetailRecallHeading");
                    }
                    var aItems = oEvent.getSource().getItems()
                    this.byId('recallIconTabFilter').setIconColor('Default');
                    for (var i = 0; i < aItems.length; i++) {
                        if (aItems[i].getBindingContext('vin').getObject().ClaimTypeId === 'ZRCL') {
                            this.byId('recallIconTabFilter').setIconColor('Critical');
                        }
                    };
                    this.byId('recallIconTabFilter').setVisible(iTotalItems !== 0).setCount(iTotalItems);
                    oViewModel.setProperty("/recallItemListTitle", sTitle);
                }
            },
            /**
             * Formats an attribute
             * @name   encollab.dp.vin.Detail#vehicleCustomAttrib
             * @param {string} value
             * @param {string} type  
             * @return {string}
             * @method
             */
            vehicleCustomAttrib: function(value, type) {
                switch (type) {
                    case 'Date':
                        return value.substr(6, 2) + '/' + value.substr(4, 2) + '/' + value.substr(0, 4);
                    default:
                        return value;
                }
            },
            /**
             * Checks claim creation authorization
             * @name   encollab.dp.vin.Detail#canCreateClaim
             * @param {string} status
             * @return {boolean}  
             * @method
             */
            canCreateClaim: function(status) {
                return this.isUserAuthorised('WarrantyCreate');
            },
            /**
             * Checks case creation authorization
             * @name   encollab.dp.vin.Detail#canCreateCase
             * @param {string} status
             * @return {boolean}  
             * @method
             */
            canCreateCase: function(status) {
                return this.isUserAuthorised('WarrantyCreate');
            },
            /**
             * Navigates to a claim creation screen when the Create Claim button is checked
             * @name   encollab.dp.vin.Detail#onCreateClaim
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onCreateClaim: function(oEvent) {
                var oItem = oEvent.getSource();
                this.myRouter.navTo("createwty", {
                    vehiclePath: oItem.getBindingContext('vin').getPath().substr(1)
                });
            },
            /**
             * Navigates to the claim creation screen for a particular VIN
             * @name   encollab.dp.vin.Detail#onCreateService
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onCreateService: function(oEvent) {
                var sWtyQual = oEvent.getSource().getBindingContext('vin').getObject().QualifierId;

                var oItem = oEvent.getSource();
                this.myRouter.navTo("createservice", {
                    vehiclePath: this.getView().getBindingContext('vin').getPath().substr(1),
                    qual: sWtyQual
                });
            },
            
            /**Navigates to service contract creation screen for particular VIN
             *  @name   encollab.dp.vin.Detail#onCreateService
             * @param {sap.ui.base.Event} oEvent 
             * @method
             *
             * */
             onPressservice:function(oEvent) {
                var servicepgm = oEvent.getSource().getBindingContext('vin').getObject().ServicePgmID;
                var servicetyp = oEvent.getSource().getBindingContext('vin').getObject().ServiceType;
                var ClaimNo = oEvent.getSource().getBindingContext('vin').getObject().ClaimNo;
                 var vehicle =  this.getView().getBindingContext('vin').getPath().substr(1);
                if ( ClaimNo !== '')
                {
                 this.myRouter.navTo("serctdetail", {
                    serctPath: "Servicects('" + ClaimNo + "')"
                });
                }
                else
                {
                this.myRouter.navTo("createservicepgm", {
                vehiclePath: vehicle,
                   servicepgm: servicepgm,
                   servicetype:servicetyp
                    
                });
                }
             },
            /**
             * Navigates to the Recall creation screen
             * @name   encollab.dp.vin.Detail#onCreateRecall
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onCreateRecall: function(oEvent) {
                var sRecallMaster = oEvent.getSource().getBindingContext('vin').getObject().ClaimId;

                var oItem = oEvent.getSource();
                this.myRouter.navTo("createrecall", {
                    vehiclePath: this.getView().getBindingContext('vin').getPath().substr(1),
                    qual: 'RC',
                    recallMaster: sRecallMaster
                });
            },

            onCreateCase: function(oEvent) {
                // create dialog
                this._oDialog = sap.ui.xmlfragment("encollab.dp.fprs.createCase", this);
                this._oDialog.bindElement({
                    model: 'vin',
                    path: oEvent.getSource().getBindingContext('vin').getPath()
                });
                this.myView.addDependent(this._oDialog);
                this._oDialog.open();
            },

            onCreateCaseConfirm: function(oEvent) {
                var oParams = {
                    VIN: this.getView().getBindingContext('vin').getObject().VIN,
                    Title: this._findElementIn('caseTitle', this._oDialog.findElements(true)).getValue()
                };

                this.onDialogCancel(oEvent);
                this.busyDialog.open();

                this.getView().getModel('fprs').callFunction("/CreateCase", {
                    method: 'POST',
                    urlParameters: oParams,
                    success: $.proxy(function(oData, response) {
                        this.busyDialog.close();
                        this.getRouter().navTo("fprsDetail", {
                            fprsPath: "Cases('" + oData.CaseId + "')"
                        });
                    }, this),
                    error: $.proxy(function(oError) {
                        this.busyDialog.close();
                        MessageBox.alert(this.gatewayError(oError));
                    }, this)
                });
            },
            /**
             * Closes the current dialog
             * @name   encollab.dp.vin.Detail#onDialogCancel
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onDialogCancel: function(oEvent) {
                this._oDialog.close().destroy();
            },
            /**
             * Navigates to a claim if a claim number is pressed
             * @name   encollab.dp.vin.Detail#onClaimPress
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onClaimPress: function(oEvent) {
                this.myRouter.navTo("wtydetail", {
                    wtyPath: oEvent.getSource().getBindingContext('vin').getPath().substr(1)
                });
            },
            onPressClaim: function(oEvent) {
                var claimNo = oEvent.getSource().getBindingContext('vin').getObject().ClaimNo;
                if (claimNo !== '') {
                    this.getRouter().navTo("wtydetail", {
                        wtyPath: "WarrantyClaims('" + claimNo + "')"
                    });
                }
            },
            
            onPressPos: function(oEvent) {
                var claimNo = oEvent.getSource().getBindingContext('vin').getObject().ClaimNo;
                if (claimNo !== '') {
                    this.getRouter().navTo("serctdetail", {
                        serctPath: "Servicects('" + claimNo + "')"
                    });
                }
            },
            /* =========================================================== */
            /* begin: internal methods                                     */
            /* =========================================================== */

            /**
             * Binds the view to the object path and expands the aggregated line items.
             * @function
             * @name   encollab.dp.vin.Detail#_onObjectMatched
             * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
             * @private
             */
            _onObjectMatched: function(oEvent) {
                var sObjectId = oEvent.getParameter("arguments").vehiclePath;
                this.getModel('vin').metadataLoaded().then(function() {
                    var sObjectPath = this.getModel('vin').createKey("Vehicles", {
                        VIN: sObjectId
                    });
                    this._bindView("vin>/" + sObjectPath);
                }.bind(this));
            },

            onAttributePress: function(oEvent) {
                var item = oEvent.getParameter('listItem').getBindingContext('vin').getObject();
                if (item.DataType === 'Case') {
                    var aName = item.Name.split(' ');
                    var caseId = aName[aName.length - 1];
                    this.getRouter().navTo("fprsDetail", {
                        fprsPath: "Cases('" + caseId + "')"
                    });
                }
            },
            /**
             * Binds the view to the object path. Makes sure that detail view displays
             * a busy indicator while data for the corresponding element binding is loaded.
             * @function
             * @name   encollab.dp.vin.Detail#_bindView
             * @param {string} sObjectPath path to the object to be bound to the view.
             * 
             * @private
             */
            _bindView: function(sObjectPath) {
                // Set busy indicator during view binding
                var oViewModel = this.getModel("detailView");
                var oView = this.getView();

                // If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
                oViewModel.setProperty("/busy", false);

                oView.bindElement({
                    path: sObjectPath,
                    parameters: {
                        expand: 'CustomAttributes,Dealer,Owner'
                    },
                    events: {
                        change: this._onBindingChange.bind(this),
                        dataRequested: function() {
                            oViewModel.setProperty("/busy", true);
                            oView.setBusy(true);
                        },
                        dataReceived: function() {
                            oViewModel.setProperty("/busy", false);
                            oView.setBusy(false);
                        }
                    }
                });
            },

            _onBindingChange: function() {
                var oView = this.getView(),
                    oElementBinding = oView.getElementBinding('vin');

                // No data for the binding
                if (!oElementBinding.getBoundContext()) {
                    this.getRouter().getTargets().display("objectNotFound");
                    return;
                }

            },

            _onMetadataLoaded: function() {
                // Store original busy indicator delay for the detail view
                var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
                    oViewModel = this.getModel("detailView");
                //oConfigItemTable = this.byId("configItemsList"),
                //iOriginalConfigItemTableBusyDelay = oConfigItemTable.getBusyIndicatorDelay(),
                //oHistoryItemTable = this.byId("historyItemsList"),
                //iOriginalHistoryItemTableBusyDelay = oHistoryItemTable.getBusyIndicatorDelay();

                // Make sure busy indicator is displayed immediately when
                // detail view is displayed for the first time
                oViewModel.setProperty("/delay", 0);
                oViewModel.setProperty("/configItemTableDelay", 0);
                oViewModel.setProperty("/historyItemTableDelay", 0);

                // oConfigItemTable.attachEventOnce("updateFinished", function() {
                //     // Restore original busy indicator delay for line item table
                //     oViewModel.setProperty("/configItemTableDelay", iOriginalConfigItemTableBusyDelay);
                // });

                // oHistoryItemTable.attachEventOnce("updateFinished", function() {
                //     // Restore original busy indicator delay for line item table
                //     oViewModel.setProperty("/historyItemTableDelay", iOriginalHistoryItemTableBusyDelay);
                // });

                // Binding the view will set it to not busy - so the view is always busy if it is not bound
                oViewModel.setProperty("/busy", true);
                // Restore original busy indicator delay for the detail view
                oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
            }

        });

    });