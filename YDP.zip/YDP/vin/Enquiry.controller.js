sap.ui.define([
        "encollab/dp/vin/BaseController",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/m/ColumnListItem",
        "sap/m/ObjectNumber",
        "sap/m/ObjectIdentifier"
    ],
    /**
     * <p>Controller for the VIN search.</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Vin</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.vin.Enquiry.view.xml <small>main view</small></li>
     * </ul>
     * @class Enquiry
     * @memberOf encollab.dp.vin
     * @extends {encollab.dp.vin.BaseController}
     * @return {encollab.dp.vin.Enquiry}
     * 
     * @param {encollab.dp.vin.BaseController} Controller   
     * @param {sap.ui.movel.Filter} Filter         
     * @param {sap.ui.model.FilterOperator} FilterOperator 
     * @param {sap.m.ColumnListItem} ColumnListItem 
     * @param {sap.m.ObjectNumber} ObjectNumber 
     * @param {sap.m.ObjectIdentifier} ObjectIdentifier    
     */
    function(Controller, Filter, FilterOperator, ColumnListItem, ObjectNumber, ObjectIdentifier) {
        "use strict";
        return Controller.extend("encollab.dp.vin.Enquiry", {
            _userAuthorisations: ['VehicleEnquiry'],
            //_userParameters: ['VKO', 'VTW'],
            /**
             * Initialization
             *
             * @method
             * @name   encollab.dp.vin.Enquiry#onInit
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);
            },
            /**
             * On search input box confirmation
             *
             * @method
             * @name   encollab.dp.vin.Enquiry#onSearchVehicles
             * @param {sap.ui.base.Event} evt
             */
            onSearchVehicles: function(evt) {
                var searchString = evt.getSource().getValue();

                if (searchString && searchString.length > 0) {
                    this._performSearch(searchString);
                }
            },
            /**
             * Uses VIN service to search and filter for VIN's and displays it in a list
             *
             * @method
             * @name   encollab.dp.vin.Enquiry#_performSearch
             * @param {sap.ui.base.Event} evt
             */
            _performSearch: function(searchString) {
                var oList = this.getView().byId('vehicleList');
                var filters = [];

                if (!this._oVehicleTemplate) {
                    this._oVehicleTemplate = new ColumnListItem({
                        type: 'Navigation',
                        press: jQuery.proxy(this.onPress, this),
                        cells: [
                            new ObjectIdentifier({
                                title: "{VIN}"
                            }),
                            // new ObjectIdentifier({
                            //     title: "{VehicleNo}"
                            // }),
                            new ObjectNumber({
                                number: "{Registration}",
                                emphasized: false
                            })
                        ]
                    });
                }

                this.getView().setBusy(true);
                this.getModel('vin').callFunction("/VehicleSearch", {
                    method: 'GET',
                    urlParameters: {
                        "$expand": "Owner",
                        "SearchString": searchString.toUpperCase()
                    }, //Gotta figure out how to do a $expand
                    success: $.proxy(function(oData, response) {
                        var model = new sap.ui.model.json.JSONModel(oData.results);
                        var vehicleList = this.getView().byId('vehicleList');
                        vehicleList.setModel(model);
                        vehicleList.bindItems({
                            path: "/",
                            template: this._oVehicleTemplate
                        });
                        this.getView().setBusy(false);
                    }, this),
                    failure: $.proxy(function(oError) {
                        this.gatewayError(oError);
                        this.getView().setBusy(false);
                    }, this)
                });
            },
            onCreateVehicle: function(oEvent) {
                this.getRouter().navTo("vinCreate");
            },
            /**
             * Navigates to the VIN when a VIN number is selected
             *
             * @method
             * @name   encollab.dp.vin.Enquiry#onPress
             * @param {sap.ui.base.Event} oEvent
             */
            onPress: function(oEvent) {
                var oItem = oEvent.getSource();
                this.getRouter().navTo("vindetail", {
                    vehiclePath: oItem.getBindingContext().getProperty("VIN") //getPath().substr(1)
                });

            }
        });
    });