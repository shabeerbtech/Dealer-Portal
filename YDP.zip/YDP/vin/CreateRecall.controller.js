sap.ui.define([
        "encollab/dp/vin/BaseController",
        "sap/ui/core/routing/History",
        "sap/ui/model/json/JSONModel",
        "sap/ui/model/odata/v2/ODataModel",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/m/MessageBox",
        "sap/m/MessageToast"
    ],
    /**
     * <p>Controller for the ATP / Backorder report. It's based on calling the same ABAP classes as deliverable AS036. Please refer
     * to the spec of this development to learn more about the data displayed here.</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Vin</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.vin.CreateRecall.view.xml <small>main view</small></li>
     * <li>encollab.dp.vin.recallClaim.fragment.xml</li>
     * </ul>
     * @class CreateRecall
     * @memberOf encollab.dp.vin
     * @extends {encollab.dp.BaseController}
     * @return {encollab.dp.vin.CreateRecall}
     * 
     * @param {encollab.dp.vin.BaseController} Controller   
     * @param {sap.ui.core.routing.History} History
     * @param {sap.ui.model.json.JSONModel} JSONModel 
     * @param {sap.ui.model.odata.v2.ODataModel} ODataModel
     * @param {sap.ui.model.Filter} Filter         
     * @param {sap.ui.model.FilterOperator} FilterOperator
     * @param {sap.m.MessageBox} MessageBox 
     * @param {sap.m.MessageToast} MessageToast         
     */
    function(Controller, History, JSONModel, ODataModel, Filter, FilterOperator, MessageBox, MessageToast) {
        "use strict";
        return Controller.extend("encollab.dp.vin.CreateRecall", {
            _userAuthorisations: ['WarrantyClaims', 'WarrantyCreate'],
            /**
             * Initialization of the controller. Sets up a new claim JSON model. 
             * @name   encollab.dp.vin.CreateRecall#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);

                this.getView().setModel(new JSONModel(), "newClaim");

                this.myRouter.getRoute("vinRecall").attachPatternMatched(this._onObjectMatched, this);
            },
            /**
             * Gets vehicle number from the URL parameters and fetch it's details from SAP. Bind the results to the screen. 
             * @name   encollab.dp.vin.CreateRecall#_onObjectMatched
             * @param {sap.ui.base.Event} oEvent
             * @private
             * @method
             */
            _onObjectMatched: function(oEvent) {
                this.getView().getModel('vin').read('/' + oEvent.getParameter("arguments").vehiclePath, {
                    success: $.proxy(function(oData, response) {
                        this._vehicle = oData;
                        this._initializeNewClaimData();
                    }, this)
                });
                var recallPath = oEvent.getParameter("arguments").recallPath;
                this.getView().bindElement({
                    model: 'vin',
                    path: "/" + recallPath,
                    parameters: {
                        expand: 'Variants'
                    },
                    success: $.proxy(function(oData, response) {
                        console.log('Success');
                    })
                });
            },
            /**
             * Sets up the local JSON model with an empty claim structure 
             * @name   encollab.dp.vin.CreateRecall#_initializeNewClaimData
             * @param {sap.ui.base.Event} oEvent
             * @private
             * @method
             */
            _initializeNewClaimData: function() {
                this.getView().getModel("newClaim").setData({
                    Detail: {
                        VIN: this._vehicle.VIN,
                        Dealer: this.myComponent.getMySettingValue('DP_KUNNR'),
                        DealerRefNo: '',
                        Km: 0,
                        RepairDate: new Date(),
                        WarrantyVariant: null,
                        ReadyToSubmit: false
                    }
                });
            },
            /**
             * When the dealer changes, it's value is stored
             * @name   encollab.dp.vin.CreateRecall#onDealerChange
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onDealerChange: function(oEvent) {
                var mNewClaim = this.getView().getModel("newClaim").getData().Detail;
                var vPath = "/UserSettings(UserId='" + this.myComponent.getMyId() + "',Name='DP_KUNNR')";
                this.getModel('core').update(vPath, {
                    Value: mNewClaim.Dealer
                }, {
                    merge: true
                });
            },
            /**
             * Gets the current values of the new claim details and converts some to their proper types like, blanks to booleans. 
             * @name   encollab.dp.vin.CreateRecall#onDetailsChange
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onDetailsChange: function(oEvent) {
                var mNewClaim = this.getView().getModel("newClaim").getData().Detail;
                var submitButton = this.getView().byId('submitButton');
                mNewClaim.ReadyToSubmit = true;
                if (mNewClaim.Dealer === '') mNewClaim.ReadyToSubmit = false;
                if (mNewClaim.DealerRefNo === '') mNewClaim.ReadyToSubmit = false;
                if (mNewClaim.Km === '' || parseInt(mNewClaim.Km, 10) <= parseInt(this._vehicle.Mileage, 10)) mNewClaim.ReadyToSubmit = false;
                if (mNewClaim.RepairDate > new Date()) mNewClaim.ReadyToSubmit = false;
            },
            /**
             * Formatter for date, checks if it's larger than today 
             * @name   encollab.dp.vin.CreateRecall#isValidDate
             * @param {string} value
             * @method
             */
            isValidDate: function(value) {
                return value > new Date() ? 'Error' : 'None';
            },
            /**
             * Sets up all the details for the claim structure and updates SAP. On success, the claim details are reset and
             * the app navigates to the newly created claim. On error, a message is displayed. 
             * @name   encollab.dp.vin.CreateRecall#saveClaim
             * @method
             */
            saveClaim: function() {
                this.getOwnerComponent().resetMessagePopover();

                var mNewVehicle = this.getView().getModel("newClaim").getData().Detail;
                var oData = this.getView().getBindingContext('vin').getObject();
                var oParams = {
                    VIN: mNewVehicle.VIN,
                    RecallNo: oData.ClaimId,
                    Dealer: mNewVehicle.Dealer,
                    DealerRefNo: mNewVehicle.DealerRefNo,
                    Km: mNewVehicle.Km,
                    RepairDate: mNewVehicle.RepairDate,
                    WarrantyVariant: this.getView().byId('idVar').getSelectedKey()
                };

                this.getView().getModel().callFunction("/WtyClaimRecall", {
                    method: 'POST',
                    urlParameters: oParams,
                    success: $.proxy(function(oData, response) {
                        this._initializeNewClaimData();
                        this.getRouter().navTo("wtydetail", {
                            wtyPath: "WtyHeaders(guid'" + oData.GUID + "')"
                        });
                        this.busyDialog.close();
                        MessageToast.show("Recall Claim '" + oData.ClaimNr + "' created");
                    }, this),
                    error: $.proxy(function(oError) {
                        this.busyDialog.close();
                        MessageBox.alert(this.gatewayError(oError));
                    }, this)
                });
            },
            /**
             * Trigger for the Save button. Sets the busy dialog and calls the save function. 
             * @name   encollab.dp.vin.CreateRecall#onSave
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onSave: function() {
                this.busyDialog.open();
                this.saveClaim();
            },
            /**
             * Navigates back
             * @name   encollab.dp.vin.CreateRecall#onCancel
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onCancel: function() {
                this.onNavBack();
            },
            /**
             * Navigates back to the VIN
             * @name   encollab.dp.vin.CreateRecall#onNavBack
             * @param {sap.ui.base.Event} oEvent
             * @method
             */
            onNavBack: function() {
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();

                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    this.myRouter.navTo("vin", true);
                }
            }
        });
    });