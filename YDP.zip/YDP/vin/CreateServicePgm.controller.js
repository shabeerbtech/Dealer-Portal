/**
****************************************************************************************
*  Created on:  Created by:  TR          Description 
*  2018.02.25   Nisha                    New Controller fiel for Service Program

*****************************************************************************************
*/
sap.ui.define([
        "encollab/dp/vin/BaseController",
        "sap/ui/core/routing/History",
        "sap/ui/model/json/JSONModel",
        "sap/ui/model/odata/v2/ODataModel",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/m/MessageBox",
        "sap/m/MessageToast"
    ],
    /**
     * <p>This acts as the controller for the creation of every qualifier claim, some of which have their own tile, while others go through 
     * the VIN detail screen.</p>
     * <h4>OData services used</h4>
     * <ul>
     * <li>Wty</li>
     * <li>Core</li>
     * <li>VIN</li>
     * <li>Part</li>
     * </ul>
     * <h4>Templates used</h4>
     * <ul>
     * <li>encollab.dp.wty.Create.view.xml <small>main view</small></li>
     * <li>encollab.dp.wty.standardForm.fragment.xml</li>
     * </ul>
     * @class Create
     * @memberOf encollab.dp.wty
     * @extends {encollab.dp.BaseController}
     * @return {encollab.dp.wty.Create}
     * 
     * @param {encollab.dp.wty.BaseController} Controller   
     * @param {sap.ui.core.routing.History} History
     * @param {sap.ui.model.json.JSONModel} JSONModel 
     * @param {sap.m.Sta0ndardListItem} StandardListItem
     * @param {sap.m.Item} Item  
     * @param {sap.ui.model.Filter} Filter         
     * @param {sap.ui.model.FilterOperator} FilterOperator       
     */
    function(Controller, History, JSONModel, ODataModel, Filter, FilterOperator, MessageBox, MessageToast)
    {
        "use strict";
        return Controller.extend("encollab.dp.vin.CreateServicePgm", {
           _userAuthorisations: ['VehicleEnquiry'],
            /**
             * This array holds the user parameters required to run this controller
             *
             * @private
             * @member
             * @name   encollab.dp.orders.Create#_userParameters
             */
           // _userParameters: ['VKO', 'VTW', 'WRK'],
            /**
             * Holds the current qualifier
             * @name   encollab.dp.wty.Create#_Qualifier
             * @member
             */
           
            /**
             * Initialization of the controller. Sets up a new claim JSON model. 
             * @name   encollab.dp.wty.Create#onInit
             * @method
             */
            onInit: function() {
                Controller.prototype.onInit.apply(this, arguments);
                this._Customer = this.myComponent.Customer;
              this.getView().setModel(new JSONModel(), "newClaim");
                this.myRouter.getRoute("createservicepgm").attachPatternMatched(this._onVehicleClaim, this);
             
            },
            /**
             * Executed after the entire view is rendered. User details are fetched from the Core service to see if the user has
             * any dealers defined. 
             * @name   encollab.dp.wty.Create#onAfterViewRendered
             * @method
             */
            onAfterViewRendered: function() {
                var aCust = this.getModel('core').getProperty("/Users('" + this.getOwnerComponent().getMyId() + "')/Dealers");
                if (!aCust || !aCust.length || aCust.length === 0) {
                    this.popErrorMessage('No Dealer', 'This user not linked to a dealer');
                    this.getView().getContent()[0].destroyContent();
                }
            },
            /**
             * This sets the VIN related claim creation, and fetches the VIN details
             * @name   encollab.dp.wty.Create#onInit
             * @param {sap.ui.base.Event} oEvent
             * @method
             * @private
             */
             _onVehicleClaim: function(oEvent) {
                
                var sVehiclePath = "/" + oEvent.getParameter("arguments").vehiclePath;
                var servicepgm = oEvent.getParameter("arguments").servicepgm;
                var servicetype = oEvent.getParameter("arguments").servicetype;
                this.getView().bindElement({
                    model: 'vin',
                    path: sVehiclePath,
                    events: {
                        change: this._onBindingChange.bind(this, servicepgm, servicetype)
                    }
                });
            },
  
            
            /**
             * When the binding changes, several checks are made and the wizard is reset. 
             * @name   encollab.dp.wty.Create#_onEXClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             * @private
             */
            _onBindingChange: function(servicepgm, servicetype , oEvent) {
                this.getView().setBusy(true);
                this.initializeNewClaimData(servicepgm,servicetype);
                //this.getView().setBusy(false);
               this._buildWizard(servicepgm, servicetype);
               
            },
            /**
             * Function to build a new wizard
             * @name   encollab.dp.wty.Create#_onEXClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             * @private
             */
            _buildWizard: function( ) {
                var oPage = this.getView().byId('createClaimPage');
                
                if (!this._wizard) {
                    this._wizard = sap.ui.xmlfragment("encollab.dp.vin.standardForm", this);
                    //oPage.addContent(this._wizard);
                }
                    //var newClaim = this.getView().getModel("newClaim").getData();
                    //var serv = newClaim.Header.ServicePgmID;
                    var vin = this.getView().getBindingContext('vin').getObject().VIN;
                    oPage.setTitle(this.getText('wtyClaimCreateTitle') + ' ' + vin);
             
                this.getView().byId('onSaveButton').setVisible(true);
            },
            /**
             * Sets up the Qualifier selection box with the relevant qualifiers and their descriptions. 
             * @name   encollab.dp.wty.Create#_onEXClaim
             * @param {sap.ui.base.Event} oEvent
             * @method
             
     
            /**
             * Initialize a new claim based on the current Qualifier
             * @name   encollab.dp.wty.Create#initializeNewClaimData
             * @method
             */
            initializeNewClaimData: function(servicepgm, servicetype) 
            {
                this.getView().setBusy(true);
                var oComponent = this.myComponent;
                var oVehicle = this.getView().getBindingContext('vin').getObject();
                        this.getView().getModel("newClaim").setData({
                            Header: {
                                ServicePgmID: servicepgm,
                                ServiceType:servicetype,
                                Dealer: oComponent.getMySettingValue('DP_KUNNR'),
                                Claimdate: new Date(),
                                VIN: oVehicle.VIN,
                                ReferenceNo: oComponent.getMyId(),
                                Mileage:'0',
                                RepairEndate:new Date()
                             // ClaimDescr: ''
                            },
                            items:[]
                           
                        });

                 //to dispplay items
                  if( servicepgm)
                   {
                   this.getModel('vin').read("/Servicepmps(VIN='" + oVehicle.VIN +"',ServicePgmID='"+ servicepgm+"',ServiceType='" + servicetype + "')"+"/ServiceItems",
                   {
                   success: function(data) {
                     // var itms = data.results;
                      // this.getModel('newClaim').setProperty('items', itms);
                      this.getView().getModel("newClaim").setProperty('/items', data.results);
                    //   var newClaim = this.getView().getModel("newClaim").getData();
                    this.getView().setBusy(false);
                    }.bind(this ),
                    error:function(oError) {
                        this.getView().setBusy(false);
                    //this._wizard.destroy();
                        //this._wizard = null;

                      //var text = JSON.parse(oError.responseText).error.message.value;
                      //this.MessageToast.show('PMPItems fetch failed');
                      //this.errorMessage('PMPItems fetch failed', text);
                    }.bind(this)
                });
                }
                 else
                 {
                var items = [];
                this.getView().getModel("newClaim").setProperty('/items', items);
                 }
                },
           // },
         
   
            /**
             * Checks if the date supplied is valid
             * @name   encollab.dp.wty.Create#isValidDate
             * @param {date} value 
             * @method
             */
            isValidDate: function(value) {
                return value > new Date() ? 'Error' : 'None';
            },
        
            /**
             * @param {sap.ui.base.Event} oEvent 
             * @name   encollab.dp.wty.Create#onDealerChange
             * @method
             */
            onDealerChange: function(oEvent) {
                var mNewClaim = this.getView().getModel("newClaim").getData().Header;
                var vPath = "/UserSettings(UserId='" + this.myComponent.getMyId() + "',Name='DP_KUNNR')";
                this.getModel('core').update(vPath, {
                    Value: mNewClaim.Dealer
                }, {
                    merge: true
                });
                this.onFieldChange(oEvent);
            },
            /**
             * @param {sap.ui.base.Event} oEvent 
             * @name   encollab.dp.wty.Create#onRefDateChange
             * @method
             */
            onRefDateChange: function(oEvent) {
                this.onFieldChange(oEvent);
            },
            /**
             * @param {sap.ui.base.Event} oEvent 
             * @name   encollab.dp.wty.Create#onRepDateChange
             * @method
             */
            onRepDateChange: function(oEvent) {
                this.onFieldChange(oEvent);
            },
            /**
             * Use this method checks the validity of all fields
             * @name   encollab.dp.wty.Create#onFieldChange
             * @param {sap.ui.base.Event} oEvent 
             * @method
             */
            onFieldChange: function(oEvent) {
                var allOk = true;
                var newClaim = this.getView().getModel('newClaim').getProperty('/');
                if (newClaim.Header.Claimdate > new Date()) {
                    allOk = false;
                }
                
                if (!newClaim.Header.ReferenceNo || !newClaim.Header.ReferenceNo.length) {
                    allOk = false;
                }
          
                if (newClaim.Header.Mileage && Number(newClaim.Header.Mileage) <= 0) {
                    allOk = false;
                }

                this.getView().byId('onSaveButton').setEnabled(allOk && this._readyToCreate());
            },
            _readyToCreate: function() {
                var oNewClaim = this.getView().getModel("newClaim").getData();
                if (
                    oNewClaim &&
                    oNewClaim.Header.servicepgm !== '' &&
                    oNewClaim.Header.Dealer !== '' &&
                    oNewClaim.Header.servicetype !== '' &&
                    oNewClaim.Header.Claimdate <= new Date() &&
                    oNewClaim.Header.ReferenceNo !== ''  &&
                    oNewClaim.Header.Mileage !==  '' && 
                    oNewClaim.Header.RepairEndate <= new Date()
                    //oNewClaim.Header.ClaimDescr !== '' //&&
                    //oNewClaim.CausalPart.MaterialId !== ''
                ) {
                    return true;
                } else {
                    return false;
                }
            },
            /**
             * This takes the new claim data and creates the claim in SAP. It also performs a followup action on the claim if necessary. 
             * On success the Wizard is reset, otherwise errors are displayed.
             * @name   encollab.dp.wty.Create#createClaim
             * @param  {object} oPayload 
             * @method
             */
            createClaim: function(oPayload) { // I really should use promises here
                this.resetMessagePopover();
                //var newClaimId;
                var fSuccess = function(mResponse) {
                    this.initializeNewClaimData();
                    //this._wizard.destroy();
                    //this._wizard = null;
                    this.myRouter.navTo("serctdetail", {
                        serctPath: "Servicects('" + mResponse.ClaimNo + "')"
                    });
                    this.MessageToast.show(this.getText('serctClaimCreated', [mResponse.ClaimNo]));
                    this.busyDialog.close();
                };
                var fError = function(oError) {
                    this.busyDialog.close();
                    this.gatewayError(oError);
                    
                        this.initializeNewClaimData();
                        //this._wizard.destroy();
                        //this._wizard = null;
                       
                      var text = JSON.parse(oError.responseText).error.message.value;
                      this.MessageToast.show('Claim Creation failed ,See info Messages');
                      this.errorMessage('Claim creation failed', text);
                    };
              //  };
        
                // Send OData Create request
                this.getView().getModel('vin').create("/Servicects", oPayload, {
                    success: fSuccess.bind(this),
                    error: fError.bind(this)
                });
            },
            /**
             * Takes the wizard data and prepares the claim's payload before saving
             * @name   encollab.dp.wty.Create#onSave
             * @param  {object} oPayload 
             * @method
             */
             //BOC-C004
             	onSave:function(oEvent){

          var millage = this.getView().getModel("newClaim").getData().Header.Mileage;
          var isValidMileage = this.ValidatemileageInput(millage);
          
       	if (isValidMileage ) {
        //EOC-C005
              this.oClaimpayload();
          }
//}
      },
       oClaimpayload: function(oEvent) {
                this.busyDialog.open();
                var newClaim = this.getView().getModel("newClaim").getData();
                var mPayload = newClaim.Header;
                mPayload.Claimdate = this.accountForUTCDate(mPayload.Claimdate);
                mPayload.RepairEndate = this.accountForUTCDate(mPayload.RepairEndate);
                this.createClaim(mPayload);
            },
            /**
            * This method validate mileageinput,this method not allow  special char & decimal in mileage input
            */
            ValidatemileageInput: function(mileageCurr) {
          var numbers = /^[0-9]+$/;
         if (mileageCurr.match(numbers)) {
          return true;
        } else {
        //BOC-C003
          this.MessageToast.show("Please Enter Mileage Without Separators");
        //EOC-C003
          return false;
        }
      },
      //EOC-C004

            onCancel: function() {
                this.onNavBack();
            },
            onNavBack: function() {
                //this._wizard.destroy();
               //this._wizard = null;
                this.myRouter.navTo("vindetail", {
                    vehiclePath: this.getView().getBindingContext('vin').getProperty("VIN")
                });
            }
        });
    });