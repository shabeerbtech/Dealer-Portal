sap.ui.define([
		"encollab/dp/BaseController",
		"sap/ui/model/odata/v2/ODataModel"
	],
	/**
	 * <p>Base Controller for VIN. Serves no purpose at this point. </p>
	 * <h4>OData services used</h4>
	 * <ul>
	 * <li>Vin</li>
	 * </ul>
	 * @class BaseController
	 * @memberOf encollab.dp.vin
	 * @extends {encollab.dp.BaseController}
	 * @return {encollab.dp.vin.BaseController}
	 * 
	 * @param  {encollab.dp.BaseController} Controller          
	 */
	function(Controller, ODataModel) {
		"use strict";

		return Controller.extend("encollab.dp.vin.BaseController", {

			onInit: function() {
				Controller.prototype.onInit.apply(this, arguments);
			}
		});

	});